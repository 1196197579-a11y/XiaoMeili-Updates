@echo off
setlocal
set "ROOT=%PUBLIC%\XiaoMeili"
set "APP_DIR=%ROOT%\app"
if not exist "%APP_DIR%\.venv\Scripts\python.exe" (
  echo Run INSTALL_AND_RUN.bat first.
  pause
  exit /b 1
)
"%APP_DIR%\.venv\Scripts\python.exe" -m pip install "pyinstaller>=6.10,<7"
set "DXCAM_ARG="
"%APP_DIR%\.venv\Scripts\python.exe" -c "import dxcam" >nul 2>nul && set "DXCAM_ARG=--collect-all dxcam"
"%APP_DIR%\.venv\Scripts\pyinstaller.exe" --noconfirm --clean --windowed --name "XiaoMeili" --icon "%APP_DIR%\assets\xiaomeili_icon.ico" --distpath "%ROOT%\DesktopApp" --workpath "%ROOT%\build" --specpath "%ROOT%" --collect-all rapidocr --collect-all onnxruntime --collect-all espeakng_loader --collect-all kokoro_onnx --collect-all misaki --collect-all jieba --collect-all pypinyin --collect-all pypinyin_dict --collect-all cn2an --collect-all ordered_set --collect-all soundfile %DXCAM_ARG% --add-data "%APP_DIR%\assets;assets" "%APP_DIR%\src\main.py"
echo.
echo Build finished:
echo %ROOT%\DesktopApp\XiaoMeili\XiaoMeili.exe
pause
