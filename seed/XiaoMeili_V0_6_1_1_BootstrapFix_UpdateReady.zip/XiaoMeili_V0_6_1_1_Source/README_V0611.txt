﻿小美丽 V0.6.1.1｜Voice Mouth Bootstrap Fix

本版重点：
1. 修复 V0.6.1 的 INSTALL_AND_RUN.bat 在 Windows CMD 下因文本编码/换行解析异常而出现的“xxx 不是内部或外部命令”。
2. INSTALL_AND_RUN.bat / .cmd 现在为纯 ASCII + CRLF；INSTALL.ps1 为 UTF-8 BOM + CRLF，兼容 Windows PowerShell 5.1。
3. 保留 V0.6.1 的 Kokoro/eSpeak 打包修复、桌面错误日志、应用内更新器。
4. 正常安装后，日常只启动桌面“小美丽”快捷方式，不再使用 BAT。
5. 运行错误会写入桌面：小美丽错误日志_请上传给ChatGPT.txt
6. 安装错误会写入桌面：小美丽安装错误日志_请上传给ChatGPT.txt；若 PowerShell 甚至未能启动，还会生成 XiaoMeili_Install_Error_Log.txt。
7. 更新器支持 latest.json + SHA-256 校验 + 下载 + 替换 + 自动重启。永久更新源需要绑定到一个可访问的 GitHub 仓库。

本次操作：
解压完整压缩包后，只双击 INSTALL_AND_RUN.bat（或 INSTALL_AND_RUN.cmd）一次。
安装成功后，以后只打开小美丽.exe。
