# -*- coding: utf-8 -*-
import os, sys, json, shutil, logging, traceback, subprocess, threading, time, ctypes, re, gc, random, tempfile, zipfile, urllib.request, hashlib
# Limit math/image libraries to one worker thread. The previous build could let
# OpenCV/ONNX fan out across many cores during frequent HUD scans.
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
from difflib import SequenceMatcher
from pathlib import Path
from logging.handlers import RotatingFileHandler

from PySide6.QtCore import Qt, QPropertyAnimation, QEasingCurve, QParallelAnimationGroup, Signal, QObject, QTimer, QThread, QSize, QRect, QRectF, QPointF
from PySide6.QtGui import QIcon, QAction, QKeySequence, QCursor, QImage, QMovie, QPixmap, QFontDatabase, QFont, QPainter, QColor, QFontMetrics, QPainterPath, QPen
from PySide6.QtWidgets import (
    QApplication, QWidget, QLabel, QVBoxLayout, QStackedLayout, QGraphicsOpacityEffect,
    QSystemTrayIcon, QMenu, QDialog, QTabWidget, QFormLayout, QCheckBox, QSlider,
    QPushButton, QHBoxLayout, QFileDialog, QMessageBox, QTableWidget,
    QTableWidgetItem, QKeySequenceEdit, QHeaderView, QSpinBox, QGroupBox, QGridLayout, QLineEdit, QComboBox, QListWidget, QListWidgetItem, QProgressDialog, QDoubleSpinBox, QInputDialog, QProgressBar
)
from PIL import Image
import keyboard
import cv2
import numpy as np

APP_NAME = "小美丽 V0.6.1.1｜Voice Mouth + Continuous Puppet V2"
APP_VERSION = "0.6.1.1"
UPDATE_PROTOCOL_VERSION = 1
ORG_NAME = "XiaoMeili"
ASSET_RNG = random.SystemRandom()  # independent draw with replacement; consecutive repeats are allowed
VIDEO_EXTS = {".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v"}
MAX_ASSETS_PER_STATE = 20

STATE_NAMES = {
    "idle": "待机",
    "low_hp": "低血量",
    "kill": "击杀",
    "dead": "被击杀",
    "victory": "获胜",
    "defeat": "失败",
    "report": "战报",
}

DEFAULT_HOTKEYS = {
    "idle": "ctrl+alt+1",
    "low_hp": "ctrl+alt+2",
    "kill": "ctrl+alt+3",
    "dead": "ctrl+alt+4",
    "victory": "ctrl+alt+5",
    "defeat": "ctrl+alt+6",
    "toggle_lock": "ctrl+alt+l",
    "settings": "ctrl+alt+s",
    "show_hide": "ctrl+alt+h",
}


def app_root() -> Path:
    if getattr(sys, "frozen", False):
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
    return Path(__file__).resolve().parent.parent


def user_root() -> Path:
    if sys.platform == "win32":
        base = os.getenv("PUBLIC") or r"C:\Users\Public"
        p = Path(base) / "XiaoMeiliData"
    else:
        p = Path.home() / ".xiaomeili"
    p.mkdir(parents=True, exist_ok=True)
    return p


ROOT = app_root()
USER = user_root()
LOG_DIR = USER / "logs"
CACHE_DIR = USER / "assets"
DEBUG_DIR = USER / "vision_debug"
REPORT_DEBUG_DIR = DEBUG_DIR / "report_debug"
LOG_DIR.mkdir(parents=True, exist_ok=True)
CACHE_DIR.mkdir(parents=True, exist_ok=True)
DEBUG_DIR.mkdir(parents=True, exist_ok=True)
REPORT_DEBUG_DIR.mkdir(parents=True, exist_ok=True)
CONFIG_FILE = USER / "config.json"
UPDATE_DIR = USER / "updates"
UPDATE_DIR.mkdir(parents=True, exist_ok=True)


def desktop_dir() -> Path:
    """Return the real Windows Desktop path when possible, including OneDrive/localized setups."""
    if sys.platform == "win32":
        try:
            buf = ctypes.create_unicode_buffer(1024)
            # CSIDL_DESKTOPDIRECTORY = 0x10
            if ctypes.windll.shell32.SHGetFolderPathW(None, 0x10, None, 0, buf) == 0 and buf.value:
                return Path(buf.value)
        except Exception:
            pass
    p = Path.home() / "Desktop"
    p.mkdir(parents=True, exist_ok=True)
    return p


DESKTOP_ERROR_LOG = desktop_dir() / "小美丽错误日志_请上传给ChatGPT.txt"




DEFAULT_REPORT_LAYOUT = {
    # Normalized to the complete pet canvas. The supplied whiteboard is stationary,
    # so one rectangle is enough and no per-frame tracking is required.
    "x": 0.105, "y": 0.675, "w": 0.790, "h": 0.235,
    "offset_x": 0.0, "offset_y": 0.0,
    "line1_scale": 1.00, "line2_scale": 1.00,
    "line_spacing": 0.02,
    "text_color": "#08423A",
    "outline_color": "#F6FFF9",
    "outline_width": 0.0,
    "auto_fill": True,
    "max_eval_lines": 2,
}


def report_layout_key(path_value):
    try:
        p = Path(str(path_value or ""))
        return p.name or "__default_report__"
    except Exception:
        return "__default_report__"


def normalized_report_layout(value=None):
    out = dict(DEFAULT_REPORT_LAYOUT)
    if isinstance(value, dict):
        for k in out:
            if k in value:
                out[k] = value[k]
    # Clamp user-editable geometry so a malformed config cannot hide text forever.
    try:
        out["x"] = max(0.0, min(0.95, float(out["x"])))
        out["y"] = max(0.0, min(0.95, float(out["y"])))
        out["w"] = max(0.05, min(1.0 - out["x"], float(out["w"])))
        out["h"] = max(0.05, min(1.0 - out["y"], float(out["h"])))
        out["offset_x"] = max(-0.3, min(0.3, float(out["offset_x"])))
        out["offset_y"] = max(-0.3, min(0.3, float(out["offset_y"])))
        out["line1_scale"] = max(0.45, min(2.2, float(out["line1_scale"])))
        out["line2_scale"] = max(0.45, min(2.2, float(out["line2_scale"])))
        out["line_spacing"] = max(-0.10, min(0.25, float(out["line_spacing"])))
        out["outline_width"] = max(0.0, min(5.0, float(out["outline_width"])))
        out["max_eval_lines"] = 2 if int(out.get("max_eval_lines", 2)) >= 2 else 1
        out["auto_fill"] = bool(out.get("auto_fill", True))
    except Exception:
        return dict(DEFAULT_REPORT_LAYOUT)
    return out


def get_report_layout(cfg, asset_path=None):
    layouts = cfg.get("report_layouts", {}) if isinstance(cfg.get("report_layouts"), dict) else {}
    return normalized_report_layout(layouts.get(report_layout_key(asset_path), {}))


def set_report_layout(cfg, asset_path, layout):
    if not isinstance(cfg.get("report_layouts"), dict):
        cfg["report_layouts"] = {}
    cfg["report_layouts"][report_layout_key(asset_path)] = normalized_report_layout(layout)


def _split_eval_candidates(text):
    text = str(text or "").strip()
    if not text:
        return [[""]]
    out = [[text]]
    # Prefer semantic punctuation; also consider a balanced hard split as fallback.
    positions = [m.end() for m in re.finditer(r"[，,。！？!?；;]", text) if 1 < m.end() < len(text)-1]
    positions += [i for i in range(max(2, len(text)//2-3), min(len(text)-1, len(text)//2+4))]
    seen = set()
    for pos in positions:
        a, b = text[:pos].strip(), text[pos:].strip()
        key=(a,b)
        if a and b and key not in seen:
            seen.add(key); out.append([a,b])
    return out


def _max_font_px(font_family, lines, max_width, max_height, max_px=180):
    lines = list(lines or [""])
    lo, hi, best = 6, max(8, int(max_px)), 6
    while lo <= hi:
        mid=(lo+hi)//2
        f=QFont(font_family); f.setPixelSize(mid)
        fm=QFontMetrics(f)
        widest=max((fm.horizontalAdvance(x) for x in lines), default=0)
        total=len(lines)*fm.height()
        if widest <= max_width and total <= max_height:
            best=mid; lo=mid+1
        else:
            hi=mid-1
    return best


def _best_eval_layout(font_family, text, max_width, max_height, max_lines=2):
    candidates=_split_eval_candidates(text)
    best_lines=[text]; best_px=6
    for lines in candidates:
        if len(lines)>max_lines:
            continue
        px=_max_font_px(font_family, lines, max_width, max_height)
        # Prefer visually larger lettering; a tiny bias keeps one-line text intact when close.
        score=px + (0.25 if len(lines)==1 else 0.0)
        if score > best_px:
            best_px=score; best_lines=lines
    return best_lines, int(best_px)


def _draw_path_text(painter, rect, text, font, fill, outline=None, outline_width=0.0):
    fm=QFontMetrics(font)
    x=rect.x() + (rect.width()-fm.horizontalAdvance(text))/2
    baseline=rect.y() + (rect.height()-fm.height())/2 + fm.ascent()
    path=QPainterPath(); path.addText(QPointF(float(x), float(baseline)), font, text)
    if outline_width and outline_width>0:
        painter.setPen(QPen(outline or QColor("#F6FFF9"), float(outline_width), Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
        painter.setBrush(Qt.BrushStyle.NoBrush); painter.drawPath(path)
    painter.setPen(Qt.PenStyle.NoPen); painter.setBrush(fill); painter.drawPath(path)


def render_report_text_pixmap(width, height, layout, kills, evaluation, font_family):
    width=max(1,int(width)); height=max(1,int(height)); layout=normalized_report_layout(layout)
    pix=QPixmap(width,height); pix.fill(Qt.GlobalColor.transparent)
    p=QPainter(pix); p.setRenderHint(QPainter.RenderHint.Antialiasing,True); p.setRenderHint(QPainter.RenderHint.TextAntialiasing,True)
    rx=(layout["x"]+layout["offset_x"])*width; ry=(layout["y"]+layout["offset_y"])*height
    rw=layout["w"]*width; rh=layout["h"]*height
    # Small internal safety margin. Auto-fit then expands text until it nearly fills this region.
    mx=max(2.0,rw*0.025); my=max(2.0,rh*0.025)
    inner=QRect(int(rx+mx),int(ry+my),max(1,int(rw-2*mx)),max(1,int(rh-2*my)))
    gap=max(-4,int(rh*float(layout.get("line_spacing",0.02))))
    line1_h=max(18,int(inner.height()*0.34)); eval_h=max(18,inner.height()-line1_h-gap)
    r1=QRect(inner.x(),inner.y(),inner.width(),line1_h)
    r2=QRect(inner.x(),inner.y()+line1_h+gap,inner.width(),eval_h)
    fill=QColor(str(layout.get("text_color","#08423A"))); outline=QColor(str(layout.get("outline_color","#F6FFF9")))
    line1=f"击杀数：{max(0,int(kills))}个"
    if bool(layout.get("auto_fill",True)):
        p1=_max_font_px(font_family,[line1],int(r1.width()*0.98),int(r1.height()*0.96),max_px=max(20,int(height*0.35)))
    else:
        p1=max(8,int(r1.height()*0.62))
    p1=max(8,int(p1*float(layout.get("line1_scale",1.0))))
    f1=QFont(font_family); f1.setPixelSize(p1)
    _draw_path_text(p,r1,line1,f1,fill,outline,float(layout.get("outline_width",0.0)))
    lines,p2=_best_eval_layout(font_family,str(evaluation or ""),int(r2.width()*0.98),int(r2.height()*0.96),int(layout.get("max_eval_lines",2)))
    if not bool(layout.get("auto_fill",True)):
        p2=max(8,min(p2,int(r2.height()*0.40)))
    p2=max(8,int(p2*float(layout.get("line2_scale",1.0))))
    f2=QFont(font_family); f2.setPixelSize(p2); fm2=QFontMetrics(f2)
    total=len(lines)*fm2.height(); start_y=r2.y()+(r2.height()-total)//2
    for i,line in enumerate(lines):
        rr=QRect(r2.x(),start_y+i*fm2.height(),r2.width(),fm2.height())
        _draw_path_text(p,rr,line,f2,fill,outline,float(layout.get("outline_width",0.0)))
    p.end(); return pix

class DesktopErrorHandler(logging.Handler):
    """Every ERROR+ also leaves one easy-to-find desktop report for the user to upload."""
    _lock = threading.Lock()

    def emit(self, record):
        if record.levelno < logging.ERROR:
            return
        try:
            with self._lock:
                DESKTOP_ERROR_LOG.parent.mkdir(parents=True, exist_ok=True)
                lines = [
                    "=" * 72,
                    f"时间: {time.strftime('%Y-%m-%d %H:%M:%S')}",
                    f"版本: {APP_VERSION}",
                    f"系统: {sys.platform}",
                    f"程序目录: {ROOT}",
                    f"用户数据: {USER}",
                    f"错误级别: {record.levelname}",
                    f"错误: {record.getMessage()}",
                ]
                if record.exc_info:
                    lines.append("异常堆栈:\n" + "".join(traceback.format_exception(*record.exc_info)))
                lines.append(f"完整运行日志: {CURRENT_LOG if 'CURRENT_LOG' in globals() else '初始化中'}")
                lines.append("")
                with open(DESKTOP_ERROR_LOG, "a", encoding="utf-8") as f:
                    f.write("\n".join(lines) + "\n")
        except Exception:
            pass


def setup_logging():
    logfile = LOG_DIR / f"xiaomeili_{time.strftime('%Y%m%d_%H%M%S')}.log"
    logger = logging.getLogger("xiaomeili")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
    fh = RotatingFileHandler(logfile, maxBytes=3_000_000, backupCount=8, encoding="utf-8")
    fh.setFormatter(fmt)
    logger.addHandler(fh)
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    logger.addHandler(sh)
    dh = DesktopErrorHandler()
    dh.setLevel(logging.ERROR)
    dh.setFormatter(fmt)
    logger.addHandler(dh)
    logger.info("=== %s 启动 ===", APP_NAME)
    logger.info("ROOT=%s", ROOT)
    logger.info("USER=%s", USER)
    logger.info("Python=%s", sys.version.replace("\n", " "))
    logger.info("Platform=%s", sys.platform)
    return logger, logfile


LOGGER, CURRENT_LOG = setup_logging()


def resource(rel: str) -> str:
    return str(ROOT / rel)


def bundled_assets():
    # Every state owns a pool. Imported videos replace the placeholder pool and
    # up to 20 clips can be rotated randomly.
    out = {k: [resource(f"assets/states/{k}.gif")] for k in STATE_NAMES}
    out["report"] = [resource("assets/states/report.webp")]
    return out


def _asset_list(value):
    if isinstance(value, list):
        return [str(x) for x in value if x]
    if isinstance(value, str) and value:
        return [value]
    return []


def default_config():
    return {
        "config_version": 18,
        "always_on_top": True,
        "click_through": False,
        "lock_position": False,
        "opacity": 100,
        "pet_width": 280,
        "x": 1200,
        "y": 500,
        "last_state": "idle",
        "transition_ms": 220,
        "hotkeys": DEFAULT_HOTKEYS.copy(),
        "assets": bundled_assets(),
        "report_font_path": "",
        "report_duration_ms": 10000,
        "report_layouts": {},
        "mouse_interaction": {
            "enabled": True,
            "attention_radius": 1.85,
            "interaction_radius": 1.18,
            "enter_delay_ms": 260,
            "inner_enter_delay_ms": 120,
            "exit_delay_ms": 900,
            "idle_timeout_ms": 12000,
            "poll_interval_ms": 20,
            "smoothing": 0.18,
            "eye_x_px": 3.2,
            "eye_y_px": 2.0,
            "head_x_px": 8.5,
            "head_y_px": 5.0,
            "body_x_px": 3.2,
            "body_y_px": 1.7,
            "front_x_px": 6.4,
            "front_y_px": 3.6,
            "back_x_px": 2.4,
            "back_y_px": 1.8,
            "head_rot_deg": 4.2,
            "body_rot_deg": 1.5,
            "front_rot_deg": 4.6,
            "back_rot_deg": 1.9,
            "pupil_reduce_when_head_turn": 0.80,
        },
        "voice": {
            "enabled": True,
            "voice_id": "",
            "speed": 1.0,
            "test_text": "美丽美丽，我在呢。今天又想让我陪你干嘛？",
        },
        "updates": {
            "enabled": True,
            "manifest_url": "",
            "auto_check": True,
        },
        "vision": {
            "enabled": True,
            "scan_interval_ms": 350,
            "mode": "ultra_low",
            "pause_when_background": True,
            "low_hp_threshold": 50,
            "alive_threshold": 0.74,
            "kill_threshold": 0.78,
            "result_threshold": 0.75,
            "kill_show_ms": 1400,
            "result_show_ms": 2800,
            "player_nickname": "",
            "ocr_interval_ms": 650,
            "nickname_ocr_fallback": True,
            "prefer_dxcam": True,
            "context_threshold": 2,
            "death_fallback_seconds": 2.2,
            # HP stability guard: a single bad frame must never trigger LOW_HP.
            "hp_vote_window": 5,
            "hp_enter_votes": 3,
            "hp_exit_votes": 3,
            "hp_exit_margin": 10,
            "hp_min_conf": 0.56,
            "hp_occlusion_guard": True,
            "report_enabled": True,
            # V0.4.9.9 report watcher: OCR still sleeps during the live match.
            # After the live HUD disappears we enter a long-lived, low-power
            # layout wait (~2 Hz).  Only after a result-like frame appears do we
            # temporarily switch to a short burst scanner for cleaner retries.
            "report_scan_interval_ms": 1400,
            "report_wait_interval_ms": 450,  # legacy key retained for old configs
            "report_wait_fast_interval_ms": 100,
            "report_wait_slow_interval_ms": 850,
            "report_wait_fast_seconds": 20,
            "report_capture_interval_ms": 160,
            "report_capture_window_ms": 3000,
            "report_settle_min_hits": 2,
            "report_settle_min_candidate_hits": 2,
            "report_settle_diff_threshold": 2.6,
            "report_candidate_cache_seconds": 2.8,
        },
    }


def _is_user_asset(path_value):
    if not path_value:
        return False
    try:
        p = Path(path_value)
        return CACHE_DIR in p.parents or p.parent == CACHE_DIR
    except Exception:
        return False


def load_config():
    cfg = default_config()
    old_data = {}
    if CONFIG_FILE.exists():
        try:
            old_data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        except Exception:
            LOGGER.exception("读取配置失败，使用默认配置")
            old_data = {}

    # General fields.
    for k, v in old_data.items():
        if k in ("hotkeys", "assets", "vision", "mouse_interaction", "voice", "updates"):
            continue
        if k in cfg:
            cfg[k] = v

    # Migrate hotkeys. New six-state layout gets clean defaults unless a matching key exists.
    old_hk = old_data.get("hotkeys", {}) if isinstance(old_data.get("hotkeys"), dict) else {}
    for k in cfg["hotkeys"]:
        if k in old_hk:
            cfg["hotkeys"][k] = str(old_hk[k] or "")

    # Migrate old single-asset configs into V0.4 pools. User clips are kept,
    # while old built-in placeholders are replaced by the new bundled placeholder.
    old_assets = old_data.get("assets", {}) if isinstance(old_data.get("assets"), dict) else {}
    aliases = {
        "idle": ("idle",),
        "low_hp": ("low_hp",),
        "kill": ("kill", "happy"),
        "dead": ("dead",),
        "victory": ("victory", "celebrate"),
        "defeat": ("defeat", "angry"),
        "report": ("report",),
    }
    for new_key, old_keys in aliases.items():
        migrated = []
        for old_key in old_keys:
            for item in _asset_list(old_assets.get(old_key)):
                if _is_user_asset(item) and Path(item).exists() and item not in migrated:
                    migrated.append(item)
        if migrated:
            cfg["assets"][new_key] = migrated[:MAX_ASSETS_PER_STATE]

    old_mouse = old_data.get("mouse_interaction", {}) if isinstance(old_data.get("mouse_interaction"), dict) else {}
    cfg["mouse_interaction"].update({k: v for k, v in old_mouse.items() if k in cfg["mouse_interaction"]})
    try:
        old_ver = int(old_data.get("config_version", 0) or 0)
    except Exception:
        old_ver = 0
    if old_ver < 15:
        cfg["mouse_interaction"]["eye_x_px"] = 3.0
        cfg["mouse_interaction"]["eye_y_px"] = 1.8

    old_voice = old_data.get("voice", {}) if isinstance(old_data.get("voice"), dict) else {}
    cfg["voice"].update({k: v for k, v in old_voice.items() if k in cfg["voice"]})

    old_updates = old_data.get("updates", {}) if isinstance(old_data.get("updates"), dict) else {}
    cfg["updates"].update({k: v for k, v in old_updates.items() if k in cfg["updates"]})

    old_vision = old_data.get("vision", {}) if isinstance(old_data.get("vision"), dict) else {}
    cfg["vision"].update({k: v for k, v in old_vision.items() if k in cfg["vision"]})
    if cfg["vision"].get("mode") == "low_power":
        cfg["vision"]["mode"] = "ultra_low"
    # V0.4.10.2 migration: old configs must not keep the slower 200ms + 4-hit
    # settle rule, otherwise a user who clicks Continue within ~0.5s can escape
    # before the result frame is owned by XiaoMeili.
    try:
        old_ver = int(old_data.get("config_version", 0) or 0)
    except Exception:
        old_ver = 0
    if old_ver < 13:
        cfg["vision"]["report_wait_fast_interval_ms"] = 100
        cfg["vision"]["report_settle_min_hits"] = 2
        cfg["vision"]["report_settle_min_candidate_hits"] = 2
        cfg["vision"]["report_settle_diff_threshold"] = 2.6
        cfg["vision"]["report_candidate_cache_seconds"] = 2.8

    locked = bool(old_data.get("click_through", False) or old_data.get("lock_position", False))
    cfg["click_through"] = locked
    cfg["lock_position"] = locked
    if cfg.get("last_state") not in STATE_NAMES:
        cfg["last_state"] = "idle"
    return cfg


def save_config(cfg):
    try:
        CONFIG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        LOGGER.exception("保存配置失败")


REPORT_FONT_FILENAME = "MaokenAssortedSans-Lite.otf"
REPORT_FONT_DIR = USER / "fonts"
REPORT_FONT_DIR.mkdir(parents=True, exist_ok=True)
REPORT_FONT_LOCAL = REPORT_FONT_DIR / REPORT_FONT_FILENAME
THUMB_DIR = USER / "thumbnails"
THUMB_DIR.mkdir(parents=True, exist_ok=True)


def maybe_adopt_report_font(cfg):
    """Find the user's Maoken font once without bundling it with XiaoMeili.
    The selected font is copied into XiaoMeiliData so future EXE upgrades keep it.
    """
    current = str(cfg.get("report_font_path", "") or "").strip()
    if current and Path(current).exists():
        return current
    if REPORT_FONT_LOCAL.exists():
        cfg["report_font_path"] = str(REPORT_FONT_LOCAL)
        save_config(cfg)
        return str(REPORT_FONT_LOCAL)
    if sys.platform == "win32":
        home = Path(os.environ.get("USERPROFILE") or Path.home())
        candidates = [
            home / "Downloads" / REPORT_FONT_FILENAME,
            home / "Desktop" / REPORT_FONT_FILENAME,
            home / "Documents" / REPORT_FONT_FILENAME,
        ]
        for src in candidates:
            try:
                if src.exists():
                    shutil.copy2(src, REPORT_FONT_LOCAL)
                    cfg["report_font_path"] = str(REPORT_FONT_LOCAL)
                    save_config(cfg)
                    LOGGER.info("自动找到并导入战报字体: %s", src)
                    return str(REPORT_FONT_LOCAL)
            except Exception:
                LOGGER.exception("自动导入战报字体失败: %s", src)
    return ""


def report_evaluation(kills):
    k = max(0, int(kills))
    if k <= 5:
        return "不愧是医者，不愿杀生是吗？"
    if k <= 15:
        return "你不配做我美丽的徒弟！"
    if k <= 25:
        return "我将收你为关门弟子，但只能看大门。"
    return "我的两成功力如何？"


def asset_thumbnail(path_value, size=96):
    """Create/cached PNG preview from first frame of an imported animation."""
    try:
        src = Path(path_value)
        if not src.exists():
            return None
        key = f"{src.stem}_{int(src.stat().st_mtime)}_{src.stat().st_size}.png"
        out = THUMB_DIR / key
        if out.exists():
            return str(out)
        im = Image.open(src)
        try:
            im.seek(0)
            frame = im.convert("RGBA")
            frame.thumbnail((size, size), Image.Resampling.LANCZOS)
            canvas = Image.new("RGBA", (size, size), (246, 246, 246, 255))
            x = (size - frame.width) // 2
            y = (size - frame.height) // 2
            canvas.alpha_composite(frame, (x, y))
            canvas.save(out, "PNG")
        finally:
            try: im.close()
            except Exception: pass
        return str(out)
    except Exception:
        LOGGER.exception("生成素材缩略图失败: %s", path_value)
        return None


def save_rgba_gif(frames, dst, duration=67):
    pal_frames = []
    for frame in frames:
        im = frame.convert("RGBA")
        alpha = im.getchannel("A")
        pal = im.convert("RGB").quantize(colors=255, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
        palette = pal.getpalette()[:255 * 3] + [0, 0, 0]
        pal.putpalette(palette)
        mask = alpha.point(lambda x: 255 if x < 72 else 0)
        pal.paste(255, mask=mask)
        pal.info["transparency"] = 255
        pal.info["disposal"] = 2
        pal_frames.append(pal)
    pal_frames[0].save(
        dst, save_all=True, append_images=pal_frames[1:], duration=duration,
        loop=0, transparency=255, disposal=2, optimize=False
    )


def set_windows_app_identity():
    """Give Windows a stable app identity so the taskbar/settings window uses
    the XiaoMeili icon instead of grouping under Python/pythonw.
    """
    if sys.platform != "win32":
        return
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("XiaoMeili.DesktopPet.V0_6")
    except Exception:
        LOGGER.exception("设置 Windows AppUserModelID 失败")


class Bridge(QObject):
    trigger_state = Signal(str)
    open_settings = Signal()
    toggle_lock = Signal()
    show_hide = Signal()


class HotkeyManager:
    def __init__(self, bridge: Bridge):
        self.bridge = bridge
        self.registered = []

    def unregister_all(self):
        try:
            keyboard.unhook_all_hotkeys()
        except Exception:
            LOGGER.exception("清理全局快捷键失败")
        self.registered = []

    def register(self, cfg):
        self.unregister_all()
        hk = cfg.get("hotkeys", {})
        callbacks = {
            "idle": lambda: self.bridge.trigger_state.emit("idle"),
            "low_hp": lambda: self.bridge.trigger_state.emit("low_hp"),
            "kill": lambda: self.bridge.trigger_state.emit("kill"),
            "dead": lambda: self.bridge.trigger_state.emit("dead"),
            "victory": lambda: self.bridge.trigger_state.emit("victory"),
            "defeat": lambda: self.bridge.trigger_state.emit("defeat"),
            "toggle_lock": lambda: self.bridge.toggle_lock.emit(),
            "settings": lambda: self.bridge.open_settings.emit(),
            "show_hide": lambda: self.bridge.show_hide.emit(),
        }
        for key, cb in callbacks.items():
            combo = str(hk.get(key, "")).strip().lower()
            if not combo:
                continue
            try:
                keyboard.add_hotkey(combo, cb, suppress=False, trigger_on_release=False)
                self.registered.append(combo)
            except Exception:
                LOGGER.exception("注册快捷键失败: %s=%s", key, combo)
        LOGGER.info("已注册快捷键: %s", self.registered)


class HelpBadge(QPushButton):
    def __init__(self, help_text, parent=None):
        super().__init__("?", parent)
        self.setFixedSize(20, 20)
        self.setCursor(Qt.CursorShape.WhatsThisCursor)
        self.setToolTip(help_text)
        self.setStyleSheet(
            "QPushButton{border:1px solid #b7b7b7;border-radius:10px;background:#f7f7f7;color:#555;font-weight:700;}"
            "QPushButton:hover{background:#e9f7f3;border-color:#53bba6;color:#18745f;}"
        )
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)


class ReportTextOverlay(QWidget):
    """Cached report lettering painted over the stationary report whiteboard."""
    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.cfg=cfg; self.kill_count=None; self.evaluation=""; self.asset_path=None
        self.font_family="Microsoft YaHei"; self._cache=QPixmap()
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents,True)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground,True)
        self.hide(); self.reload_font()

    def reload_font(self):
        family=None; font_path=str(self.cfg.get("report_font_path","") or "")
        if font_path and Path(font_path).exists():
            try:
                fid=QFontDatabase.addApplicationFont(font_path)
                if fid>=0:
                    fams=QFontDatabase.applicationFontFamilies(fid); family=fams[0] if fams else None
            except Exception: LOGGER.exception("加载战报字体失败: %s",font_path)
        if not family:
            try:
                fams=set(QFontDatabase.families())
                for candidate in ("MaokenAssortedSans-Lite","猫啃什锦黑-轻量版"):
                    if candidate in fams: family=candidate; break
            except Exception: pass
        self.font_family=family or "Microsoft YaHei"; self._rebuild_cache()

    def set_asset(self,path):
        self.asset_path=str(path or ""); self._rebuild_cache()

    def set_report(self,kills,evaluation):
        self.kill_count=max(0,int(kills)); self.evaluation=str(evaluation or "")
        self.reload_font(); self.show(); self.raise_(); self._rebuild_cache(); self.update()

    def clear_report(self):
        self.kill_count=None; self.evaluation=""; self._cache=QPixmap(); self.hide()

    def _rebuild_cache(self):
        if self.kill_count is None or self.width()<=0 or self.height()<=0: return
        layout=get_report_layout(self.cfg,self.asset_path)
        self._cache=render_report_text_pixmap(self.width(),self.height(),layout,self.kill_count,self.evaluation,self.font_family)
        self.update()

    def resizeEvent(self,event):
        super().resizeEvent(event); self._rebuild_cache()

    def paintEvent(self,event):
        if self.kill_count is None or self._cache.isNull(): return
        p=QPainter(self); p.drawPixmap(0,0,self._cache); p.end()


class MouseInteractionLayer(QWidget):
    """Continuous layered XiaoMeili driven by global mouse position.

    V2 abandons any discrete direction sprite switching.  The same PSD-derived
    layered XiaoMeili is driven continuously by mouse position: pupils react
    first, then head, then body, while hair and earrings trail slightly behind.
    """
    ASSET_FILES = {
        "back": "hair_back.png",
        "body": "body.png",
        "head": "head.png",
        "brows": "brows.png",
        "eye_l": "eye_white_left.png",
        "eye_r": "eye_white_right.png",
        "pupil_l": "pupil_left.png",
        "pupil_r": "pupil_right.png",
        "blink_l": "blink_left.png",
        "blink_r": "blink_right.png",
        "mask_l": "eye_mask_left.png",
        "mask_r": "eye_mask_right.png",
        "front": "hair_front.png",
        "ear_l": "earring_left.png",
        "ear_r": "earring_right.png",
    }

    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.pix = {}
        for key, filename in self.ASSET_FILES.items():
            p = resource(f"assets/mouse_interaction/{filename}")
            pm = QPixmap(p)
            if pm.isNull():
                LOGGER.error("鼠标互动图层加载失败: %s", p)
            self.pix[key] = pm

        self.target_x = 0.0
        self.target_y = 0.0
        self.look_x = 0.0
        self.look_y = 0.0
        self.body_x = self.body_y = 0.0
        self.head_x = self.head_y = 0.0
        self.front_x = self.front_y = 0.0
        self.back_x = self.back_y = 0.0
        self.ear_x = self.ear_y = 0.0
        self.head_vel_x = 0.0
        self.head_vel_y = 0.0

        self.blinking = False
        self.blink_until = 0.0
        self.next_blink = time.monotonic() + random.uniform(2.8, 5.2)

    def set_target(self, nx, ny):
        self.target_x = max(-1.0, min(1.0, float(nx)))
        self.target_y = max(-1.0, min(1.0, float(ny)))

    def reset_pose(self):
        self.target_x = self.target_y = 0.0
        self.look_x = self.look_y = 0.0
        self.body_x = self.body_y = 0.0
        self.head_x = self.head_y = 0.0
        self.front_x = self.front_y = 0.0
        self.back_x = self.back_y = 0.0
        self.ear_x = self.ear_y = 0.0
        self.head_vel_x = self.head_vel_y = 0.0
        self.blinking = False
        self.blink_until = 0.0
        self.next_blink = time.monotonic() + random.uniform(2.8, 5.2)
        self.update()

    def force_blink(self):
        now = time.monotonic()
        self.blinking = True
        self.blink_until = now + 0.13
        self.next_blink = now + random.uniform(2.5, 4.8)
        self.update()

    @staticmethod
    def _follow(current, target, smooth):
        return current + (target - current) * smooth

    def step(self, now=None):
        now = time.monotonic() if now is None else float(now)
        micfg = self.cfg.get("mouse_interaction", {})
        smooth = max(0.05, min(0.55, float(micfg.get("smoothing", 0.18))))
        base_mul = 1.35 if abs(self.target_x) + abs(self.target_y) < 0.08 else 1.0

        self.look_x = self._follow(self.look_x, self.target_x, smooth * 1.15 * base_mul)
        self.look_y = self._follow(self.look_y, self.target_y, smooth * 1.08 * base_mul)

        prev_head_x, prev_head_y = self.head_x, self.head_y
        self.head_x = self._follow(self.head_x, self.look_x, 0.28 * base_mul)
        self.head_y = self._follow(self.head_y, self.look_y, 0.24 * base_mul)
        # Body intentionally reacts less and a little slower, so the pet feels like
        # she shifts her weight after the eyes/head have already looked.
        self.body_x = self._follow(self.body_x, self.look_x * 0.58, 0.15 * base_mul)
        self.body_y = self._follow(self.body_y, self.look_y * 0.42, 0.13 * base_mul)
        # Front hair stays close to the head but still drags slightly.
        self.front_x = self._follow(self.front_x, self.head_x, 0.20 * base_mul)
        self.front_y = self._follow(self.front_y, self.head_y, 0.18 * base_mul)
        # Ponytail / back hair should feel heavier.
        self.back_x = self._follow(self.back_x, self.head_x * 0.72, 0.11 * base_mul)
        self.back_y = self._follow(self.back_y, self.head_y * 0.70, 0.10 * base_mul)
        # Earrings are the loosest pieces; they pick up a bit of inertia.
        self.ear_x = self._follow(self.ear_x, self.head_x, 0.12 * base_mul)
        self.ear_y = self._follow(self.ear_y, self.head_y, 0.12 * base_mul)

        self.head_vel_x = self.head_x - prev_head_x
        self.head_vel_y = self.head_y - prev_head_y

        if self.blinking and now >= self.blink_until:
            self.blinking = False
            self.next_blink = now + random.uniform(2.8, 5.5)
        elif not self.blinking and now >= self.next_blink:
            self.blinking = True
            self.blink_until = now + random.uniform(0.105, 0.145)
        self.update()

    def _draw_layer(self, painter, key, dx=0.0, dy=0.0):
        pm = self.pix.get(key)
        if pm is None or pm.isNull():
            return
        target = QRectF(float(dx), float(dy), float(self.width()), float(self.height()))
        source = QRectF(0.0, 0.0, float(pm.width()), float(pm.height()))
        painter.drawPixmap(target, pm, source)

    def _draw_pixmap_transformed(self, painter, pixmap, dx=0.0, dy=0.0, rot_deg=0.0, scale_x=1.0, scale_y=1.0, pivot=(0.5, 0.5)):
        if pixmap is None or pixmap.isNull():
            return
        px = float(self.width()) * float(pivot[0])
        py = float(self.height()) * float(pivot[1])
        painter.save()
        painter.translate(px + float(dx), py + float(dy))
        if rot_deg:
            painter.rotate(float(rot_deg))
        if scale_x != 1.0 or scale_y != 1.0:
            painter.scale(float(scale_x), float(scale_y))
        painter.translate(-px, -py)
        target = QRectF(0.0, 0.0, float(self.width()), float(self.height()))
        source = QRectF(0.0, 0.0, float(pixmap.width()), float(pixmap.height()))
        painter.drawPixmap(target, pixmap, source)
        painter.restore()

    def _draw_layer_transformed(self, painter, key, dx=0.0, dy=0.0, rot_deg=0.0, scale_x=1.0, scale_y=1.0, pivot=(0.5, 0.5)):
        self._draw_pixmap_transformed(painter, self.pix.get(key), dx, dy, rot_deg, scale_x, scale_y, pivot)

    def _draw_clipped_pupil(self, painter, pupil_key, mask_key, pupil_dx, pupil_dy, mask_dx, mask_dy):
        pupil = self.pix.get(pupil_key); mask = self.pix.get(mask_key)
        if pupil is None or pupil.isNull() or mask is None or mask.isNull():
            return
        temp = QImage(max(1, self.width()), max(1, self.height()), QImage.Format.Format_RGBA8888)
        temp.fill(Qt.GlobalColor.transparent)
        tp = QPainter(temp)
        tp.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        target = QRectF(float(pupil_dx), float(pupil_dy), float(self.width()), float(self.height()))
        source = QRectF(0.0, 0.0, float(pupil.width()), float(pupil.height()))
        tp.drawPixmap(target, pupil, source)
        tp.setCompositionMode(QPainter.CompositionMode.CompositionMode_DestinationIn)
        mt = QRectF(float(mask_dx), float(mask_dy), float(self.width()), float(self.height()))
        ms = QRectF(0.0, 0.0, float(mask.width()), float(mask.height()))
        tp.drawPixmap(mt, mask, ms)
        tp.end()
        painter.drawImage(0, 0, temp)

    @staticmethod
    def _qimage_rgba_array(image):
        image = image.convertToFormat(QImage.Format.Format_RGBA8888)
        h, w = image.height(), image.width()
        bpl = image.bytesPerLine()
        arr = np.frombuffer(image.bits(), dtype=np.uint8, count=image.sizeInBytes())
        arr = arr.reshape((h, bpl // 4, 4))[:, :w, :].copy()
        return arr

    def _compose_head_group(self, eye_dx, eye_dy, ear_dx, ear_dy):
        img = QImage(max(1, self.width()), max(1, self.height()), QImage.Format.Format_RGBA8888)
        img.fill(Qt.GlobalColor.transparent)
        p = QPainter(img)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        self._draw_layer(p, "head", 0.0, 0.0)
        self._draw_layer(p, "brows", 0.0, 0.0)
        self._draw_layer(p, "ear_l", ear_dx, ear_dy)
        self._draw_layer(p, "ear_r", ear_dx, ear_dy)
        if self.blinking:
            self._draw_layer(p, "blink_l", 0.0, 0.0)
            self._draw_layer(p, "blink_r", 0.0, 0.0)
        else:
            self._draw_layer(p, "eye_l", 0.0, 0.0)
            self._draw_layer(p, "eye_r", 0.0, 0.0)
            self._draw_clipped_pupil(p, "pupil_l", "mask_l", eye_dx, eye_dy, 0.0, 0.0)
            self._draw_clipped_pupil(p, "pupil_r", "mask_r", eye_dx, eye_dy, 0.0, 0.0)
        p.end()
        return img

    def paintEvent(self, event):
        if self.width() <= 0 or self.height() <= 0:
            return
        micfg = self.cfg.get("mouse_interaction", {})
        sx = self.width() / 280.0
        sy = self.height() / max(1.0, 280.0 * 660.0 / 620.0)

        body_dx = self.body_x * float(micfg.get("body_x_px", 3.2)) * sx
        body_dy = self.body_y * float(micfg.get("body_y_px", 1.7)) * sy
        head_dx = self.head_x * float(micfg.get("head_x_px", 8.5)) * sx
        head_dy = self.head_y * float(micfg.get("head_y_px", 5.0)) * sy
        front_dx = self.front_x * float(micfg.get("front_x_px", 6.4)) * sx
        front_dy = self.front_y * float(micfg.get("front_y_px", 3.6)) * sy
        back_dx = self.back_x * float(micfg.get("back_x_px", 2.4)) * sx
        back_dy = self.back_y * float(micfg.get("back_y_px", 1.8)) * sy

        body_rot = self.body_x * float(micfg.get("body_rot_deg", 1.5))
        head_rot = self.head_x * float(micfg.get("head_rot_deg", 4.2)) + self.head_y * 0.7
        front_rot = self.front_x * float(micfg.get("front_rot_deg", 4.6)) + self.head_vel_x * 14.0
        back_rot = self.back_x * float(micfg.get("back_rot_deg", 1.9)) - self.head_vel_x * 10.0

        pupil_reduce = max(0.35, min(1.0, float(micfg.get("pupil_reduce_when_head_turn", 0.80))))
        pupil_gain = 1.0 - (1.0 - pupil_reduce) * min(1.0, abs(self.head_x))
        eye_dx = self.look_x * float(micfg.get("eye_x_px", 3.2)) * sx * pupil_gain
        eye_dy = self.look_y * float(micfg.get("eye_y_px", 2.0)) * sy * pupil_gain
        ear_dx = (self.ear_x * 2.4 + self.head_vel_x * 9.0) * sx
        ear_dy = (self.ear_y * 1.3 + self.head_vel_y * 4.0) * sy

        body_scale_x = 1.0 - abs(self.body_x) * 0.012
        body_scale_y = 1.0 + max(-self.body_y, 0.0) * 0.010 - max(self.body_y, 0.0) * 0.006
        head_scale_y = 1.0 + max(-self.head_y, 0.0) * 0.018 - max(self.head_y, 0.0) * 0.010
        front_scale_y = 1.0 + max(-self.front_y, 0.0) * 0.010

        head_img = self._compose_head_group(eye_dx, eye_dy, ear_dx, ear_dy)

        canvas = QImage(self.width(), self.height(), QImage.Format.Format_RGBA8888)
        canvas.fill(Qt.GlobalColor.transparent)
        cp = QPainter(canvas)
        cp.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        self._draw_layer_transformed(cp, "back", back_dx, back_dy, back_rot, 1.0, 1.0, pivot=(0.50, 0.46))
        self._draw_layer_transformed(cp, "body", body_dx, body_dy, body_rot, body_scale_x, body_scale_y, pivot=(0.50, 0.82))
        self._draw_pixmap_transformed(cp, QPixmap.fromImage(head_img), head_dx, head_dy, head_rot, 1.0, head_scale_y, pivot=(0.50, 0.60))
        self._draw_layer_transformed(cp, "front", front_dx, front_dy, front_rot, 1.0, front_scale_y, pivot=(0.50, 0.58))
        cp.end()

        rgba = self._qimage_rgba_array(canvas)
        rgba = _add_soft_white_glow(rgba, outline_px=1, glow_px=4,
                                    outline_strength=0.42, glow_strength=0.24)
        rgba = np.ascontiguousarray(rgba)
        final_img = QImage(rgba.data, rgba.shape[1], rgba.shape[0], rgba.strides[0],
                           QImage.Format.Format_RGBA8888).copy()
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        p.drawImage(0, 0, final_img)
        p.end()


class LockBubble(QWidget):
    clicked = Signal()

    def __init__(self):
        super().__init__(None)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool | Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setFixedSize(38, 38)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(2, 2, 2, 2)
        self.btn = QPushButton("🔒")
        self.btn.setFixedSize(34, 34)
        self.btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn.setStyleSheet(
            "QPushButton { background: rgba(18,24,28,220); color: white; border: 1px solid rgba(64,220,194,210); "
            "border-radius: 17px; font-size: 17px; } "
            "QPushButton:hover { background: rgba(25,44,45,235); border: 1px solid rgba(93,255,224,255); }"
        )
        self.btn.clicked.connect(self.clicked.emit)
        lay.addWidget(self.btn)
        self.hide()

    def set_locked(self, locked: bool):
        self.btn.setText("🔒" if locked else "🔓")
        self.btn.setToolTip("当前：已锁定（固定位置 + 点击穿透），点击可解锁" if locked else "当前：已解锁（可拖动 / 可右键），点击可锁定")


class PetWindow(QWidget):
    request_settings = Signal()
    config_changed = Signal()

    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self.drag_offset = None
        self.current_state = None
        self.current_slot = 0
        self.anim_group = None
        self.movies = [None, None]
        self.current_asset_path = None
        self.last_asset_by_state = {}
        self.movie_generation = 0
        self.mouse_interaction_active = False
        self._mouse_inside_since = None
        self._mouse_outside_since = None
        self._mouse_last_pos = None
        self._mouse_last_move_time = time.monotonic()
        self._mouse_transition_group = None
        self.lock_bubble = LockBubble()
        self.lock_bubble.clicked.connect(self.toggle_interaction_lock)
        self.lock_bubble.set_locked(bool(self.cfg.get("click_through", False)))
        self._hover_last_seen = 0.0
        self._hit_image = QImage(resource("assets/xiaomeili_base.png"))

        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setWindowTitle(APP_NAME)
        self.setWindowIcon(QIcon(resource("assets/xiaomeili_icon.png")))
        self.apply_window_flags(first=True)

        self.stack = QStackedLayout(self)
        self.stack.setStackingMode(QStackedLayout.StackingMode.StackAll)
        self.stack.setContentsMargins(0, 0, 0, 0)
        self.labels, self.effects = [], []
        for i in range(2):
            lab = QLabel(self)
            lab.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lab.setScaledContents(True)
            eff = QGraphicsOpacityEffect(lab)
            eff.setOpacity(1.0 if i == 0 else 0.0)
            lab.setGraphicsEffect(eff)
            self.stack.addWidget(lab)
            self.labels.append(lab)
            self.effects.append(eff)

        self.mouse_layer = MouseInteractionLayer(self.cfg, self)
        self.mouse_layer.setGeometry(0, 0, self.width(), self.height())
        self.mouse_effect = QGraphicsOpacityEffect(self.mouse_layer)
        self.mouse_effect.setOpacity(0.0)
        self.mouse_layer.setGraphicsEffect(self.mouse_effect)
        self.mouse_layer.hide()

        self.report_overlay = ReportTextOverlay(self.cfg, self)
        self.report_active = False
        self.report_timer = QTimer(self)
        self.report_timer.setSingleShot(True)
        self.report_timer.timeout.connect(self._end_report)

        self.setWindowOpacity(max(0.2, min(1.0, self.cfg.get("opacity", 100) / 100.0)))
        self.resize_pet()
        self.move(int(self.cfg.get("x", 1200)), int(self.cfg.get("y", 500)))
        self.ensure_on_screen()
        self.play_state(self.cfg.get("last_state", "idle"), immediate=True)

        self.hover_timer = QTimer(self)
        self.hover_timer.setInterval(70)
        self.hover_timer.timeout.connect(self.poll_hover_lock_button)
        self.hover_timer.start()

        self.mouse_interaction_timer = QTimer(self)
        self.mouse_interaction_timer.setInterval(max(20, min(80, int(self.cfg.get("mouse_interaction", {}).get("poll_interval_ms", 33)))))
        self.mouse_interaction_timer.timeout.connect(self.poll_mouse_interaction)
        self.mouse_interaction_timer.start()

    def apply_window_flags(self, first=False):
        flags = Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool
        if self.cfg.get("always_on_top", True):
            flags |= Qt.WindowType.WindowStaysOnTopHint
        self.setWindowFlags(flags)
        if not first:
            self.show()
        QTimer.singleShot(30, self.apply_clickthrough_native)

    def apply_clickthrough_native(self):
        if sys.platform != "win32" or not self.winId():
            return
        try:
            hwnd = int(self.winId())
            GWL_EXSTYLE = -20
            WS_EX_LAYERED = 0x00080000
            WS_EX_TRANSPARENT = 0x00000020
            user32 = ctypes.windll.user32
            style = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
            style |= WS_EX_LAYERED
            if self.cfg.get("click_through", False):
                style |= WS_EX_TRANSPARENT
            else:
                style &= ~WS_EX_TRANSPARENT
            user32.SetWindowLongW(hwnd, GWL_EXSTYLE, style)
            LOGGER.info("点击穿透=%s", self.cfg.get("click_through", False))
        except Exception:
            LOGGER.exception("切换点击穿透失败")

    def resize_pet(self):
        w = int(self.cfg.get("pet_width", 280))
        h = int(w * 660 / 620)
        self.setFixedSize(w, h)
        for lab in self.labels:
            lab.setFixedSize(w, h)
        if hasattr(self, "mouse_layer"):
            self.mouse_layer.setGeometry(0, 0, w, h)
        if hasattr(self, "report_overlay"):
            # Overlay spans the whole pet canvas; each report asset owns a normalized
            # whiteboard rectangle in report_layouts.
            self.report_overlay.setGeometry(0, 0, w, h)
            self.report_overlay.raise_()

    def ensure_on_screen(self):
        try:
            screen = QApplication.primaryScreen()
            if not screen:
                return
            area = screen.availableGeometry()
            if not area.intersects(self.frameGeometry()):
                margin = 40
                x = max(area.left() + margin, area.right() - self.width() - margin)
                y = max(area.top() + margin, area.bottom() - self.height() - margin)
                self.move(x, y)
                self.cfg["x"], self.cfg["y"] = x, y
                save_config(self.cfg)
        except Exception:
            LOGGER.exception("检查桌宠位置失败")

    def _state_pool(self, state):
        pool = _asset_list(self.cfg.get("assets", {}).get(state))
        pool = [p for p in pool if Path(p).exists()]
        if not pool:
            pool = _asset_list(bundled_assets().get(state))
        return pool[:MAX_ASSETS_PER_STATE]

    def _pick_asset(self, state):
        pool = self._state_pool(state)
        if not pool:
            return None
        # V0.4.8 retains independent random draw WITH replacement.  Do not exclude the
        # previously played clip. This intentionally allows sequences such as
        # 1→1→2, 2→2→1, 3→3→2, etc. Every clip gets the same probability on
        # every draw, including the clip that just finished.
        path = ASSET_RNG.choice(pool)
        self.last_asset_by_state[state] = path
        return path

    def set_asset(self, label_idx, path, state):
        movie = QMovie(path)
        movie.setCacheMode(QMovie.CacheMode.CacheAll)
        movie.setScaledSize(self.size())
        if not movie.isValid():
            raise RuntimeError(f"动画素材无效: {path}")
        self.movie_generation += 1
        token = self.movie_generation
        # Imported WebP clips are finite. When one finishes, choose another clip
        # from the same state pool. Stale movies are ignored via generation token.
        movie.finished.connect(lambda tok=token, st=state: self._movie_finished(tok, st))
        self.movies[label_idx] = movie
        self.labels[label_idx].setMovie(movie)
        self.current_asset_path = path
        if state == "report" and hasattr(self, "report_overlay"):
            self.report_overlay.set_asset(path)
        movie.start()

    def _movie_finished(self, token, state):
        if token != self.movie_generation or state != self.current_state:
            return
        if state == "report":
            # The 10-second report lifetime is controlled by report_timer.
            return
        if len(self._state_pool(state)) <= 1:
            # Finite one-clip pool: replay the same clip without changing state.
            QTimer.singleShot(25, lambda st=state: self.play_state(st, force_new_clip=True, immediate=True))
        else:
            QTimer.singleShot(25, lambda st=state: self.play_state(st, force_new_clip=True))

    def _set_mouse_layer_visible(self, visible, fade_ms=180):
        if self._mouse_transition_group:
            try: self._mouse_transition_group.stop()
            except Exception: pass
        fade_ms = max(0, int(fade_ms))
        if visible:
            self.mouse_layer.show(); self.mouse_layer.raise_()
            self.report_overlay.raise_()
            self.mouse_effect.setOpacity(0.0 if fade_ms else 1.0)
            if fade_ms <= 0:
                self.effects[self.current_slot].setOpacity(0.0)
                return
            old = self.current_slot
            a1 = QPropertyAnimation(self.effects[old], b"opacity")
            a1.setDuration(fade_ms); a1.setStartValue(self.effects[old].opacity()); a1.setEndValue(0.0)
            a2 = QPropertyAnimation(self.mouse_effect, b"opacity")
            a2.setDuration(fade_ms); a2.setStartValue(self.mouse_effect.opacity()); a2.setEndValue(1.0)
            grp = QParallelAnimationGroup(self); grp.addAnimation(a1); grp.addAnimation(a2)
            def done():
                if self.movies[old]: self.movies[old].stop()
            grp.finished.connect(done); self._mouse_transition_group = grp; grp.start()
        else:
            self.mouse_effect.setOpacity(0.0)
            self.mouse_layer.hide()

    def _enter_mouse_interaction(self):
        if self.mouse_interaction_active or self.current_state != "idle" or self.report_active:
            return
        if not bool(self.cfg.get("mouse_interaction", {}).get("enabled", True)):
            return
        self.mouse_interaction_active = True
        self.mouse_layer.reset_pose()
        self._set_mouse_layer_visible(True, 180)
        LOGGER.info("鼠标互动进入：注意力区域触发")

    def _exit_mouse_interaction(self, resume_idle=True):
        if not self.mouse_interaction_active:
            return
        self.mouse_interaction_active = False
        self._mouse_inside_since = None
        self._mouse_outside_since = None
        self.mouse_layer.set_target(0.0, 0.0)
        if not resume_idle:
            self._set_mouse_layer_visible(False, 0)
            return
        # Prepare a fresh random idle clip behind the interaction layer, then cross-fade.
        path = self._pick_asset("idle")
        if not path:
            self._set_mouse_layer_visible(False, 0); return
        try:
            new = 1 - self.current_slot
            self.set_asset(new, path, "idle")
            self.effects[new].setOpacity(0.0)
            self.labels[new].show()
            if self._mouse_transition_group:
                try: self._mouse_transition_group.stop()
                except Exception: pass
            a1 = QPropertyAnimation(self.mouse_effect, b"opacity")
            a1.setDuration(180); a1.setStartValue(self.mouse_effect.opacity()); a1.setEndValue(0.0)
            a2 = QPropertyAnimation(self.effects[new], b"opacity")
            a2.setDuration(180); a2.setStartValue(0.0); a2.setEndValue(1.0)
            grp = QParallelAnimationGroup(self); grp.addAnimation(a1); grp.addAnimation(a2)
            def done():
                self.mouse_layer.hide(); self.current_slot = new
                self.effects[1-new].setOpacity(0.0)
            grp.finished.connect(done); self._mouse_transition_group = grp; grp.start()
            self.current_state = "idle"
            self.cfg["last_state"] = "idle"
            save_config(self.cfg)
            LOGGER.info("鼠标互动退出：恢复随机待机素材")
        except Exception:
            LOGGER.exception("鼠标互动退出失败")
            self._set_mouse_layer_visible(False, 0)

    def refresh_mouse_interaction_config(self):
        interval = max(20, min(80, int(self.cfg.get("mouse_interaction", {}).get("poll_interval_ms", 33))))
        if hasattr(self, "mouse_interaction_timer"):
            self.mouse_interaction_timer.setInterval(interval)
        if not bool(self.cfg.get("mouse_interaction", {}).get("enabled", True)) and self.mouse_interaction_active:
            self._exit_mouse_interaction(resume_idle=True)

    def poll_mouse_interaction(self):
        try:
            micfg = self.cfg.get("mouse_interaction", {})
            if not bool(micfg.get("enabled", True)) or not self.isVisible():
                if self.mouse_interaction_active: self._exit_mouse_interaction(resume_idle=True)
                return
            if self.drag_offset is not None:
                if self.mouse_interaction_active: self._exit_mouse_interaction(resume_idle=True)
                return
            if self.report_active or self.current_state != "idle":
                if self.mouse_interaction_active: self._exit_mouse_interaction(resume_idle=False)
                return
            now = time.monotonic()
            pos = QCursor.pos()
            if self._mouse_last_pos is None:
                self._mouse_last_pos = pos
            moved = (pos - self._mouse_last_pos).manhattanLength() >= 2
            if moved:
                self._mouse_last_move_time = now
                self._mouse_last_pos = pos

            fg = self.frameGeometry(); c = fg.center()
            dx = float(pos.x() - c.x()); dy = float(pos.y() - c.y())
            # Elliptical normalized distance: 1.0 is roughly one pet-width/height from center.
            ux = dx / max(1.0, self.width() * 0.55)
            uy = dy / max(1.0, self.height() * 0.55)
            dist = (ux*ux + uy*uy) ** 0.5
            outer = max(1.15, min(2.8, float(micfg.get("attention_radius", 1.75))))
            inner = max(0.65, min(outer-0.05, float(micfg.get("interaction_radius", 1.10))))
            inside_outer = dist <= outer
            inside_inner = dist <= inner

            if not self.mouse_interaction_active:
                if inside_outer and moved:
                    if self._mouse_inside_since is None: self._mouse_inside_since = now
                    need = int(micfg.get("inner_enter_delay_ms" if inside_inner else "enter_delay_ms", 120 if inside_inner else 320)) / 1000.0
                    if now - self._mouse_inside_since >= need:
                        self._enter_mouse_interaction()
                elif not inside_outer:
                    self._mouse_inside_since = None
            else:
                # Track continuously. Eye/head motion is continuous, not discrete animation switching.
                tx = max(-1.0, min(1.0, ux / max(inner, 1e-6)))
                ty = max(-1.0, min(1.0, uy / max(inner, 1e-6)))
                self.mouse_layer.set_target(tx, ty)
                self.mouse_layer.step(now)

                if inside_outer:
                    self._mouse_outside_since = None
                else:
                    if self._mouse_outside_since is None: self._mouse_outside_since = now
                    if now - self._mouse_outside_since >= int(micfg.get("exit_delay_ms", 700))/1000.0:
                        self._exit_mouse_interaction(resume_idle=True); return

                idle_timeout = max(2000, int(micfg.get("idle_timeout_ms", 10000))) / 1000.0
                if now - self._mouse_last_move_time >= idle_timeout:
                    self._exit_mouse_interaction(resume_idle=True); return
        except Exception:
            LOGGER.exception("鼠标互动轮询失败")

    def play_state(self, state, immediate=False, force_new_clip=False, asset_override=None):
        if state not in STATE_NAMES:
            return
        if self.report_active and state != "report":
            return
        if self.mouse_interaction_active:
            if state == "idle" and not force_new_clip and not immediate:
                return
            if state != "idle":
                # Game reactions/report always outrank mouse interaction.
                self._exit_mouse_interaction(resume_idle=False)
                immediate = True
        if state == self.current_state and not immediate and not force_new_clip:
            return
        path = str(asset_override) if asset_override and Path(str(asset_override)).exists() else self._pick_asset(state)
        if not path:
            LOGGER.error("状态素材池为空: %s", state)
            return
        try:
            next_slot = self.current_slot if immediate and self.current_state is None else 1 - self.current_slot
            self.set_asset(next_slot, path, state)
            if immediate or self.current_state is None:
                self.effects[next_slot].setOpacity(1.0)
                self.effects[1 - next_slot].setOpacity(0.0)
                old = 1 - next_slot
                if self.movies[old]:
                    self.movies[old].stop()
                self.current_slot = next_slot
            else:
                if self.anim_group:
                    self.anim_group.stop()
                old, new = self.current_slot, next_slot
                a1 = QPropertyAnimation(self.effects[old], b"opacity")
                a1.setDuration(int(self.cfg.get("transition_ms", 220)))
                a1.setStartValue(self.effects[old].opacity())
                a1.setEndValue(0.0)
                a1.setEasingCurve(QEasingCurve.Type.InOutQuad)
                a2 = QPropertyAnimation(self.effects[new], b"opacity")
                a2.setDuration(int(self.cfg.get("transition_ms", 220)))
                a2.setStartValue(self.effects[new].opacity())
                a2.setEndValue(1.0)
                a2.setEasingCurve(QEasingCurve.Type.InOutQuad)
                grp = QParallelAnimationGroup(self)
                grp.addAnimation(a1); grp.addAnimation(a2)
                def done():
                    if self.movies[old]:
                        self.movies[old].stop()
                    self.current_slot = new
                grp.finished.connect(done)
                self.anim_group = grp
                grp.start()
            self.current_state = state
            self.cfg["last_state"] = state
            save_config(self.cfg)
            LOGGER.info("切换状态 -> %s | 素材=%s", STATE_NAMES[state], Path(path).name)
        except Exception:
            LOGGER.exception("播放状态失败: %s", state)

    def show_report(self, data):
        try:
            kills = int(data.get("kills", 0))
            evaluation = str(data.get("evaluation") or report_evaluation(kills))
            if self.mouse_interaction_active:
                self._exit_mouse_interaction(resume_idle=False)
            self.report_active = True
            self.play_state("report", force_new_clip=True)
            self.report_overlay.set_asset(self.current_asset_path)
            self.report_overlay.set_report(kills, evaluation)
            self.report_overlay.raise_()
            duration = max(3000, int(self.cfg.get("report_duration_ms", 10000)))
            self.report_timer.start(duration)
            LOGGER.info("显示整局战报 | nickname=%s agent=%s kills=%s eval=%s", data.get("nickname"), data.get("agent"), kills, evaluation)
        except Exception:
            LOGGER.exception("显示整局战报失败")

    def _end_report(self):
        self.report_active = False
        self.report_overlay.clear_report()
        self.play_state("idle", force_new_clip=True, immediate=True)

    def _cursor_hits_pet_shape(self, global_pos):
        if not self.isVisible() or not self.frameGeometry().contains(global_pos):
            return False
        if self._hit_image.isNull():
            return True
        local = global_pos - self.frameGeometry().topLeft()
        ix = int(local.x() * self._hit_image.width() / max(1, self.width()))
        iy = int(local.y() * self._hit_image.height() / max(1, self.height()))
        ix = max(0, min(self._hit_image.width() - 1, ix))
        iy = max(0, min(self._hit_image.height() - 1, iy))
        return self._hit_image.pixelColor(ix, iy).alpha() > 18

    def _position_lock_bubble(self):
        self.lock_bubble.move(self.x() + self.width() - self.lock_bubble.width() - 10, self.y() + 10)
        self.lock_bubble.raise_()

    def poll_hover_lock_button(self):
        try:
            pos = QCursor.pos()
            over_pet = self._cursor_hits_pet_shape(pos)
            over_bubble = self.lock_bubble.isVisible() and self.lock_bubble.frameGeometry().adjusted(-6, -6, 6, 6).contains(pos)
            now = time.monotonic()
            if over_pet or over_bubble:
                self._hover_last_seen = now
                self._position_lock_bubble()
                self.lock_bubble.set_locked(bool(self.cfg.get("click_through", False)))
                if not self.lock_bubble.isVisible():
                    self.lock_bubble.show(); self.lock_bubble.raise_()
            elif self.lock_bubble.isVisible() and now - self._hover_last_seen > 0.35:
                self.lock_bubble.hide()
        except Exception:
            LOGGER.exception("悬停锁定按钮刷新失败")

    def set_interaction_lock(self, locked):
        locked = bool(locked)
        self.cfg["click_through"] = locked
        self.cfg["lock_position"] = locked
        save_config(self.cfg)
        self.apply_clickthrough_native()
        self.lock_bubble.set_locked(locked)
        self.config_changed.emit()

    def toggle_interaction_lock(self):
        self.set_interaction_lock(not bool(self.cfg.get("click_through", False)))

    def toggle_show_hide(self):
        if self.isVisible():
            self.lock_bubble.hide(); self.hide()
        else:
            self.show(); self.raise_(); self.activateWindow()

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton and not self.cfg.get("lock_position", False) and not self.cfg.get("click_through", False):
            if self.mouse_interaction_active:
                self._exit_mouse_interaction(resume_idle=True)
            self.drag_offset = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if self.drag_offset is not None and event.buttons() & Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self.drag_offset)
            event.accept()

    def mouseReleaseEvent(self, event):
        if self.drag_offset is not None:
            self.drag_offset = None
            self.cfg["x"], self.cfg["y"] = self.x(), self.y()
            save_config(self.cfg)

    def contextMenuEvent(self, event):
        if self.cfg.get("click_through", False):
            return
        menu = QMenu(self)
        showhide = menu.addAction("显示/隐藏")
        settings = menu.addAction("设置")
        chosen = menu.exec(event.globalPos())
        if chosen == showhide:
            self.toggle_show_hide()
        elif chosen == settings:
            self.request_settings.emit()

    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton and not self.cfg.get("click_through", False):
            self.request_settings.emit()


# ------------------------------
# VALORANT screen-only recognition
# ------------------------------

def _find_valorant_client_rect():
    """Return screen-space client rect (x, y, w, h) for the largest visible VALORANT window."""
    if sys.platform != "win32":
        return None
    user32 = ctypes.windll.user32
    candidates = []
    WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    class POINT(ctypes.Structure):
        _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]

    class RECT(ctypes.Structure):
        _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long), ("right", ctypes.c_long), ("bottom", ctypes.c_long)]

    @WNDENUMPROC
    def enum_proc(hwnd, lparam):
        try:
            if not user32.IsWindowVisible(hwnd) or user32.IsIconic(hwnd):
                return True
            length = user32.GetWindowTextLengthW(hwnd)
            if length <= 0:
                return True
            buf = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, buf, length + 1)
            title = buf.value.strip()
            if "VALORANT" not in title.upper():
                return True
            rc = RECT()
            if not user32.GetClientRect(hwnd, ctypes.byref(rc)):
                return True
            p = POINT(0, 0)
            if not user32.ClientToScreen(hwnd, ctypes.byref(p)):
                return True
            w, h = rc.right - rc.left, rc.bottom - rc.top
            if w >= 800 and h >= 450:
                candidates.append((w * h, p.x, p.y, w, h, title))
        except Exception:
            pass
        return True

    user32.EnumWindows(enum_proc, 0)
    if not candidates:
        return None
    candidates.sort(reverse=True)
    _, x, y, w, h, title = candidates[0]
    return (x, y, w, h, title)


def _trim_and_normalize_game(frame):
    """Trim obvious black bars and center-crop to a 16:9 gameplay viewport."""
    if frame is None or frame.size == 0:
        return frame
    img = frame
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    h, w = gray.shape

    # Trim only very obvious near-black pillar/letterbox bars. Limit to 12% per side.
    def left_cut():
        lim = int(w * 0.12)
        for x in range(lim):
            col = gray[:, x]
            if np.percentile(col, 90) > 20:
                return max(0, x - 1)
        return 0
    def right_cut():
        lim = int(w * 0.12)
        for d in range(lim):
            col = gray[:, w - 1 - d]
            if np.percentile(col, 90) > 20:
                return max(0, d - 1)
        return 0
    lc, rc = left_cut(), right_cut()
    if lc > 4 or rc > 4:
        img = img[:, lc:w - rc if rc else w]

    h, w = img.shape[:2]
    target = 16 / 9
    ar = w / max(1, h)
    if ar > target + 0.02:
        nw = int(h * target)
        x = max(0, (w - nw) // 2)
        img = img[:, x:x + nw]
    elif ar < target - 0.02:
        nh = int(w / target)
        y = max(0, (h - nh) // 2)
        img = img[y:y + nh, :]
    return img


def _match_multiscale(gray, templ, scales):
    best_score, best_loc, best_size = -1.0, (0, 0), (0, 0)
    for s in scales:
        tw = max(8, int(round(templ.shape[1] * s)))
        th = max(8, int(round(templ.shape[0] * s)))
        if gray.shape[1] < tw or gray.shape[0] < th:
            continue
        interp = cv2.INTER_AREA if s < 1 else cv2.INTER_CUBIC
        t = cv2.resize(templ, (tw, th), interpolation=interp)
        res = cv2.matchTemplate(gray, t, cv2.TM_CCOEFF_NORMED)
        _, score, _, loc = cv2.minMaxLoc(res)
        if score > best_score:
            best_score, best_loc, best_size = float(score), loc, (tw, th)
    return best_score, best_loc, best_size


def _roi(frame, box):
    h, w = frame.shape[:2]
    x1, y1, x2, y2 = box
    return frame[int(h * y1):int(h * y2), int(w * x1):int(w * x2)]


def _scan_gray_template(frame, templ, box, scales):
    r = _roi(frame, box)
    if r.size == 0:
        return 0.0
    gray = cv2.cvtColor(r, cv2.COLOR_BGR2GRAY)
    return _match_multiscale(gray, templ, scales)[0]


def _scan_binary_template(frame, templ, box, scales, white_threshold=220):
    r = _roi(frame, box)
    if r.size == 0:
        return 0.0
    gray = cv2.cvtColor(r, cv2.COLOR_BGR2GRAY)
    bw = (gray > white_threshold).astype(np.uint8) * 255
    return _match_multiscale(bw, templ, scales)[0]


def _template_detection_count(frame, templ, box, threshold):
    """Count distinct own-kill rows in the killfeed using NMS over multiple scales."""
    r = _roi(frame, box)
    if r.size == 0:
        return 0, 0.0
    gray = cv2.cvtColor(r, cv2.COLOR_BGR2GRAY)
    detections = []
    best_score = 0.0
    for s in np.linspace(0.70, 1.40, 15):
        tw = max(12, int(round(templ.shape[1] * s)))
        th = max(8, int(round(templ.shape[0] * s)))
        if gray.shape[1] < tw or gray.shape[0] < th:
            continue
        t = cv2.resize(templ, (tw, th), interpolation=cv2.INTER_AREA if s < 1 else cv2.INTER_CUBIC)
        res = cv2.matchTemplate(gray, t, cv2.TM_CCOEFF_NORMED)
        best_score = max(best_score, float(res.max()))
        ys, xs = np.where(res >= threshold)
        # cap candidates per scale
        if len(xs) > 50:
            vals = res[ys, xs]
            idx = np.argsort(vals)[-50:]
            xs, ys = xs[idx], ys[idx]
        for x, y in zip(xs, ys):
            detections.append((int(x), int(y), tw, th, float(res[y, x])))
    detections.sort(key=lambda d: d[4], reverse=True)
    kept = []
    for d in detections:
        x, y, w, h, score = d
        cx, cy = x + w / 2, y + h / 2
        duplicate = False
        for k in kept:
            kx, ky, kw, kh, _ = k
            kcx, kcy = kx + kw / 2, ky + kh / 2
            if abs(cx - kcx) < min(w, kw) * 0.55 and abs(cy - kcy) < min(h, kh) * 0.65:
                duplicate = True
                break
        if not duplicate:
            kept.append(d)
    return min(5, len(kept)), best_score


class DigitReader:
    def __init__(self, npz_path):
        data = np.load(npz_path)
        self.bank = {str(i): data[f"d{i}"] for i in range(10)}

    @staticmethod
    def _normalize(mask, target=(32, 48)):
        ys, xs = np.where(mask > 0)
        if len(xs) == 0:
            return np.zeros((target[1], target[0]), np.uint8)
        crop = mask[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
        tw, th = target
        scale = min((tw - 4) / max(1, crop.shape[1]), (th - 4) / max(1, crop.shape[0]))
        nw = max(1, int(round(crop.shape[1] * scale)))
        nh = max(1, int(round(crop.shape[0] * scale)))
        rs = cv2.resize(crop, (nw, nh), interpolation=cv2.INTER_NEAREST)
        out = np.zeros((th, tw), np.uint8)
        x, y = (tw - nw) // 2, (th - nh) // 2
        out[y:y + nh, x:x + nw] = rs
        return out

    @staticmethod
    def _score(glyph, templates):
        g = (glyph > 0).astype(np.float32)
        gf = g.ravel()
        scores = []
        for t in templates:
            b = (t > 0).astype(np.float32)
            inter = float((g * b).sum())
            union = float(((g + b) > 0).sum())
            iou = inter / union if union else 0.0
            bf = b.ravel()
            gs, bs = gf.std(), bf.std()
            corr = 0.0 if gs < 1e-6 or bs < 1e-6 else float(np.corrcoef(gf, bf)[0, 1])
            scores.append(0.55 * iou + 0.45 * corr)
        return max(scores) if scores else 0.0

    def read_hp_roi(self, r):
        if r is None or r.size == 0:
            return None, 0.0
        gray = cv2.cvtColor(r, cv2.COLOR_BGR2GRAY)
        _, bw = cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY)
        n, labels, stats, _ = cv2.connectedComponentsWithStats(bw, 8)
        comps = []
        for i in range(1, n):
            x, y, w, h, area = stats[i]
            density = area / max(1, w * h)
            if h >= r.shape[0] * 0.28 and area >= 50 and w >= 3 and density >= 0.16:
                comps.append((x, y, w, h, area))
        comps.sort(key=lambda c: c[0])
        # Keep plausible digit groups only and discard low-density HUD lines.
        if len(comps) > 3:
            comps = sorted(comps, key=lambda c: c[4], reverse=True)[:3]
            comps.sort(key=lambda c: c[0])
        if not (1 <= len(comps) <= 3):
            return None, 0.0

        digits, confidences = [], []
        for x, y, w, h, area in comps:
            glyph = self._normalize(bw[y:y + h, x:x + w])
            ranked = []
            for d, templates in self.bank.items():
                ranked.append((self._score(glyph, templates), d))
            ranked.sort(reverse=True)
            best, second = ranked[0], ranked[1]
            # Confidence combines shape fit and separation from runner-up.
            conf = max(0.0, min(1.0, best[0] * 0.85 + max(0.0, best[0] - second[0]) * 0.6))
            digits.append(best[1]); confidences.append(conf)
        try:
            value = int("".join(digits))
        except Exception:
            return None, 0.0
        conf = min(confidences) if confidences else 0.0
        if value < 0 or value > 100 or conf < 0.44:
            return None, conf
        return value, conf


    def read_hp(self, frame):
        # Compatibility path for offline validation/debug frames.
        r = _roi(frame, ROI_HP)
        return self.read_hp_roi(r)


ROI_CONTEXT_LEFT = (0.190, 0.018, 0.230, 0.082)
ROI_CONTEXT_CENTER = (0.450, 0.005, 0.550, 0.120)
ROI_CONTEXT_RIGHT = (0.770, 0.018, 0.810, 0.082)
ROI_ALIVE = (0.145, 0.00, 0.505, 0.145)
ROI_HP = (0.303, 0.915, 0.347, 0.970)
ROI_KILL_PROBE = (0.70, 0.02, 1.00, 0.20)
ROI_KILL_OCR = (0.60, 0.02, 1.00, 0.23)
ROI_RESULT = (0.35, 0.08, 0.65, 0.35)
ROI_DEATH_REPORT = (0.775, 0.300, 0.995, 0.735)
# Whole-match result screen: five player cards + red Continue button.
# Low-resolution radar crop. Keep it small and cheap; it is never OCR'd.
ROI_REPORT_CARDS_RADAR = (0.090, 0.500, 0.910, 0.770)
# High-resolution parse crop. It deliberately starts higher so the nickname row
# and K/D/A row are both present in the frozen snapshot.
ROI_REPORT_CARDS = (0.090, 0.420, 0.910, 0.740)
ROI_REPORT_CONTINUE = (0.410, 0.840, 0.590, 0.940)


def _find_valorant_window():
    """Return (hwnd, x, y, w, h, title) for the largest visible VALORANT client window."""
    if sys.platform != "win32":
        return None
    user32 = ctypes.windll.user32
    candidates = []
    WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    class POINT(ctypes.Structure):
        _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]

    class RECT(ctypes.Structure):
        _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long), ("right", ctypes.c_long), ("bottom", ctypes.c_long)]

    @WNDENUMPROC
    def enum_proc(hwnd, lparam):
        try:
            if not user32.IsWindowVisible(hwnd) or user32.IsIconic(hwnd):
                return True
            length = user32.GetWindowTextLengthW(hwnd)
            if length <= 0:
                return True
            buf = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, buf, length + 1)
            title = buf.value.strip()
            if "VALORANT" not in title.upper():
                return True
            rc = RECT()
            if not user32.GetClientRect(hwnd, ctypes.byref(rc)):
                return True
            pt = POINT(0, 0)
            if not user32.ClientToScreen(hwnd, ctypes.byref(pt)):
                return True
            w, h = rc.right - rc.left, rc.bottom - rc.top
            if w >= 800 and h >= 450:
                candidates.append((w * h, int(hwnd), pt.x, pt.y, w, h, title))
        except Exception:
            pass
        return True

    user32.EnumWindows(enum_proc, 0)
    if not candidates:
        return None
    candidates.sort(reverse=True)
    _, hwnd, x, y, w, h, title = candidates[0]
    return hwnd, x, y, w, h, title


def _client_rect_for_hwnd(hwnd):
    if sys.platform != "win32" or not hwnd:
        return None
    try:
        user32 = ctypes.windll.user32
        if not user32.IsWindow(hwnd) or not user32.IsWindowVisible(hwnd) or user32.IsIconic(hwnd):
            return None

        class POINT(ctypes.Structure):
            _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]

        class RECT(ctypes.Structure):
            _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long), ("right", ctypes.c_long), ("bottom", ctypes.c_long)]

        rc = RECT()
        if not user32.GetClientRect(hwnd, ctypes.byref(rc)):
            return None
        pt = POINT(0, 0)
        if not user32.ClientToScreen(hwnd, ctypes.byref(pt)):
            return None
        w, h = rc.right - rc.left, rc.bottom - rc.top
        if w < 800 or h < 450:
            return None
        return pt.x, pt.y, w, h
    except Exception:
        return None


def _viewport_from_client(client_rect):
    """Map a possibly letterboxed/pillarboxed client area to its centered 16:9 game viewport."""
    x, y, w, h = client_rect
    target = 16.0 / 9.0
    ar = w / max(1.0, h)
    if ar > target + 0.005:
        vw = int(round(h * target))
        return x + (w - vw) // 2, y, vw, h
    if ar < target - 0.005:
        vh = int(round(w / target))
        return x, y + (h - vh) // 2, w, vh
    return x, y, w, h


class ScreenGrabber:
    """Small-region screen grabber. Prefer DXGI Desktop Duplication (dxcam) on Windows,
    and fall back to MSS. We never start a continuous capture thread; each request is a
    single tiny ROI grab, which keeps idle cost near zero.
    """
    def __init__(self, prefer_dxcam=True):
        self.backend = "mss"
        self.camera = None
        self.sct = None
        if sys.platform == "win32" and prefer_dxcam:
            try:
                import dxcam
                self.camera = dxcam.create(output_color="BGR")
                self.backend = "dxcam"
                LOGGER.info("截图后端：DXGI Desktop Duplication (dxcam)")
            except Exception:
                LOGGER.warning("dxcam 不可用，回退 MSS ROI 截图", exc_info=True)
                self.camera = None
        if self.camera is None:
            from mss import mss
            self.sct = mss()
            self.backend = "mss"
            LOGGER.info("截图后端：MSS ROI")

    def grab(self, left, top, width, height):
        width=max(2,int(width)); height=max(2,int(height))
        left=int(left); top=int(top)
        if self.camera is not None:
            frame=self.camera.grab(region=(left, top, left+width, top+height))
            if frame is not None:
                return np.asarray(frame, dtype=np.uint8)
        if self.sct is None:
            from mss import mss
            self.sct=mss(); self.backend="mss"
        shot=np.asarray(self.sct.grab({"left":left,"top":top,"width":width,"height":height}), dtype=np.uint8)
        return cv2.cvtColor(shot, cv2.COLOR_BGRA2BGR)

    def close(self):
        try:
            if self.camera is not None:
                self.camera.stop()
        except Exception:
            pass
        try:
            if self.sct is not None:
                self.sct.close()
        except Exception:
            pass


def _grab_relative_roi(grabber, viewport, box, target_size=None):
    vx, vy, vw, vh = viewport
    x1, y1, x2, y2 = box
    left = int(round(vx + vw * x1))
    top = int(round(vy + vh * y1))
    width = max(2, int(round(vw * (x2 - x1))))
    height = max(2, int(round(vh * (y2 - y1))))
    img = grabber.grab(left, top, width, height)
    if img is None or img.size == 0:
        return np.zeros((2,2,3), np.uint8)
    if target_size and (img.shape[1], img.shape[0]) != tuple(target_size):
        img = cv2.resize(img, tuple(target_size), interpolation=cv2.INTER_AREA)
    return img


def _killfeed_green_signature(img):
    """Cheap event probe: count green/cyan killfeed row bands without OCR."""
    if img is None or img.size == 0:
        return (0, ()), 0.0
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(hsv)
    mask = ((h >= 35) & (h <= 100) & (s >= 70) & (v >= 80)).astype(np.uint8)
    row_density = mask.mean(axis=1)
    active = row_density > 0.03
    centers = []
    start = None
    for i, val in enumerate(active):
        if val and start is None:
            start = i
        if (not val or i == len(active) - 1) and start is not None:
            end = i if not val else i + 1
            if end - start >= 2:
                centers.append(int(round((start + end) / 2 / max(1, len(active)) * 20)))
            start = None
    sig = (len(centers), tuple(centers))
    return sig, float(row_density.max()) if len(row_density) else 0.0


class VisionWorker(QThread):
    state_requested = Signal(str)
    report_ready = Signal(object)
    snapshot = Signal(object)

    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self._stop_event = threading.Event()
        self._debug_event = threading.Event()

        # Preload only tiny templates. All matching is confined to HUD ROIs.
        alive = cv2.imread(resource("assets/vision/sage_alive.png"), cv2.IMREAD_GRAYSCALE)
        alive_alt = cv2.imread(resource("assets/vision/sage_alive_alt.png"), cv2.IMREAD_GRAYSCALE)
        kill = cv2.imread(resource("assets/vision/own_kill_segment.png"), cv2.IMREAD_GRAYSCALE)
        win = cv2.imread(resource("assets/vision/victory_mask.png"), cv2.IMREAD_GRAYSCALE)
        loss = cv2.imread(resource("assets/vision/defeat_mask.png"), cv2.IMREAD_GRAYSCALE)
        ctx = cv2.imread(resource("assets/vision/match_center_mask.png"), cv2.IMREAD_GRAYSCALE)
        base_alive = cv2.resize(alive, None, fx=0.80, fy=0.80, interpolation=cv2.INTER_AREA)
        self.alive_templates = [
            cv2.resize(base_alive, None, fx=s, fy=s, interpolation=cv2.INTER_AREA)
            for s in (0.90, 1.00, 1.10)
        ]
        if alive_alt is not None:
            alt_base = cv2.resize(alive_alt, None, fx=0.79, fy=0.79, interpolation=cv2.INTER_AREA)
            self.alive_templates.extend([
                cv2.resize(alt_base, None, fx=s, fy=s, interpolation=cv2.INTER_AREA)
                for s in (0.92, 1.00, 1.08)
            ])
        self.kill_portrait_t = cv2.resize(kill[:, :48], None, fx=0.80, fy=0.80, interpolation=cv2.INTER_AREA)
        self.win_t = cv2.resize(win, None, fx=0.80, fy=0.80, interpolation=cv2.INTER_NEAREST)
        self.loss_t = cv2.resize(loss, None, fx=0.825, fy=0.825, interpolation=cv2.INTER_NEAREST)
        self.context_center_t = (ctx > 0).astype(np.uint8)
        self.digit_reader = DigitReader(resource("assets/vision/hp_digit_templates.npz"))

        # High-level phase gate. No death/HP/kill decision is legal outside MATCH_CONTEXT.
        self.match_context = False
        self.context_hits = 0
        self.context_misses = 0
        self.context_left_score = 0.0
        self.context_center_score = 0.0
        self.context_right_score = 0.0
        self.context_votes = 0
        self.match_recent_until = 0.0
        self.phase = "OUT_OF_MATCH"

        self.last_snapshot = {}
        self.alive_state = None
        self.ever_alive = False
        self.alive_hits = 0
        self.alive_misses = 0
        self.low_hits = 0
        self.low_state = False
        self.last_valid_hp = None
        self.last_hp_time = 0.0
        # V0.4.8: HP is decided by a rolling vote, not a single read.
        self.hp_history = []
        self.hp_enter_votes = 0
        self.hp_exit_votes = 0
        self.hp_occluded = False
        self.hp_guard_reason = "-"
        self.hp_last_confirmed = None
        self.win_latched = False
        self.loss_latched = False
        self.round_end = False
        self.current_display_state = "idle"
        self.transient_until = 0.0
        self.pending_result = None

        # Death is a two-stage decision: portrait disappears -> suspected -> evidence/fallback.
        self.death_suspect_since = None
        self.death_latched = False
        self.death_ocr_checked = False
        self.last_death_report_score = 0.0
        self.last_death_evidence = "-"

        self.hwnd = None
        self.window_title = ""
        self.last_window_lookup = 0.0
        self.background_since = None
        self.last_snapshot_emit = 0.0

        self.last_alive_score = 0.0
        self.last_hp = None
        self.last_hp_conf = 0.0
        self.last_kill_score = 0.0
        self.last_kill_count = 0
        self.last_nickname_match = "-"
        self.last_ocr_texts = []
        self.last_win_score = 0.0
        self.last_loss_score = 0.0
        self.last_kill_signature = (0, ())
        self.last_kill_probe_strength = 0.0
        self.last_kill_event_time = 0.0
        self.last_hp_probe = None
        self.last_hp_full_read = 0.0

        self.ocr_trigger_count = 0
        self.hp_read_count = 0
        self.next_context = self.next_alive = self.next_hp = self.next_kill = self.next_result = self.next_death = 0.0

        self.perf_wall = time.monotonic()
        self.perf_cpu = time.process_time()
        self.perf_scans = 0
        self.scan_fps = 0.0
        self.cpu_estimate = 0.0
        self.backend_name = "pending"
        self.timings = {k:0.0 for k in ("capture","context","alive","hp","kill","death","result","ocr")}
        self.worker_busy = False
        self.skipped_cycles = 0

        # Whole-match report scanner. It sleeps during live rounds and runs only
        # after a real match has been registered and the live HUD has disappeared.
        self.report_armed = False
        self.report_armed_since = 0.0
        self.report_last_live_seen = 0.0
        self.report_done = False
        self.report_candidate_hits = 0
        self.report_attempts = 0
        self.report_retry_after = 0.0
        self.next_report = 0.0
        self.session_sage_seen = False
        self.last_report_layout_score = 0.0
        self.last_report_nickname = "-"
        self.last_report_agent = "-"
        self.last_report_kills = None
        self.report_pending_kills = None
        self.report_kill_confirm_hits = 0
        # V0.4.9.9: post-match report uses two stages.  During the live match
        # report OCR is fully asleep.  Once the live HUD disappears we keep only
        # a low-frequency, layout-only sentinel alive.  A convincing result frame
        # is frozen immediately; a short burst scanner is used only if the first
        # frozen frame cannot be parsed cleanly.
        self.report_waiting_result = False
        self.report_wait_started = 0.0
        self.report_wait_samples = 0
        self.report_capture_active = False
        self.report_capture_started = 0.0
        self.report_capture_deadline = 0.0
        self.report_snapshot_locked = False
        self.report_snapshot_score = 0.0
        self.report_capture_samples = 0
        self.report_capture_best_score = 0.0
        self.report_capture_best_cards = None
        # V0.4.9.9: snapshot ownership is independent from OCR success. Once a
        # result page has been frozen, parsing can fail without throwing away the
        # user's only copy of that short-lived screen.
        self.report_snapshot_cards = None
        self.report_snapshot_full = None
        self.report_snapshot_locked_at = 0.0
        # V0.4.10.2: as soon as a genuine five-card result page appears, keep
        # the best native-resolution frame in memory immediately. Stability is
        # now only a confirmation step, not a prerequisite for owning the frame.
        self.report_best_candidate_cards = None
        self.report_best_candidate_full = None
        self.report_best_candidate_quality = 0.0
        self.report_best_candidate_at = 0.0
        self.report_best_candidate_counts = []
        self.report_candidate_signature = None
        self.report_candidate_stable_hits = 0
        self.report_last_signature_diff = 0.0
        self.report_parse_status = "等待结算页"
        self.report_parse_attempts = 0
        self.report_ocr_engine = None
        self.report_ocr_init_failed = False
        self.last_report_debug_dir = ""

    def stop(self):
        self._stop_event.set()

    def request_debug_frame(self):
        self._debug_event.set()

    def _ema_timing(self, key, ms):
        old=float(self.timings.get(key,0.0))
        self.timings[key] = ms if old <= 0 else old*0.82 + ms*0.18

    @staticmethod
    def _fixed_match(gray, templ):
        if gray is None or templ is None or gray.shape[0] < templ.shape[0] or gray.shape[1] < templ.shape[1]:
            return 0.0
        return float(cv2.minMaxLoc(cv2.matchTemplate(gray, templ, cv2.TM_CCOEFF_NORMED))[1])

    def _multi_match(self, gray, templates):
        best = 0.0
        for templ in templates:
            best = max(best, self._fixed_match(gray, templ))
        return best

    def _request_state(self, state, reason=""):
        if state not in STATE_NAMES:
            return
        if state != self.current_display_state:
            self.current_display_state = state
            LOGGER.info("视觉识别触发 -> %s | %s", STATE_NAMES[state], reason)
            self.state_requested.emit(state)

    def _persistent_state(self):
        if not self.match_context:
            return "idle"
        if self.round_end:
            return "idle"
        if self.death_latched:
            return "dead"
        if self.alive_state is True and self.low_state:
            return "low_hp"
        return "idle"

    def _reset_match_state(self, reason=""):
        self.alive_state = None
        self.ever_alive = False
        self.alive_hits = 0
        self.alive_misses = 0
        self.low_hits = 0
        self.low_state = False
        self.last_hp = None
        self.last_hp_conf = 0.0
        self.last_hp_probe = None
        self.hp_history = []
        self.hp_enter_votes = 0
        self.hp_exit_votes = 0
        self.hp_occluded = False
        self.hp_guard_reason = "-"
        self.hp_last_confirmed = None
        self.death_suspect_since = None
        self.death_latched = False
        self.death_ocr_checked = False
        self.last_death_report_score = 0.0
        self.last_death_evidence = "-"
        self.round_end = False
        self.phase = "OUT_OF_MATCH"
        self.pending_result = None
        if self.current_display_state not in ("victory", "defeat") or time.monotonic() >= self.transient_until:
            self.transient_until = 0.0
            self._request_state("idle", reason or "outside match")

    @staticmethod
    def _norm_name(text):
        text = str(text or "").strip().lower()
        return re.sub(r"[\s\-_.·•#丨|:：\[\]()（）{}<>《》]+", "", text)

    @staticmethod
    def _name_similarity(a, b):
        a = VisionWorker._norm_name(a); b = VisionWorker._norm_name(b)
        if not a or not b:
            return 0.0
        if a in b or b in a:
            return min(1.0, min(len(a), len(b)) / max(1, max(len(a), len(b))) + 0.35)
        return SequenceMatcher(None, a, b).ratio()

    def _get_report_ocr_engine(self):
        """Create RapidOCR once and reuse it inside the vision worker thread."""
        if self.report_ocr_engine is not None:
            return self.report_ocr_engine
        if self.report_ocr_init_failed:
            return None
        try:
            from rapidocr import RapidOCR
            self.report_ocr_engine = RapidOCR()
            LOGGER.info("RapidOCR 战报引擎初始化完成（复用模式）")
            return self.report_ocr_engine
        except Exception:
            self.report_ocr_init_failed = True
            LOGGER.exception("RapidOCR 战报引擎初始化失败")
            return None

    def _ocr_names_once(self, kill_roi, want="killer"):
        nickname = str(self.cfg.get("vision", {}).get("player_nickname", "")).strip()
        if not nickname or not bool(self.cfg.get("vision",{}).get("nickname_ocr_fallback", True)):
            return False, "未启用昵称二次校验"
        t0=time.perf_counter(); engine=self._get_report_ocr_engine()
        try:
            if engine is None:
                return False, "OCR引擎不可用"
            self.ocr_trigger_count += 1
            roi2 = cv2.resize(kill_roi, None, fx=1.15, fy=1.15, interpolation=cv2.INTER_LINEAR)
            result = engine(roi2)
            boxes = getattr(result, "boxes", None); txts = getattr(result, "txts", None); scores = getattr(result, "scores", None)
            if txts is None or boxes is None:
                self.last_ocr_texts=[]; return False, "未识别到文字"
            target=self._norm_name(nickname); debug=[]; rw=roi2.shape[1]
            hit=False
            for i, txt in enumerate(list(txts)):
                score=float(scores[i]) if scores is not None and i < len(scores) else 1.0
                if score < 0.42: continue
                box=np.array(boxes[i],dtype=np.float32); cx=float(box[:,0].mean())/max(1.0,rw)
                sim=self._name_similarity(target,txt); debug.append(f"{txt}@{cx:.2f}/{sim:.2f}")
                if sim < 0.66: continue
                if want == "killer" and cx < 0.66:
                    hit=True
                if want == "victim" and cx > 0.62:
                    hit=True
            self.last_ocr_texts=debug[:10]
            return hit, ("命中" if hit else "未命中")
        except Exception as e:
            LOGGER.exception("昵称 OCR 二次校验失败")
            return False, f"OCR错误:{type(e).__name__}"
        finally:
            self._ema_timing("ocr", (time.perf_counter()-t0)*1000)

    def _ocr_own_kill_once(self, kill_roi):
        hit, desc = self._ocr_names_once(kill_roi, "killer")
        return (1 if hit else 0), desc

    def _mode_intervals(self):
        mode=str(self.cfg.get("vision",{}).get("mode","ultra_low"))
        if mode == "debug":
            return 0.35, 0.45, 0.25, 0.18, 0.35, 0.22, 0.35
        # context, identity, HP hash, killfeed probe, result, death-confirm, UI emit
        return 0.65, 0.85, 0.34, 0.32, 0.80, 0.30, 0.75

    def _update_perf(self, now):
        dt=now-self.perf_wall
        if dt < 2.0: return
        cpu_now=time.process_time(); cpu_dt=max(0.0,cpu_now-self.perf_cpu); cores=max(1,os.cpu_count() or 1)
        self.cpu_estimate=max(0.0,min(100.0,cpu_dt/max(0.001,dt)/cores*100.0))
        self.scan_fps=self.perf_scans/max(0.001,dt); self.perf_scans=0
        self.perf_wall=now; self.perf_cpu=cpu_now

    @staticmethod
    def _context_icon_score(img, side):
        if img is None or img.size == 0:
            return 0.0
        hsv=cv2.cvtColor(img,cv2.COLOR_BGR2HSV); h,s,v=cv2.split(hsv)
        if side == "left":
            mask=((h>=75)&(h<=105)&(s>=55)&(v>=90))
        else:
            mask=(((h<=10)|(h>=170))&(s>=70)&(v>=95))
        return float(mask.mean())

    def _context_center_similarity(self, img):
        if img is None or img.size == 0:
            return 0.0
        img=cv2.resize(img,(205,132),interpolation=cv2.INTER_AREA)
        hsv=cv2.cvtColor(img,cv2.COLOR_BGR2HSV); _,s,v=cv2.split(hsv)
        white=((s<85)&(v>135)).astype(np.uint8)
        cand=np.zeros_like(white)
        cand[58:132,:]=white[58:132,:]
        cand[18:70,:48]=white[18:70,:48]
        cand[18:70,157:]=white[18:70,157:]
        cand=cv2.morphologyEx(cand,cv2.MORPH_OPEN,np.ones((2,2),np.uint8))
        templ=self.context_center_t
        inter=float(np.logical_and(templ>0,cand>0).sum())
        ps=float((cand>0).sum()); ts=float((templ>0).sum())
        if ps <= 0 or ts <= 0: return 0.0
        precision=inter/ps; recall=inter/ts
        return float(2*precision*recall/max(1e-9,precision+recall))

    def _scan_context(self, grabber, viewport, now):
        t0=time.perf_counter()
        left=_grab_relative_roi(grabber,viewport,ROI_CONTEXT_LEFT,(82,74))
        center=_grab_relative_roi(grabber,viewport,ROI_CONTEXT_CENTER,(205,132))
        right=_grab_relative_roi(grabber,viewport,ROI_CONTEXT_RIGHT,(82,74))
        self._ema_timing("capture",(time.perf_counter()-t0)*1000)
        q=time.perf_counter()
        ls=self._context_icon_score(left,"left")
        cs=self._context_center_similarity(center)
        rs=self._context_icon_score(right,"right")
        self._ema_timing("context",(time.perf_counter()-q)*1000); self.perf_scans+=1
        self.context_left_score=ls; self.context_center_score=cs; self.context_right_score=rs
        votes=int(ls>=0.028)+int(cs>=0.24)+int(rs>=0.065)
        self.context_votes=votes
        raw=votes>=int(self.cfg.get("vision",{}).get("context_threshold",2))
        if raw:
            self.context_hits+=1; self.context_misses=0; self.match_recent_until=now+4.0
            if self.report_armed:
                self.report_last_live_seen = now
            # A real live HUD coming back means this was only an inter-round gap.
            # Stop the temporary result-screen radar immediately.
            if self.report_waiting_result or self.report_capture_active:
                self._cancel_report_capture_window("live HUD returned")
        else:
            self.context_misses+=1; self.context_hits=0
            # Start the cheap waiter on the FIRST missing live-HUD sample instead
            # of waiting for the full MATCH_CONTEXT state to decay.  This buys
            # roughly one extra context interval when the user clicks through a
            # very short-lived result page.  A returning live HUD cancels it.
            if self.match_context and self.report_armed and not self.report_done and not self.report_waiting_result:
                self._start_report_wait(now, "first live HUD miss")
        if not self.match_context and self.context_hits>=2:
            self.match_context=True; self.phase="IN_MATCH_UNKNOWN"; LOGGER.info("MATCH_CONTEXT TRUE votes=%s L=%.3f C=%.3f R=%.3f",votes,ls,cs,rs)
            # A new live HUD means a real match session. The whole-match report is
            # registered here and is deliberately NOT tied to Sage detection.
            # This costs essentially nothing during the match: it is only a boolean
            # memory flag plus the last-live timestamp. Report OCR remains asleep.
            if self.report_done:
                self.report_done = False
                self.report_attempts = 0
                self.report_pending_kills = None
                self.report_kill_confirm_hits = 0
                self.session_sage_seen = False
                self.report_last_live_seen = 0.0
                self.last_report_nickname = "-"
                self.last_report_agent = "-"
                self.last_report_kills = None
                self._clear_report_snapshot("new match HUD")
            elif self.report_snapshot_locked:
                # A live HUD returning while an unfinished snapshot exists means
                # the prior candidate was not the final whole-match page.
                self._clear_report_snapshot("live HUD returned before report completion")
            if not self.report_armed:
                self.report_armed_since = now
            self.report_armed = True
            self.report_last_live_seen = now
            if not self.report_snapshot_locked:
                self.report_parse_status = "本局已登记"
            # Make identity scan immediate when entering a real match.
            self.next_alive=0.0
        elif self.match_context and self.context_misses>=2:
            self.match_context=False; LOGGER.info("MATCH_CONTEXT FALSE votes=%s L=%.3f C=%.3f R=%.3f",votes,ls,cs,rs)
            # Enter low-power post-match waiting.  This is intentionally NOT a
            # short countdown anymore: ordinary inter-round gaps are cancelled
            # as soon as the live HUD returns, while a real end-of-match screen
            # can arrive many seconds later without being missed.
            if self.report_armed and not self.report_done:
                self._start_report_wait(now, "live HUD disappeared")
            self._reset_match_state("not in live match HUD")

    def _clear_report_snapshot(self, reason=""):
        if self.report_snapshot_locked or self.report_snapshot_cards is not None:
            LOGGER.info("清除战报快照 | %s", reason or "reset")
        self.report_snapshot_locked = False
        self.report_snapshot_score = 0.0
        self.report_snapshot_cards = None
        self.report_snapshot_full = None
        self.report_snapshot_locked_at = 0.0
        self.report_best_candidate_cards = None
        self.report_best_candidate_full = None
        self.report_best_candidate_quality = 0.0
        self.report_best_candidate_at = 0.0
        self.report_best_candidate_counts = []
        self.report_candidate_signature = None
        self.report_candidate_stable_hits = 0
        self.report_last_signature_diff = 0.0
        self.report_parse_status = "等待结算页"
        self.report_parse_attempts = 0

    def _start_report_wait(self, now, reason=""):
        """Enter lightweight waiting without touching an already-owned snapshot."""
        if not bool(self.cfg.get("vision", {}).get("report_enabled", True)):
            return
        if not self.report_armed or self.report_done or self.report_snapshot_locked:
            return
        if not self.report_waiting_result:
            self.report_wait_started = now
            self.report_wait_samples = 0
            self.report_parse_status = "等待整局结算页"
            LOGGER.info("战报低功耗等待启动 | %s", reason or "live HUD disappeared")
        self.report_waiting_result = True
        self.report_capture_active = False
        self.report_capture_started = 0.0
        self.report_capture_deadline = 0.0
        self.report_capture_samples = 0
        self.report_capture_best_score = 0.0
        self.report_capture_best_cards = None
        self.report_best_candidate_cards = None
        self.report_best_candidate_full = None
        self.report_best_candidate_quality = 0.0
        self.report_best_candidate_at = 0.0
        self.report_best_candidate_counts = []
        self.report_candidate_hits = 0
        self.report_candidate_signature = None
        self.report_candidate_stable_hits = 0
        self.report_last_signature_diff = 0.0
        self.report_retry_after = 0.0
        self.last_report_layout_score = 0.0
        self.next_report = 0.0

    def _start_report_capture_window(self, now, reason=""):
        """Legacy burst mode retained only for diagnostics; never unlocks a snapshot."""
        if not bool(self.cfg.get("vision", {}).get("report_enabled", True)):
            return
        if not self.report_armed or self.report_done or self.report_snapshot_locked:
            return
        window_ms = max(1200, min(6000, int(self.cfg.get("vision", {}).get("report_capture_window_ms", 3000))))
        self.report_waiting_result = True
        self.report_capture_active = True
        self.report_capture_started = now
        self.report_capture_deadline = now + window_ms / 1000.0
        self.report_capture_samples = 0
        self.report_candidate_hits = 0
        self.report_retry_after = 0.0
        self.next_report = 0.0
        LOGGER.info("战报高速捕获窗口启动 %.1fs | %s", window_ms/1000.0, reason or "candidate")

    def _cancel_report_capture_window(self, reason=""):
        # A real live HUD returning proves an inter-round gap. If a snapshot was
        # somehow captured before that, it was a false positive and is safe to clear.
        if self.report_waiting_result or self.report_capture_active or self.report_snapshot_locked:
            LOGGER.info("战报等待/捕获结束 | %s", reason or "cancel")
        self.report_waiting_result = False
        self.report_wait_started = 0.0
        self.report_wait_samples = 0
        self.report_capture_active = False
        self.report_capture_started = 0.0
        self.report_capture_deadline = 0.0
        self.report_capture_samples = 0
        self.report_capture_best_score = 0.0
        self.report_capture_best_cards = None
        self.report_candidate_hits = 0
        self.last_report_layout_score = 0.0
        self._clear_report_snapshot(reason or "capture cancelled")

    def _verify_k_same_snapshot(self, cards_img, data):
        """Second K check from the same frozen result frame.

        This replaces the old requirement that the user keep the result screen
        visible for a *second screen scan*.  A slightly wider crop is fed through
        the lightweight digit templates.  High-confidence primary reads are also
        accepted when the alternate crop is inconclusive.
        """
        try:
            card_idx = int(data.get("card_index", 1)) - 1
            ch, cw = cards_img.shape[:2]
            x1 = int(card_idx * cw / 5); x2 = int((card_idx + 1) * cw / 5)
            card = cards_img[:, x1:x2]
            h, w = card.shape[:2]
            roi = card[int(h*0.70):int(h*0.95), int(w*0.21):int(w*0.46)]
            if roi.size:
                value, conf = self.digit_reader.read_hp_roi(roi)
                if value is not None and 0 <= int(value) <= 60 and float(conf) >= 0.50:
                    return int(value) == int(data.get("kills")), int(value), float(conf)
        except Exception:
            LOGGER.exception("战报同帧K二次校验失败")
        primary_conf = float(data.get("kill_confidence", 0.0) or 0.0)
        # The normal tight-crop digit path is already very conservative.
        if data.get("kill_method") == "digit-template" and primary_conf >= 0.66:
            return True, int(data.get("kills")), primary_conf
        return False, None, 0.0

    def _scan_alive(self, grabber, viewport, now):
        if not self.match_context:
            return
        t0=time.perf_counter()
        img=_grab_relative_roi(grabber,viewport,ROI_ALIVE,(580,132)); self._ema_timing("capture",(time.perf_counter()-t0)*1000)
        q=time.perf_counter(); gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY); score=self._multi_match(gray,self.alive_templates)
        self._ema_timing("alive",(time.perf_counter()-q)*1000); self.last_alive_score=score; self.perf_scans+=1
        thr=float(self.cfg.get("vision",{}).get("alive_threshold",0.74)); raw=score>=thr
        if raw:
            self.alive_hits+=1; self.alive_misses=0
        else:
            self.alive_misses+=1; self.alive_hits=0

        if raw and self.alive_hits>=2:
            was_dead=self.death_latched
            self.alive_state=True; self.ever_alive=True; self.death_latched=False
            # Sage detection still drives the six live reaction states, but whole-match
            # report registration is handled by MATCH_CONTEXT so reports also work when
            # the player uses Sova/Jett/etc.
            self.session_sage_seen=True
            self.death_suspect_since=None; self.death_ocr_checked=False; self.last_death_evidence="-"
            if self.round_end and now>=self.transient_until:
                self.round_end=False
            self.phase="IN_MATCH_ALIVE"
            if was_dead:
                LOGGER.info("检测到新回合/复活：绿色友方条重新出现贤者头像 score=%.3f",score)
            return

        if self.alive_state is True and self.alive_misses>=2 and not self.death_latched:
            # Missing portrait is only a suspicion. Do not play DEAD yet.
            self.alive_state=None; self.low_state=False; self.low_hits=0; self.hp_history=[]; self.hp_enter_votes=0; self.hp_exit_votes=0
            self.death_suspect_since=now; self.death_ocr_checked=False
            self.phase="SUSPECTED_DEAD"
            self.last_death_evidence="贤者头像消失，等待二次证据"
            LOGGER.info("疑似死亡：绿色友方条贤者头像消失 score=%.3f",score)
            if self.current_display_state=="low_hp":
                self._request_state("idle","death pending confirmation")

    @staticmethod
    def _death_report_score(img):
        if img is None or img.size == 0:
            return 0.0
        hsv=cv2.cvtColor(img,cv2.COLOR_BGR2HSV); _,_,v=cv2.split(hsv)
        # Combat report is a large dark rectangular panel. This is only a secondary cue
        # after the player's top HUD portrait has already disappeared.
        return float((v<105).mean())

    def _confirm_death(self, reason):
        self.death_latched=True; self.alive_state=False; self.low_state=False; self.low_hits=0; self.hp_history=[]; self.hp_enter_votes=0; self.hp_exit_votes=0
        self.death_suspect_since=None; self.phase="IN_MATCH_DEAD"; self.last_death_evidence=reason
        self.transient_until=0.0; self.pending_result=None
        self._request_state("dead",reason)
        LOGGER.info("DEAD_CONFIRMED | %s",reason)

    def _scan_death_confirmation(self, grabber, viewport, now):
        if not self.match_context or self.death_latched or self.death_suspect_since is None:
            return
        # If the portrait comes back before confirmation, cancel suspicion.
        if self.alive_state is True:
            self.death_suspect_since=None; self.phase="IN_MATCH_ALIVE"; return
        t0=time.perf_counter(); report=_grab_relative_roi(grabber,viewport,ROI_DEATH_REPORT,(360,250)); self._ema_timing("capture",(time.perf_counter()-t0)*1000)
        q=time.perf_counter(); report_score=self._death_report_score(report); self._ema_timing("death",(time.perf_counter()-q)*1000); self.perf_scans+=1
        self.last_death_report_score=report_score
        if report_score>=0.56:
            self._confirm_death(f"战斗记录面板证据 {report_score:.2f}")
            return

        # With a configured nickname, inspect killfeed once to see if nickname is on victim side.
        if not self.death_ocr_checked and now-self.death_suspect_since>=0.25:
            self.death_ocr_checked=True
            nickname=str(self.cfg.get("vision",{}).get("player_nickname","")).strip()
            if nickname and bool(self.cfg.get("vision",{}).get("nickname_ocr_fallback",True)):
                t0=time.perf_counter(); kill_roi=_grab_relative_roi(grabber,viewport,ROI_KILL_OCR,(640,189)); self._ema_timing("capture",(time.perf_counter()-t0)*1000)
                hit,desc=self._ocr_names_once(kill_roi,"victim")
                if hit:
                    self._confirm_death(f"击杀栏昵称位于被击杀侧：{desc}")
                    return

        fallback=float(self.cfg.get("vision",{}).get("death_fallback_seconds",2.2))
        thr=float(self.cfg.get("vision",{}).get("alive_threshold",0.74))
        if now-self.death_suspect_since>=fallback and self.last_alive_score < max(0.30,thr-0.06):
            self._confirm_death(f"对局HUD仍存在 + 贤者头像持续消失 {fallback:.1f}s")

    @staticmethod
    def _rect_intersects(a, b):
        ax1, ay1, ax2, ay2 = a; bx1, by1, bx2, by2 = b
        return min(ax2, bx2) > max(ax1, bx1) and min(ay2, by2) > max(ay1, by1)

    def _hp_screen_rect(self, viewport):
        vx, vy, vw, vh = viewport
        x1, y1, x2, y2 = ROI_HP
        return (int(vx + x1 * vw), int(vy + y1 * vh), int(vx + x2 * vw), int(vy + y2 * vh))

    def _pet_screen_rect(self):
        # Pet position is persisted whenever dragging ends. Use a conservative
        # bounding box as a fallback guard because DXGI/MSS captures the final
        # desktop composite, including XiaoMeili itself.
        try:
            px = int(self.cfg.get("x", -100000)); py = int(self.cfg.get("y", -100000))
            pw = max(80, int(self.cfg.get("pet_width", 280)))
            ph = max(80, int(round(pw * 660 / 620)))
            return (px, py, px + pw, py + ph)
        except Exception:
            return (-100000, -100000, -99999, -99999)

    def _hp_is_occluded_by_pet(self, viewport):
        if not bool(self.cfg.get("vision", {}).get("hp_occlusion_guard", True)):
            return False
        return self._rect_intersects(self._hp_screen_rect(viewport), self._pet_screen_rect())

    def _append_hp_sample(self, hp, conf):
        vcfg = self.cfg.get("vision", {})
        min_conf = float(vcfg.get("hp_min_conf", 0.56))
        if hp is None or not (0 <= int(hp) <= 100) or float(conf) < min_conf:
            return False
        window = max(3, int(vcfg.get("hp_vote_window", 5)))
        self.hp_history.append(int(hp))
        if len(self.hp_history) > window:
            self.hp_history = self.hp_history[-window:]
        self.hp_last_confirmed = int(hp)
        return True

    def _update_low_hp_vote(self):
        vcfg = self.cfg.get("vision", {})
        threshold = int(vcfg.get("low_hp_threshold", 50))
        exit_threshold = min(100, threshold + int(vcfg.get("hp_exit_margin", 10)))
        enter_needed = max(2, int(vcfg.get("hp_enter_votes", 3)))
        exit_needed = max(2, int(vcfg.get("hp_exit_votes", 3)))
        hist = list(self.hp_history)
        self.hp_enter_votes = sum(1 for v in hist if v <= threshold)
        self.hp_exit_votes = sum(1 for v in hist if v >= exit_threshold)

        if not self.low_state:
            # Require multiple independent valid readings before entering LOW_HP.
            if len(hist) >= enter_needed and self.hp_enter_votes >= enter_needed:
                self.low_state = True
                LOGGER.info("HP低血量确认 history=%s votes=%s/%s threshold=%s", hist, self.hp_enter_votes, len(hist), threshold)
        else:
            # Hysteresis: do not leave LOW_HP around 49/51. Require >= threshold+margin.
            if len(hist) >= exit_needed and self.hp_exit_votes >= exit_needed:
                self.low_state = False
                LOGGER.info("HP恢复确认 history=%s votes=%s/%s exit>=%s", hist, self.hp_exit_votes, len(hist), exit_threshold)

    def _scan_hp(self, grabber, viewport, now):
        if not self.match_context or self.alive_state is not True or self.death_latched or self.round_end:
            self.last_hp=None; self.last_hp_conf=0.0; self.last_hp_probe=None
            self.hp_history=[]; self.hp_enter_votes=0; self.hp_exit_votes=0
            self.hp_occluded=False; self.hp_guard_reason="-"
            return

        # V0.4.8 self-occlusion guard. Desktop Duplication/MSS sees the desktop
        # pet too. If XiaoMeili overlaps the tiny HP sensor, skip this cycle
        # rather than letting her own hair/effects become fake digits.
        if self._hp_is_occluded_by_pet(viewport):
            self.hp_occluded=True
            self.hp_guard_reason="小美丽遮挡生命值区域，本轮HP识别已暂停"
            self.last_hp=None; self.last_hp_conf=0.0; self.last_hp_probe=None
            self.low_hits=0
            self.perf_scans+=1
            return
        self.hp_occluded=False; self.hp_guard_reason="-"

        # ROI_HP is deliberately very tight around the HP digits only.
        t0=time.perf_counter(); img=_grab_relative_roi(grabber,viewport,ROI_HP,(90,61)); self._ema_timing("capture",(time.perf_counter()-t0)*1000)
        g=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY); tiny=cv2.resize(g,(24,12),interpolation=cv2.INTER_AREA)
        changed=True
        if self.last_hp_probe is not None:
            changed=float(np.mean(cv2.absdiff(tiny,self.last_hp_probe))) >= 2.4
        self.last_hp_probe=tiny
        # Periodic refresh catches changes whose hash delta happens to be small.
        # After the first low/recovery candidate we temporarily re-read every HP
        # cycle so a 3-vote decision finishes in well under a second instead of
        # waiting several seconds for periodic refreshes.
        vcfg=self.cfg.get("vision",{})
        threshold=int(vcfg.get("low_hp_threshold",50))
        exit_threshold=min(100,threshold+int(vcfg.get("hp_exit_margin",10)))
        enter_needed=max(2,int(vcfg.get("hp_enter_votes",3)))
        exit_needed=max(2,int(vcfg.get("hp_exit_votes",3)))
        pending_enter=(not self.low_state and any(v<=threshold for v in self.hp_history) and self.hp_enter_votes<enter_needed)
        pending_exit=(self.low_state and any(v>=exit_threshold for v in self.hp_history) and self.hp_exit_votes<exit_needed)
        force=(self.last_hp is None or now-self.last_hp_full_read>1.8 or pending_enter or pending_exit)
        if not (changed or force):
            self.perf_scans+=1; return

        q=time.perf_counter(); hp,conf=self.digit_reader.read_hp_roi(img); self._ema_timing("hp",(time.perf_counter()-q)*1000)
        self.last_hp_full_read=now; self.hp_read_count+=1; self.perf_scans+=1
        self.last_hp=hp; self.last_hp_conf=conf

        # No stale-value reuse here: an unreadable frame is unknown, not the
        # previous HP. This prevents one bad low reading from lingering for 0.9s.
        if self._append_hp_sample(hp, conf):
            self.last_valid_hp=int(hp); self.last_hp_time=now
            self._update_low_hp_vote()
            self.low_hits=self.hp_enter_votes
        else:
            # Invalid/low-confidence frames do not vote and cannot trigger LOW_HP.
            self.low_hits=0

    def _scan_kill_probe(self, grabber, viewport, now):
        if not self.match_context or self.alive_state is not True or self.death_latched or self.round_end:
            self.last_kill_signature=(0,()); self.last_kill_count=0; return
        t0=time.perf_counter(); probe=_grab_relative_roi(grabber,viewport,ROI_KILL_PROBE,(320,108)); self._ema_timing("capture",(time.perf_counter()-t0)*1000)
        q=time.perf_counter(); sig,strength=_killfeed_green_signature(probe); self._ema_timing("kill",(time.perf_counter()-q)*1000); self.perf_scans+=1
        changed=sig!=self.last_kill_signature; self.last_kill_probe_strength=strength; self.last_kill_signature=sig
        if sig[0]<=0 or not changed or now-self.last_kill_event_time<0.65: return
        self.last_kill_event_time=now
        t0=time.perf_counter(); kill_roi=_grab_relative_roi(grabber,viewport,ROI_KILL_OCR,(640,189)); self._ema_timing("capture",(time.perf_counter()-t0)*1000)
        gray=cv2.cvtColor(kill_roi,cv2.COLOR_BGR2GRAY); portrait_score=self._fixed_match(gray,self.kill_portrait_t)
        self.last_kill_score=portrait_score; count=0; match="头像判定"
        if portrait_score>=0.86:
            count=1; match=f"贤者头像 {portrait_score:.2f}"
        elif portrait_score>=0.70:
            c,m=self._ocr_own_kill_once(kill_roi); match=m
            if c: count=c
        self.last_nickname_match=match; self.last_kill_count=count
        if count>0 and self.alive_state is True:
            self._request_state("kill",f"event-driven own kill portrait={portrait_score:.3f} nick={match}")
            self.transient_until=now+int(self.cfg.get("vision",{}).get("kill_show_ms",1400))/1000.0

    def _scan_result(self, grabber, viewport, now):
        # Result overlay may partially hide the match-context timer, so allow a short recent-match grace.
        if not self.match_context and now>self.match_recent_until:
            return
        t0=time.perf_counter(); img=_grab_relative_roi(grabber,viewport,ROI_RESULT,(480,243)); self._ema_timing("capture",(time.perf_counter()-t0)*1000)
        q=time.perf_counter(); gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY); bw=(gray>220).astype(np.uint8)*255
        win_score=self._fixed_match(bw,self.win_t); loss_score=self._fixed_match(bw,self.loss_t)
        self._ema_timing("result",(time.perf_counter()-q)*1000); self.perf_scans+=1
        self.last_win_score=win_score; self.last_loss_score=loss_score
        thr=float(self.cfg.get("vision",{}).get("result_threshold",0.75)); win_raw=win_score>=thr; loss_raw=loss_score>=thr
        win_event=win_raw and not self.win_latched; loss_event=loss_raw and not self.loss_latched
        if win_raw: self.win_latched=True
        elif win_score<thr-0.12: self.win_latched=False
        if loss_raw: self.loss_latched=True
        elif loss_score<thr-0.12: self.loss_latched=False
        result_state="victory" if win_event else "defeat" if loss_event else None
        if not result_state: return
        self.round_end=True; self.phase="ROUND_END"
        if self.current_display_state=="kill" and now<self.transient_until:
            self.pending_result=(result_state,self.transient_until+0.06)
        else:
            self._request_state(result_state,f"round result win={win_score:.3f} loss={loss_score:.3f}")
            self.transient_until=now+int(self.cfg.get("vision",{}).get("result_show_ms",2800))/1000.0; self.pending_result=None

    def _settle_state(self, now):
        if self.pending_result and now>=self.pending_result[1]:
            rs=self.pending_result[0]; self.pending_result=None; self._request_state(rs,"delayed after kill")
            self.transient_until=now+int(self.cfg.get("vision",{}).get("result_show_ms",2800))/1000.0
        if now>=self.transient_until and self.current_display_state in ("kill","victory","defeat"):
            self._request_state(self._persistent_state(),"transient finished")
        if self.current_display_state not in ("kill","victory","defeat"):
            self._request_state(self._persistent_state(),"persistent context")

    @staticmethod
    def _report_layout_candidate(cards, cont):
        if cards is None or cards.size == 0 or cont is None or cont.size == 0:
            return False, 0.0
        try:
            hsv = cv2.cvtColor(cont, cv2.COLOR_BGR2HSV)
            h, s, v = cv2.split(hsv)
            red_frac = float((((h < 10) | (h > 170)) & (s > 85) & (v > 95)).mean())
            gray_votes = 0
            for i in range(5):
                x1 = int(i * cards.shape[1] / 5)
                x2 = int((i + 1) * cards.shape[1] / 5)
                seg = cards[:, x1:x2]
                vv = cv2.cvtColor(seg, cv2.COLOR_BGR2HSV)[..., 2]
                if float((vv < 105).mean()) >= 0.55:
                    gray_votes += 1
            score = min(1.0, red_frac * 1.8 + gray_votes / 5.0 * 0.55)
            return (red_frac >= 0.16 and gray_votes >= 4), float(score)
        except Exception:
            return False, 0.0

    @staticmethod
    def _report_five_card_completeness(cards):
        """Cheap structural check for the *actual* five-player result page.

        The post-result reward/progression page also has dark panels and a red
        button, so the older detector could confuse it with the scorecard page.
        A real scorecard has dense small white text (nickname / ACS / KDA) in
        all five equally-spaced card columns.  We count those text-like bright
        components in the lower part of each fifth.

        This is deliberately OCR-free and runs on the 820x270 radar image.
        """
        if cards is None or cards.size == 0:
            return False, 0.0, [], []
        try:
            gray = cv2.cvtColor(cards, cv2.COLOR_BGR2GRAY)
            counts, densities = [], []
            for i in range(5):
                x1 = int(i * gray.shape[1] / 5)
                x2 = int((i + 1) * gray.shape[1] / 5)
                seg = gray[:, x1:x2]
                # Skip the character-art-heavy top portion; player-name/ACS/KDA
                # live in the lower 65% of the card panel.
                seg = seg[int(seg.shape[0] * 0.35):, :]
                if seg.size == 0:
                    counts.append(0); densities.append(0.0); continue
                mask = (seg > 180).astype(np.uint8) * 255
                n, labels, stats, cents = cv2.connectedComponentsWithStats(mask)
                c = 0
                for st in stats[1:]:
                    w = int(st[cv2.CC_STAT_WIDTH]); h = int(st[cv2.CC_STAT_HEIGHT])
                    area = int(st[cv2.CC_STAT_AREA])
                    if 2 <= w <= 70 and 2 <= h <= 30 and area >= 5:
                        c += 1
                counts.append(c)
                densities.append(float((seg > 180).mean()))
            enough = sum(1 for c in counts if c >= 5)
            complete = (min(counts) >= 4 and enough >= 4 and min(densities) >= 0.004)
            # Score favors all-five balance, not one very text-heavy panel.
            comp_score = sum(min(1.0, c / 8.0) for c in counts) / 5.0
            density_score = sum(min(1.0, d / 0.012) for d in densities) / 5.0
            quality = 0.72 * comp_score + 0.28 * density_score
            return bool(complete), float(quality), counts, densities
        except Exception:
            return False, 0.0, [], []

    def _cache_report_candidate(self, grabber, viewport, now, layout_score, card_quality, counts):
        """Own a real result frame immediately, before waiting for stability."""
        quality = float(layout_score) * 0.35 + float(card_quality) * 0.65
        # Avoid recapturing native/full frames unless quality actually improves.
        if self.report_best_candidate_cards is not None and quality <= self.report_best_candidate_quality + 0.012:
            return False
        try:
            vx, vy, vw, vh = viewport
            t0 = time.perf_counter()
            full_frame = grabber.grab(vx, vy, vw, vh)
            cards = _grab_relative_roi(grabber, viewport, ROI_REPORT_CARDS, None)
            self._ema_timing("capture", (time.perf_counter() - t0) * 1000)
            if cards is None or cards.size == 0:
                return False
            self.report_best_candidate_cards = cards.copy()
            self.report_best_candidate_full = None if full_frame is None else full_frame.copy()
            self.report_best_candidate_quality = quality
            self.report_best_candidate_at = now
            self.report_best_candidate_counts = list(counts or [])
            self.report_parse_status = f"五卡候选已缓存，等待定格（质量 {quality:.2f}）"
            LOGGER.info("战报五卡候选已缓存 quality=%.3f layout=%.3f counts=%s", quality, layout_score, counts)
            return True
        except Exception:
            LOGGER.exception("缓存战报五卡候选失败")
            return False

    def _lock_best_report_candidate(self, now, reason=""):
        if self.report_best_candidate_cards is None:
            return False
        self.report_snapshot_cards = self.report_best_candidate_cards.copy()
        self.report_snapshot_full = None if self.report_best_candidate_full is None else self.report_best_candidate_full.copy()
        self.report_snapshot_locked = True
        self.report_snapshot_locked_at = now
        self.report_snapshot_score = float(self.report_best_candidate_quality)
        self.report_waiting_result = False
        self.report_capture_active = False
        self.report_parse_status = "战报快照已锁定，后台解析中"
        self.report_attempts += 1
        LOGGER.info("锁定最佳五卡快照 quality=%.3f counts=%s | %s",
                    self.report_best_candidate_quality, self.report_best_candidate_counts, reason or "confirmed")
        return True

    @staticmethod
    def _parse_kill_number(text):
        """Parse only a compact kill-count token, not a full K/D/A string."""
        t = str(text or "").upper().replace("Ｏ", "0").replace("O", "0")
        t = t.replace("I", "1").replace("L", "1")
        nums = re.findall(r"(?<!\d)(\d{1,2})(?!\d)", t)
        for token in nums:
            try:
                value = int(token)
            except Exception:
                continue
            if 0 <= value <= 60:
                return value
        return None

    def _run_report_ocr(self, engine, image):
        if engine is None or image is None or image.size == 0:
            return None
        self.ocr_trigger_count += 1
        return engine(image)

    def _read_kill_count_from_card(self, cards_img, card_idx, engine=None):
        """Read K from a high-resolution frozen result card.

        V0.4.9.9 no longer uses the HP digit template as the primary method. The
        result-page K/D/A typography and vertical location differ from the HUD. We
        OCR only the narrow K/D/A row and keep the *leftmost* valid number, so D
        and A can be wrong without invalidating K. Two preprocessing variants are
        enough in normal cases; a third is used only when they disagree.
        """
        if cards_img is None or cards_img.size == 0:
            return None, 0.0, "empty"
        ch, cw = cards_img.shape[:2]
        x1 = int(card_idx * cw / 5); x2 = int((card_idx + 1) * cw / 5)
        card = cards_img[:, x1:x2]
        if card.size == 0:
            return None, 0.0, "empty-card"
        h, w = card.shape[:2]
        # Corrected V0.4.9.9 coordinates for ROI_REPORT_CARDS (y=0.42..0.74).
        # This band contains the K/D/A label and value row, not the nickname/ACS rows.
        kda_roi = card[int(h * 0.80):int(h * 0.995), int(w * 0.16):int(w * 0.84)]
        tight_k = card[int(h * 0.82):int(h * 0.995), int(w * 0.18):int(w * 0.43)]
        if kda_roi.size == 0:
            return None, 0.0, "empty-kda-roi"

        votes = []
        if engine is not None:
            try:
                up = cv2.resize(kda_roi, None, fx=2.4, fy=2.4, interpolation=cv2.INTER_CUBIC)
                gray = cv2.cvtColor(up, cv2.COLOR_BGR2GRAY)
                clahe = cv2.createCLAHE(clipLimit=1.8, tileGridSize=(6,6)).apply(gray)
                variants = [up, cv2.cvtColor(clahe, cv2.COLOR_GRAY2BGR)]
                # Third variant is only evaluated if the first two do not agree.
                for vi, variant in enumerate(variants):
                    rr = self._run_report_ocr(engine, variant)
                    try:
                        LOGGER.info("战报K OCR pass=%s txts=%s", vi + 1, ([] if getattr(rr, "txts", None) is None else (getattr(rr, "txts").tolist() if hasattr(getattr(rr, "txts"), "tolist") else list(getattr(rr, "txts")))))
                    except Exception:
                        pass
                    # RapidOCR 3.x commonly returns numpy.ndarray for boxes/scores.
                    # Using ``array or []`` raises:
                    # ValueError: The truth value of an array is ambiguous.
                    # That exception previously aborted KDA parsing even when the
                    # crop clearly contained e.g. "12/19/2".
                    boxes_raw = getattr(rr, "boxes", None)
                    txts_raw = getattr(rr, "txts", None)
                    scores_raw = getattr(rr, "scores", None)
                    boxes = [] if boxes_raw is None else list(boxes_raw)
                    txts = [] if txts_raw is None else list(txts_raw)
                    scores = [] if scores_raw is None else list(scores_raw)
                    nums = []
                    for i, txt in enumerate(txts):
                        val = self._parse_kill_number(txt)
                        if val is None:
                            continue
                        sc = float(scores[i]) if i < len(scores) else 0.5
                        if sc < 0.28:
                            continue
                        if i < len(boxes):
                            bx = np.asarray(boxes[i], dtype=np.float32)
                            xpos = float(bx[:,0].mean())
                        else:
                            xpos = float(i)
                        nums.append((xpos, int(val), sc))
                    if nums:
                        nums.sort(key=lambda z:z[0])
                        votes.append((nums[0][1], nums[0][2], vi))
                    else:
                        # Extra fallback: RapidOCR may return one compact token such
                        # as "12/19/2" without a usable box list. Parse the first
                        # valid number directly from OCR text order.
                        for i, txt in enumerate(txts):
                            val = self._parse_kill_number(txt)
                            if val is None:
                                continue
                            sc = float(scores[i]) if i < len(scores) else 0.5
                            if sc >= 0.22:
                                votes.append((int(val), sc, vi))
                                break
                if len(votes) >= 2 and votes[0][0] == votes[1][0]:
                    return votes[0][0], min(1.0, max(votes[0][1], votes[1][1]) + 0.12), "kda-ocr-consensus"
                # Only pay for a thresholded third pass when needed.
                _, bw = cv2.threshold(clahe, 160, 255, cv2.THRESH_BINARY)
                rr = self._run_report_ocr(engine, cv2.cvtColor(bw, cv2.COLOR_GRAY2BGR))
                boxes_raw = getattr(rr, "boxes", None)
                txts_raw = getattr(rr, "txts", None)
                scores_raw = getattr(rr, "scores", None)
                boxes = [] if boxes_raw is None else list(boxes_raw)
                txts = [] if txts_raw is None else list(txts_raw)
                scores = [] if scores_raw is None else list(scores_raw)
                nums=[]
                for i, txt in enumerate(txts):
                    val=self._parse_kill_number(txt)
                    if val is None: continue
                    sc=float(scores[i]) if i < len(scores) else 0.5
                    if sc < 0.25: continue
                    xpos=float(np.asarray(boxes[i],dtype=np.float32)[:,0].mean()) if i < len(boxes) else float(i)
                    nums.append((xpos,int(val),sc))
                if nums:
                    nums.sort(key=lambda z:z[0]); votes.append((nums[0][1],nums[0][2],2))
                if votes:
                    counts={}
                    for val,sc,vi in votes:
                        counts.setdefault(val,[]).append(sc)
                    best_val,best_scores=max(counts.items(), key=lambda kv:(len(kv[1]),max(kv[1])))
                    if len(best_scores)>=2 or max(best_scores)>=0.62:
                        return int(best_val), float(max(best_scores)), "kda-ocr-vote"
            except Exception:
                LOGGER.exception("战报K专用OCR失败")

        # Last-resort local digit template, now on the corrected *tight* K crop.
        try:
            value, conf = self.digit_reader.read_hp_roi(tight_k)
            if value is not None and 0 <= int(value) <= 60 and float(conf) >= 0.64:
                return int(value), float(conf), "digit-template-fallback"
        except Exception:
            LOGGER.exception("战报K模板兜底失败")

        try:
            stamp = time.strftime("%Y%m%d_%H%M%S")
            cv2.imwrite(str(DEBUG_DIR / f"report_k_miss_{stamp}_card{card_idx+1}.png"), kda_roi)
        except Exception:
            pass
        return None, 0.0, "unread"

    @staticmethod
    def _report_stability_signature(cards, cont):
        try:
            parts = []
            for arr, size in ((cards, (240, 90)), (cont, (120, 40))):
                if arr is None or arr.size == 0:
                    continue
                gray = cv2.cvtColor(arr, cv2.COLOR_BGR2GRAY)
                small = cv2.resize(gray, size, interpolation=cv2.INTER_AREA)
                parts.append(small)
            if not parts:
                return None
            return np.concatenate([p.reshape(-1) for p in parts]).astype(np.uint8)
        except Exception:
            return None

    @staticmethod
    def _report_signature_diff(sig_a, sig_b):
        if sig_a is None or sig_b is None:
            return 999.0
        try:
            a = np.asarray(sig_a, dtype=np.float32).reshape(-1)
            b = np.asarray(sig_b, dtype=np.float32).reshape(-1)
            if a.size != b.size or a.size == 0:
                return 999.0
            return float(np.mean(np.abs(a - b)))
        except Exception:
            return 999.0

    def _capture_report_snapshot(self, grabber, viewport, now, score):
        try:
            vx, vy, vw, vh = viewport
            t1 = time.perf_counter()
            full_frame = grabber.grab(vx, vy, vw, vh)
            frozen_cards = _grab_relative_roi(grabber, viewport, ROI_REPORT_CARDS, None)
            self._ema_timing("capture", (time.perf_counter() - t1) * 1000)
            self.report_snapshot_full = None if full_frame is None else full_frame.copy()
            self.report_snapshot_cards = None if frozen_cards is None else frozen_cards.copy()
            if self.report_snapshot_cards is None or self.report_snapshot_cards.size == 0:
                raise RuntimeError("战报卡片快照为空")
            self.report_snapshot_locked = True
            self.report_snapshot_locked_at = now
            self.report_snapshot_score = float(score)
            self.report_waiting_result = False
            self.report_capture_active = False
            self.report_parse_status = "战报快照已锁定，后台解析中"
            self.report_attempts += 1
            LOGGER.info("战报高清快照已锁定 score=%.3f native=%sx%s；已等待结算动画定格", score, self.report_snapshot_cards.shape[1], self.report_snapshot_cards.shape[0])
            return True
        except Exception:
            LOGGER.exception("高清战报快照抓取失败")
            return False

    def _save_report_parse_debug(self, desc, data=None):
        try:
            stamp = time.strftime("%Y%m%d_%H%M%S")
            out_dir = REPORT_DEBUG_DIR / f"reportdiag_{stamp}"
            out_dir.mkdir(parents=True, exist_ok=True)
            if self.report_snapshot_full is not None and getattr(self.report_snapshot_full, 'size', 0):
                cv2.imwrite(str(out_dir / "00_full_game_snapshot.png"), self.report_snapshot_full)
            if self.report_snapshot_cards is not None and getattr(self.report_snapshot_cards, 'size', 0):
                cv2.imwrite(str(out_dir / "01_locked_cards_snapshot.png"), self.report_snapshot_cards)
                ch, cw = self.report_snapshot_cards.shape[:2]
                for i in range(5):
                    x1 = int(i * cw / 5); x2 = int((i + 1) * cw / 5)
                    card = self.report_snapshot_cards[:, x1:x2]
                    if card.size:
                        cv2.imwrite(str(out_dir / f"02_card_{i+1}.png"), card)
                if data and data.get('card_index'):
                    idx = max(0, min(4, int(data.get('card_index')) - 1))
                    x1 = int(idx * cw / 5); x2 = int((idx + 1) * cw / 5)
                    card = self.report_snapshot_cards[:, x1:x2]
                    if card.size:
                        cv2.imwrite(str(out_dir / "03_my_card_crop.png"), card)
                        h, w = card.shape[:2]
                        nick_roi = card[int(h * 0.26):int(h * 0.58), int(w * 0.08):int(w * 0.92)]
                        kda_roi = card[int(h * 0.80):int(h * 0.995), int(w * 0.16):int(w * 0.84)]
                        if nick_roi.size:
                            cv2.imwrite(str(out_dir / "04_nickname_crop.png"), nick_roi)
                        if kda_roi.size:
                            cv2.imwrite(str(out_dir / "05_kda_crop.png"), kda_roi)
            info = [
                f"time={stamp}",
                f"status={desc}",
                f"nickname_cfg={self.cfg.get('vision', {}).get('player_nickname', '')}",
                f"layout_score={self.report_snapshot_score:.3f}",
                f"parse_attempts={self.report_parse_attempts}",
                f"stable_hits={self.report_candidate_stable_hits}",
                f"candidate_hits={self.report_candidate_hits}",
                f"signature_diff={self.report_last_signature_diff:.3f}",
            ]
            if data:
                for key in ("nickname", "nickname_similarity", "card_index", "kills", "kill_confidence", "kill_method"):
                    if key in data:
                        info.append(f"{key}={data.get(key)}")
            (out_dir / "90_parse_result.txt").write_text("\n".join(info), encoding="utf-8")
            self.last_report_debug_dir = str(out_dir)
            LOGGER.info("已导出战报诊断包: %s", out_dir)
        except Exception:
            LOGGER.exception("导出战报诊断包失败")

    def _find_player_card(self, cards_img, nickname, engine=None):
        if cards_img is None or cards_img.size == 0:
            return None
        target = self._norm_name(nickname)
        best = None
        ch, cw = cards_img.shape[:2]
        for card_idx in range(5):
            x1 = int(card_idx * cw / 5); x2 = int((card_idx + 1) * cw / 5)
            card = cards_img[:, x1:x2]
            if card.size == 0:
                continue
            h, w = card.shape[:2]
            roi = card[int(h * 0.26):int(h * 0.58), int(w * 0.08):int(w * 0.92)]
            if roi.size == 0:
                continue
            variants = []
            up = cv2.resize(roi, None, fx=2.3, fy=2.3, interpolation=cv2.INTER_CUBIC)
            variants.append(up)
            gray = cv2.cvtColor(up, cv2.COLOR_BGR2GRAY)
            clahe = cv2.createCLAHE(clipLimit=1.8, tileGridSize=(8, 8)).apply(gray)
            variants.append(cv2.cvtColor(clahe, cv2.COLOR_GRAY2BGR))
            _, bw = cv2.threshold(clahe, 168, 255, cv2.THRESH_BINARY)
            variants.append(cv2.cvtColor(bw, cv2.COLOR_GRAY2BGR))
            for variant in variants:
                result = self._run_report_ocr(engine, variant)
                txts_raw = getattr(result, 'txts', None)
                scores_raw = getattr(result, 'scores', None)
                txts = [] if txts_raw is None else list(txts_raw)
                scores = [] if scores_raw is None else list(scores_raw)
                for i, txt in enumerate(txts):
                    sc = float(scores[i]) if i < len(scores) else 0.5
                    if sc < 0.22:
                        continue
                    sim = self._name_similarity(target, txt)
                    cand = (sim, sc, str(txt), card_idx)
                    if best is None or (cand[0], cand[1]) > (best[0], best[1]):
                        best = cand
                if best and best[0] >= 0.80 and best[3] == card_idx:
                    break
        return best

    def _read_whole_match_report(self, cards_img):
        nickname = str(self.cfg.get("vision", {}).get("player_nickname", "")).strip()
        if not nickname:
            return None, "未填写游戏昵称"
        t0 = time.perf_counter()
        engine = self._get_report_ocr_engine()
        if engine is None:
            return None, "OCR引擎不可用"
        try:
            base = cards_img
            if base.shape[1] < 1500:
                scale = 1500.0 / max(1, base.shape[1])
                base = cv2.resize(base, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
            best = self._find_player_card(base, nickname, engine)
            if not best or best[0] < 0.58:
                self._save_report_parse_debug(f"未在5张卡片中找到昵称：{nickname}")
                return None, f"未在5张卡片中找到昵称：{nickname}"
            sim, nick_sc, nick_txt, card_idx = best
            kills, kill_conf, kill_method = self._read_kill_count_from_card(base, card_idx, engine)
            if kills is None:
                debug_data = {
                    "nickname": nick_txt,
                    "nickname_similarity": float(sim),
                    "card_index": int(card_idx + 1),
                }
                self._save_report_parse_debug("已找到本人卡片，但未读到击杀数K", debug_data)
                return None, "已找到本人卡片，但未读到击杀数K（诊断图已导出）"
            return {
                "nickname": nick_txt,
                "nickname_similarity": float(sim),
                "agent": "不校验角色",
                "kills": int(kills),
                "kill_confidence": float(kill_conf),
                "kill_method": str(kill_method),
                "evaluation": report_evaluation(int(kills)),
                "card_index": int(card_idx + 1),
            }, "ok"
        except Exception as e:
            LOGGER.exception("整局结算页 OCR 失败")
            self._save_report_parse_debug(f"OCR错误:{type(e).__name__}")
            return None, f"OCR错误:{type(e).__name__}"
        finally:
            self._ema_timing("ocr", (time.perf_counter() - t0) * 1000)

    def _scan_whole_match_report(self, grabber, viewport, now):
        if not bool(self.cfg.get("vision", {}).get("report_enabled", True)):
            return
        if not self.report_armed or self.report_done:
            return
        if self.report_snapshot_locked:
            return
        if self.match_context and not self.report_waiting_result:
            return
        if not self.report_waiting_result:
            self._start_report_wait(now, "armed outside live HUD")
        if not self.report_waiting_result or now < self.report_retry_after:
            return

        # Lightweight radar only. No OCR happens here.
        t0 = time.perf_counter()
        cards_radar = _grab_relative_roi(grabber, viewport, ROI_REPORT_CARDS_RADAR, (820,270))
        cont = _grab_relative_roi(grabber, viewport, ROI_REPORT_CONTINUE, (260,100))
        self._ema_timing("capture", (time.perf_counter() - t0) * 1000)
        coarse_ok, layout_score = self._report_layout_candidate(cards_radar, cont)
        five_ok, card_quality, card_counts, card_densities = self._report_five_card_completeness(cards_radar)

        self.last_report_layout_score = float(layout_score)
        self.report_wait_samples += 1
        self.perf_scans += 1
        self.report_capture_best_score = max(self.report_capture_best_score, float(layout_score))

        strict_ok = bool(coarse_ok and five_ok)
        cache_seconds = max(1.0, min(5.0, float(self.cfg.get("vision", {}).get("report_candidate_cache_seconds", 2.8))))

        if strict_ok:
            # Critical V0.4.10.2 change: the first genuine five-card frame is
            # owned immediately. The user may click Continue 0.5s later and the
            # frame is already safe in memory.
            self._cache_report_candidate(grabber, viewport, now, layout_score, card_quality, card_counts)

            sig = self._report_stability_signature(cards_radar, cont)
            stable_need = max(1, int(self.cfg.get("vision", {}).get("report_settle_min_hits", 2)))
            diff_thr = float(self.cfg.get("vision", {}).get("report_settle_diff_threshold", 2.6))
            self.report_candidate_hits += 1
            if self.report_candidate_signature is None:
                self.report_candidate_stable_hits = 0
                self.report_last_signature_diff = 999.0
            else:
                diff = self._report_signature_diff(sig, self.report_candidate_signature)
                self.report_last_signature_diff = float(diff)
                if diff <= diff_thr:
                    self.report_candidate_stable_hits += 1
                else:
                    self.report_candidate_stable_hits = 0
            self.report_candidate_signature = sig

            self.report_parse_status = (
                f"五卡候选已缓存，等待动画定格"
                f"（稳定 {self.report_candidate_stable_hits}/{stable_need}）"
            )

            # If the five-card page survives two near-identical samples, lock
            # the best cached native frame. With 100ms scanning this is usually
            # ~0.2-0.3s after the page is fully visible.
            if self.report_candidate_stable_hits >= stable_need:
                if self._lock_best_report_candidate(now, "five-card page settled"):
                    pass
                else:
                    return
            else:
                return
        else:
            # If a genuine five-card frame was cached and the screen suddenly
            # changes (typically the user clicked Continue), lock the cached
            # frame instead of photographing the new reward/progression page.
            if (self.report_best_candidate_cards is not None and
                    now - float(self.report_best_candidate_at or now) <= cache_seconds):
                if not self._lock_best_report_candidate(now, "five-card page disappeared / Continue clicked"):
                    return
            else:
                # No real scorecard has ever been seen. Do NOT let the post-game
                # reward page become a candidate just because it has dark panels
                # and a red button.
                self.report_candidate_hits = 0
                self.report_candidate_stable_hits = 0
                self.report_candidate_signature = None
                self.report_last_signature_diff = 0.0
                self.report_parse_status = "等待五人结算页"
                return

        # Everything below uses the frozen candidate. Current screen no longer matters.
        data, desc = self._read_whole_match_report(self.report_snapshot_cards)
        self.report_parse_attempts += 1
        if data is None:
            self.report_parse_status = f"解析失败（快照已保留）：{desc}"
            LOGGER.warning("战报快照解析失败，但保持锁定 | %s", desc)
            try:
                stamp = time.strftime("%Y%m%d_%H%M%S")
                cv2.imwrite(str(DEBUG_DIR / f"report_locked_parse_fail_{stamp}.png"), self.report_snapshot_cards)
            except Exception:
                pass
            return

        new_k = int(data.get("kills"))
        self.last_report_nickname = data.get("nickname", "-")
        self.last_report_agent = data.get("agent", "-")
        self.last_report_kills = new_k
        self.report_pending_kills = new_k
        self.report_kill_confirm_hits = 2 if str(data.get("kill_method", "")).startswith("kda-ocr") else 1
        self.report_done = True
        self.report_armed = False
        self.report_armed_since = 0.0
        self.report_last_live_seen = 0.0
        self.report_waiting_result = False
        self.report_capture_active = False
        self.report_retry_after = now + 30.0
        self.report_parse_status = "解析完成，战报已生成"
        LOGGER.info("整局战报完成 | card=%s nickname=%s sim=%.2f kills=%s method=%s conf=%.2f",
                    data.get("card_index"), data.get("nickname"), data.get("nickname_similarity", 0),
                    new_k, data.get("kill_method"), data.get("kill_confidence", 0))
        self.report_ready.emit(data)

    def _build_snapshot(self, game_found=True, foreground=True, paused=False, error=None):
        data={
            "game_found":game_found,"foreground":foreground,"paused":paused,"alive":self.alive_state,
            "alive_score":self.last_alive_score,"hp":self.last_hp,"hp_conf":self.last_hp_conf,"low_hp":self.low_state,
            "hp_history":list(self.hp_history),"hp_enter_votes":self.hp_enter_votes,"hp_exit_votes":self.hp_exit_votes,
            "hp_occluded":self.hp_occluded,"hp_guard_reason":self.hp_guard_reason,"hp_last_confirmed":self.hp_last_confirmed,
            "hp_vote_window":int(self.cfg.get("vision",{}).get("hp_vote_window",5)),
            "kill_count":self.last_kill_count,"kill_score":self.last_kill_score,"nickname_match":self.last_nickname_match,
            "ocr_texts":self.last_ocr_texts,"win_score":self.last_win_score,"loss_score":self.last_loss_score,
            "state":self.current_display_state,"window_title":self.window_title,
            "match_context":self.match_context,"phase":self.phase,"context_votes":self.context_votes,
            "context_left":self.context_left_score,"context_center":self.context_center_score,"context_right":self.context_right_score,
            "death_suspect":self.death_suspect_since is not None,"death_latched":self.death_latched,
            "death_report_score":self.last_death_report_score,"death_evidence":self.last_death_evidence,
            "mode":str(self.cfg.get("vision",{}).get("mode","ultra_low")),"scan_fps":self.scan_fps,
            "cpu_estimate":self.cpu_estimate,"ocr_triggers":self.ocr_trigger_count,"hp_reads":self.hp_read_count,
            "capture_backend":self.backend_name,"timings":dict(self.timings),"worker_busy":self.worker_busy,
            "queue_length":0,"skipped_cycles":self.skipped_cycles,
            "report_armed":self.report_armed,"report_done":self.report_done,"report_layout_score":self.last_report_layout_score,
            "report_nickname":self.last_report_nickname,"report_agent":self.last_report_agent,"report_kills":self.last_report_kills,
            "report_waiting_result":self.report_waiting_result,"report_wait_samples":self.report_wait_samples,
            "report_capture_active":self.report_capture_active,"report_snapshot_locked":self.report_snapshot_locked,
            "report_snapshot_score":self.report_snapshot_score,"report_capture_samples":self.report_capture_samples,
            "report_candidate_hits":self.report_candidate_hits,"report_stable_hits":self.report_candidate_stable_hits,
            "report_candidate_cached":self.report_best_candidate_cards is not None,
            "report_candidate_quality":self.report_best_candidate_quality,
            "report_candidate_counts":list(self.report_best_candidate_counts),
            "report_signature_diff":self.report_last_signature_diff,
            "report_parse_status":self.report_parse_status,"report_parse_attempts":self.report_parse_attempts,
        }
        if error: data["error"]=str(error)
        return data

    def _save_debug_current(self, grabber, viewport, data):
        try:
            vx,vy,vw,vh=viewport; frame=grabber.grab(vx,vy,vw,vh); frame=cv2.resize(frame,(1600,900),interpolation=cv2.INTER_AREA)
            img=frame.copy(); h,w=img.shape[:2]
            boxes={"ctxL":ROI_CONTEXT_LEFT,"ctxC":ROI_CONTEXT_CENTER,"ctxR":ROI_CONTEXT_RIGHT,"alive":ROI_ALIVE,"hp":ROI_HP,"kill":ROI_KILL_OCR,"death":ROI_DEATH_REPORT,"result":ROI_RESULT,"report":ROI_REPORT_CARDS_RADAR}
            colors={"ctxL":(0,255,160),"ctxC":(0,255,160),"ctxR":(0,255,160),"alive":(0,255,0),"hp":(0,180,255),"kill":(255,200,0),"death":(0,80,255),"result":(255,0,255),"report":(160,255,255)}
            for name,b in boxes.items():
                x1,y1,x2,y2=b; cv2.rectangle(img,(int(w*x1),int(h*y1)),(int(w*x2),int(h*y2)),colors[name],2)
            t=data.get("timings",{})
            lines=[
                f"phase={data.get('phase')} match={data.get('match_context')} votes={data.get('context_votes')} L/C/R={data.get('context_left',0):.2f}/{data.get('context_center',0):.2f}/{data.get('context_right',0):.2f}",
                f"backend={data.get('capture_backend')} mode={data.get('mode')} cpu~={data.get('cpu_estimate',0):.1f}% scan={data.get('scan_fps',0):.2f}",
                f"alive={data.get('alive')} score={data.get('alive_score',0):.3f} hp={data.get('hp')} hist={data.get('hp_history')} low={data.get('low_hp')} dead={data.get('death_latched')}",
                f"deathPanel={data.get('death_report_score',0):.3f} evidence={data.get('death_evidence')}",
                f"kill={data.get('kill_count')} nick={data.get('nickname_match')} win={data.get('win_score',0):.3f} loss={data.get('loss_score',0):.3f}",
                f"ms cap={t.get('capture',0):.2f} ctx={t.get('context',0):.2f} alive={t.get('alive',0):.2f} hp={t.get('hp',0):.2f} kill={t.get('kill',0):.2f} death={t.get('death',0):.2f} result={t.get('result',0):.2f} ocr={t.get('ocr',0):.2f}",
            ]
            y=30
            for line in lines:
                cv2.putText(img,line,(16,y),cv2.FONT_HERSHEY_SIMPLEX,0.52,(0,0,0),4,cv2.LINE_AA); cv2.putText(img,line,(16,y),cv2.FONT_HERSHEY_SIMPLEX,0.52,(255,255,255),1,cv2.LINE_AA); y+=24
            path=DEBUG_DIR/f"vision_v041_{time.strftime('%Y%m%d_%H%M%S')}.png"; cv2.imwrite(str(path),img); LOGGER.info("已保存 V0.4 调试帧: %s",path)
        except Exception:
            LOGGER.exception("保存识别调试帧失败")

    def _refresh_window(self, now):
        if self.hwnd and _client_rect_for_hwnd(self.hwnd) and now-self.last_window_lookup<2.0: return True
        found=_find_valorant_window(); self.last_window_lookup=now
        if not found: self.hwnd=None; self.window_title=""; return False
        self.hwnd,_,_,_,_,self.window_title=found; return True

    def run(self):
        try:
            cv2.setNumThreads(1); cv2.ocl.setUseOpenCL(False)
        except Exception: pass
        grabber=None
        try:
            grabber=ScreenGrabber(bool(self.cfg.get("vision",{}).get("prefer_dxcam",True)))
            self.backend_name=grabber.backend
        except Exception as e:
            LOGGER.exception("截图后端初始化失败")
            self.snapshot.emit({"game_found":False,"error":f"capture init: {e}"}); return

        LOGGER.info("VALORANT V0.6 Voice Mouth + Continuous Puppet V2 识别线程启动 backend=%s",self.backend_name)
        try:
            while not self._stop_event.is_set():
                now=time.monotonic(); self._update_perf(now); vcfg=self.cfg.get("vision",{})
                if not bool(vcfg.get("enabled",True)):
                    if now-self.last_snapshot_emit>0.9:
                        data=self._build_snapshot(game_found=False,paused=True); data["disabled"]=True; self.last_snapshot=data; self.snapshot.emit(data); self.last_snapshot_emit=now
                    self._stop_event.wait(0.45); continue
                if not self._refresh_window(now):
                    self.match_context=False; self.context_hits=self.context_misses=0; self._reset_match_state("VALORANT not found")
                    if now-self.last_snapshot_emit>0.9:
                        data=self._build_snapshot(game_found=False); self.snapshot.emit(data); self.last_snapshot_emit=now
                    self._stop_event.wait(0.50); continue
                foreground=True
                if sys.platform=="win32":
                    try: foreground=int(ctypes.windll.user32.GetForegroundWindow())==int(self.hwnd)
                    except Exception: pass
                if bool(vcfg.get("pause_when_background",True)) and not foreground:
                    if self.background_since is None: self.background_since=now
                    if now-self.background_since>1.0: self._request_state("idle","background sleep")
                    if now-self.last_snapshot_emit>0.8:
                        self.snapshot.emit(self._build_snapshot(game_found=True,foreground=False,paused=True)); self.last_snapshot_emit=now
                    self._stop_event.wait(0.45); continue
                self.background_since=None
                client=_client_rect_for_hwnd(self.hwnd)
                if not client: self.hwnd=None; self._stop_event.wait(0.35); continue
                viewport=_viewport_from_client(client)
                context_i,alive_i,hp_i,kill_i,result_i,death_i,emit_i=self._mode_intervals()

                if self.worker_busy:
                    self.skipped_cycles+=1; self._stop_event.wait(0.08); continue
                self.worker_busy=True
                try:
                    if now>=self.next_context:
                        self._scan_context(grabber,viewport,now); self.next_context=now+context_i
                    if self.match_context:
                        if now>=self.next_alive: self._scan_alive(grabber,viewport,now); self.next_alive=now+alive_i
                        if now>=self.next_hp: self._scan_hp(grabber,viewport,now); self.next_hp=now+hp_i
                        if now>=self.next_kill: self._scan_kill_probe(grabber,viewport,now); self.next_kill=now+kill_i
                        if now>=self.next_death: self._scan_death_confirmation(grabber,viewport,now); self.next_death=now+death_i
                    if now>=self.next_result:
                        self._scan_result(grabber,viewport,now); self.next_result=now+result_i
                    if now>=self.next_report:
                        self._scan_whole_match_report(grabber, viewport, now)
                        if self.report_capture_active:
                            # Short high-frequency retry only after a result-like
                            # frame has already appeared.  Still layout-only.
                            cap_ms=max(120,min(400,int(vcfg.get("report_capture_interval_ms",160))))
                            self.next_report=now + cap_ms/1000.0
                        elif self.report_waiting_result:
                            # First 20s after HUD loss: ~5 Hz cheap radar so even a
                            # one-second result page is very likely to be captured.
                            # Afterwards automatically fall back below 2 Hz.
                            fast_s=max(5,min(60,int(vcfg.get("report_wait_fast_seconds",20))))
                            elapsed=max(0.0, now-float(self.report_wait_started or now))
                            if elapsed <= fast_s:
                                wait_ms=max(150,min(500,int(vcfg.get("report_wait_fast_interval_ms",200))))
                            else:
                                wait_ms=max(500,min(1600,int(vcfg.get("report_wait_slow_interval_ms",850))))
                            self.next_report=now + wait_ms/1000.0
                        else:
                            self.next_report=now + max(1.0, int(vcfg.get("report_scan_interval_ms",1400))/1000.0)
                    self._settle_state(now); data=self._build_snapshot(game_found=True,foreground=True,paused=False); self.last_snapshot=data
                    if self._debug_event.is_set(): self._debug_event.clear(); self._save_debug_current(grabber,viewport,data)
                    if now-self.last_snapshot_emit>=emit_i: self.snapshot.emit(data); self.last_snapshot_emit=now
                except Exception as e:
                    LOGGER.exception("V0.6 识别处理失败")
                    if now-self.last_snapshot_emit>0.9: self.snapshot.emit(self._build_snapshot(game_found=True,foreground=foreground,error=e)); self.last_snapshot_emit=now
                finally:
                    self.worker_busy=False

                due=[self.next_context,self.next_result,self.next_report]
                if self.match_context:
                    due.extend([self.next_alive,self.next_hp,self.next_kill,self.next_death])
                next_due=min(due)
                wait_for=max(0.06,min(0.28,next_due-time.monotonic())); self._stop_event.wait(wait_for)
        finally:
            if grabber: grabber.close()
            LOGGER.info("VALORANT V0.6 Voice Mouth + Continuous Puppet V2 识别线程结束")


def _sample_green_key_rgb(rgb):
    """Estimate the greenscreen color from frame corners. Falls back to pure
    green when corners are not green-dominant. This keeps Sage's teal outfit
    because the key model requires strong green dominance, not merely hue.
    """
    h, w = rgb.shape[:2]
    sy = max(2, int(h * 0.07)); sx = max(2, int(w * 0.07))
    samples = np.concatenate([
        rgb[:sy, :sx].reshape(-1, 3), rgb[:sy, -sx:].reshape(-1, 3),
        rgb[-sy:, :sx].reshape(-1, 3), rgb[-sy:, -sx:].reshape(-1, 3)
    ], axis=0)
    key = np.median(samples, axis=0).astype(np.float32)
    r, g, b = key.tolist()
    if g - max(r, b) < 45 or g < 120:
        key = np.array([0.0, 255.0, 0.0], dtype=np.float32)
    return key


def _green_key_rgba(rgb, key_rgb):
    arr = rgb.astype(np.float32)
    key = np.asarray(key_rgb, dtype=np.float32).reshape(1, 1, 3)
    dist = np.linalg.norm(arr - key, axis=2)
    r, g, b = arr[..., 0], arr[..., 1], arr[..., 2]
    dominance = g - np.maximum(r, b)

    # A pixel is keyed only when it is both close to the sampled screen color
    # and strongly green-dominant. Turquoise/teal clothing has much smaller
    # green-vs-blue dominance and therefore remains opaque.
    close = np.clip((118.0 - dist) / 92.0, 0.0, 1.0)
    dom = np.clip((dominance - 22.0) / 125.0, 0.0, 1.0)
    keyness = close * dom
    alpha = np.clip(255.0 * (1.0 - keyness), 0, 255)
    hard_bg = (dist < 30.0) & (dominance > 90.0)
    alpha[hard_bg] = 0.0

    # Despill only where the matte says the pixel is near the screen edge.
    edge = keyness > 0.06
    max_rb = np.maximum(r, b)
    allowed_g = max_rb + 10.0 + 34.0 * (alpha / 255.0)
    g2 = np.where(edge, np.minimum(g, allowed_g), g)
    out = np.dstack([r, g2, b, alpha])
    return np.clip(out, 0, 255).astype(np.uint8)


def _add_soft_white_glow(rgba, outline_px=1, glow_px=6, outline_strength=0.42, glow_strength=0.24):
    """Add a subtle white rim + soft outer glow *behind* an already keyed RGBA frame.

    The source subject RGB/alpha is preserved.  The effect is generated only
    outside the existing alpha matte, so facial features, clothing and teal
    energy details are not washed out.  This is intentionally subtle: a thin
    white edge improves separation, while a broader low-opacity halo helps the
    desktop pet remain readable on dark or busy game backgrounds.
    """
    if rgba is None or rgba.ndim != 3 or rgba.shape[2] != 4:
        return rgba
    src = rgba.astype(np.float32)
    alpha = src[..., 3] / 255.0
    if float(alpha.max()) <= 0.001:
        return rgba

    a8 = np.clip(alpha * 255.0, 0, 255).astype(np.uint8)
    opx = max(1, int(outline_px))
    gpx = max(opx + 1, int(glow_px))

    # Thin rim from a small dilation.
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (opx * 2 + 1, opx * 2 + 1))
    dilated = cv2.dilate(a8, k, iterations=1).astype(np.float32) / 255.0
    outline = np.clip(dilated - alpha, 0.0, 1.0) * float(outline_strength)

    # Wider, feathered halo.  Blur a slightly larger dilation to avoid a harsh
    # neon-looking edge. Keep it strictly outside the original subject matte.
    kg = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (gpx * 2 + 1, gpx * 2 + 1))
    expanded = cv2.dilate(a8, kg, iterations=1)
    sigma = max(1.2, gpx * 0.62)
    blurred = cv2.GaussianBlur(expanded, (0, 0), sigmaX=sigma, sigmaY=sigma).astype(np.float32) / 255.0
    halo = np.clip(blurred - alpha, 0.0, 1.0) * float(glow_strength)
    white_a = np.maximum(outline, halo) * (1.0 - alpha)

    # Straight-alpha source-over composition: original subject over a white
    # halo layer.  Subject pixels remain unchanged; only outside pixels become
    # softly white/transparent.
    out_a = alpha + white_a * (1.0 - alpha)
    numer = src[..., :3] * alpha[..., None] + 255.0 * white_a[..., None] * (1.0 - alpha[..., None])
    denom = np.maximum(out_a[..., None], 1e-6)
    out_rgb = np.where(out_a[..., None] > 1e-6, numer / denom, 0.0)
    out = np.dstack([out_rgb, out_a * 255.0])
    return np.clip(out, 0, 255).astype(np.uint8)


def convert_greenscreen_video(src, dst, max_width=420, target_fps=12):
    """One-time import pipeline: video -> transparent animated WebP.

    Source is first copied to an ASCII temp path because OpenCV/FFmpeg builds on
    some Windows machines still dislike non-ASCII source paths. Animated WebP
    preserves full alpha and avoids GIF's 1-bit transparency/256-color halo.
    """
    src = Path(src); dst = Path(dst); dst.parent.mkdir(parents=True, exist_ok=True)
    tmp_dir = CACHE_DIR / "_import_tmp"; tmp_dir.mkdir(parents=True, exist_ok=True)
    tmp_src = tmp_dir / ("source" + (src.suffix.lower() or ".mp4"))
    shutil.copy2(src, tmp_src)
    cap = cv2.VideoCapture(str(tmp_src))
    try:
        if not cap.isOpened():
            raise RuntimeError("无法读取视频，请确认文件没有损坏")
        fps = float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
        if not np.isfinite(fps) or fps <= 0.5:
            fps = 30.0
        out_fps = max(1.0, min(float(target_fps), fps))
        next_t = 0.0; idx = 0; frames = []; key_rgb = None
        max_frames = int(out_fps * 45)  # safety cap: 45s per desktop-pet clip
        while len(frames) < max_frames:
            ok, bgr = cap.read()
            if not ok:
                break
            t = idx / fps; idx += 1
            if t + 1e-6 < next_t:
                continue
            next_t += 1.0 / out_fps
            h, w = bgr.shape[:2]
            if w > max_width:
                nh = max(2, int(round(h * max_width / w)))
                bgr = cv2.resize(bgr, (max_width, nh), interpolation=cv2.INTER_AREA)
            rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
            if key_rgb is None:
                key_rgb = _sample_green_key_rgb(rgb)
                LOGGER.info("绿幕自动取色 %s -> RGB(%.0f,%.0f,%.0f)", src.name, *key_rgb.tolist())
            rgba = _green_key_rgba(rgb, key_rgb)
            rgba = _add_soft_white_glow(rgba)
            frames.append(Image.fromarray(rgba, "RGBA"))
        if not frames:
            raise RuntimeError("视频没有可读取帧")
        duration = max(20, int(round(1000.0 / out_fps)))
        kwargs = dict(save_all=True, append_images=frames[1:], duration=duration,
                      loop=1, lossless=True, quality=100, method=4)
        try:
            frames[0].save(dst, "WEBP", exact=True, **kwargs)
        except TypeError:
            frames[0].save(dst, "WEBP", **kwargs)
        LOGGER.info("绿幕视频导入完成: %s -> %s | %d帧 @ %.1ffps", src, dst, len(frames), out_fps)
        return len(frames), out_fps
    finally:
        cap.release()
        try: tmp_src.unlink(missing_ok=True)
        except Exception: pass


def add_glow_to_transparent_animation(src, dst):
    """Upgrade an already-transparent animated WebP with the V0.4.8 white rim/glow.

    This is used for assets imported by V0.4.4 so users do not need the original
    greenscreen source just to gain the new outline effect.
    """
    src = Path(src); dst = Path(dst); dst.parent.mkdir(parents=True, exist_ok=True)
    im = Image.open(src)
    frames = []
    durations = []
    try:
        total = int(getattr(im, "n_frames", 1) or 1)
        for i in range(total):
            im.seek(i)
            frame = im.convert("RGBA")
            arr = np.array(frame, dtype=np.uint8)
            arr = _add_soft_white_glow(arr)
            frames.append(Image.fromarray(arr, "RGBA"))
            durations.append(int(im.info.get("duration", 83) or 83))
    finally:
        try: im.close()
        except Exception: pass
    if not frames:
        raise RuntimeError("透明动画没有可读取帧")
    kwargs = dict(save_all=True, append_images=frames[1:], duration=durations,
                  loop=1, lossless=True, quality=100, method=4)
    try:
        frames[0].save(dst, "WEBP", exact=True, **kwargs)
    except TypeError:
        frames[0].save(dst, "WEBP", **kwargs)
    return len(frames)



class AssetDropLabel(QLabel):
    """Per-state drop target for batch importing green-screen videos."""
    files_dropped = Signal(str, object)

    def __init__(self, state, parent=None):
        super().__init__(parent)
        self.state = state
        self.setAcceptDrops(True)
        self.setMinimumHeight(46)
        self.setAlignment(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft)
        self.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self._apply_drop_style(False)
        self.setToolTip("可一次拖入多支视频到本行；支持 MP4 / MOV / MKV / WebM / AVI / M4V，最多补到 20 支。")

    def _apply_drop_style(self, active):
        if active:
            self.setStyleSheet(
                "QLabel{border:2px dashed #5fbfb1;border-radius:8px;"
                "background:rgba(95,191,177,32);padding:6px;}"
            )
        else:
            self.setStyleSheet(
                "QLabel{border:1px dashed rgba(110,110,110,110);border-radius:8px;"
                "background:rgba(255,255,255,10);padding:6px;}"
            )

    def _accepted_paths(self, event):
        md = event.mimeData()
        if not md or not md.hasUrls():
            return []
        out = []
        for url in md.urls():
            if not url.isLocalFile():
                continue
            p = Path(url.toLocalFile())
            if p.is_file() and p.suffix.lower() in VIDEO_EXTS:
                out.append(str(p))
        return out

    def dragEnterEvent(self, event):
        if self._accepted_paths(event):
            self._apply_drop_style(True)
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        if self._accepted_paths(event):
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragLeaveEvent(self, event):
        self._apply_drop_style(False)
        event.accept()

    def dropEvent(self, event):
        paths = self._accepted_paths(event)
        self._apply_drop_style(False)
        if paths:
            event.acceptProposedAction()
            self.files_dropped.emit(self.state, paths)
        else:
            event.ignore()


class ReportLayoutPreview(QWidget):
    layout_changed = Signal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(430, 430)
        self.setMouseTracking(True)
        self.image = QPixmap()
        self.layout_cfg = dict(DEFAULT_REPORT_LAYOUT)
        self.kills = 20
        self.evaluation = report_evaluation(20)
        self.font_family = "Microsoft YaHei"
        self._mode = None
        self._last = None
        self.setStyleSheet("background:#24282d;border:1px solid #555;border-radius:6px;")

    def set_image_path(self, path):
        pix=QPixmap()
        try:
            src=Path(str(path or ""))
            if src.exists():
                im=Image.open(src)
                try:
                    n=int(getattr(im,"n_frames",1) or 1)
                    if n>1: im.seek(n//2)
                    frame=im.convert("RGBA")
                    data=frame.tobytes("raw","RGBA")
                    qi=QImage(data,frame.width,frame.height,QImage.Format.Format_RGBA8888).copy()
                    pix=QPixmap.fromImage(qi)
                finally:
                    try: im.close()
                    except Exception: pass
        except Exception:
            LOGGER.exception("读取战报模板预览失败: %s",path)
        self.image=pix; self.update()

    def set_layout(self, layout):
        self.layout_cfg=normalized_report_layout(layout); self.update()

    def set_sample(self, kills, evaluation):
        self.kills=int(kills); self.evaluation=str(evaluation or ""); self.update()

    def set_font_family(self, family):
        self.font_family=str(family or "Microsoft YaHei"); self.update()

    def _image_rect(self):
        if self.image.isNull(): return QRect(12,12,max(1,self.width()-24),max(1,self.height()-24))
        iw,ih=self.image.width(),self.image.height(); aw=max(1,self.width()-24); ah=max(1,self.height()-24)
        scale=min(aw/iw,ah/ih); w=int(iw*scale); h=int(ih*scale)
        return QRect((self.width()-w)//2,(self.height()-h)//2,w,h)

    def _board_rect(self):
        ir=self._image_rect(); l=self.layout_cfg
        return QRect(int(ir.x()+(l['x']+l['offset_x'])*ir.width()),int(ir.y()+(l['y']+l['offset_y'])*ir.height()),max(12,int(l['w']*ir.width())),max(12,int(l['h']*ir.height())))

    def paintEvent(self,event):
        p=QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing,True)
        ir=self._image_rect()
        if not self.image.isNull(): p.drawPixmap(ir,self.image,self.image.rect())
        overlay=render_report_text_pixmap(ir.width(),ir.height(),self.layout_cfg,self.kills,self.evaluation,self.font_family)
        p.drawPixmap(ir.x(),ir.y(),overlay)
        br=self._board_rect(); pen=QPen(QColor(52,205,163),2,Qt.PenStyle.DashLine); p.setPen(pen); p.setBrush(Qt.BrushStyle.NoBrush); p.drawRect(br)
        p.setBrush(QColor(52,205,163)); p.setPen(Qt.PenStyle.NoPen); p.drawRect(br.right()-6,br.bottom()-6,12,12)
        p.end()

    def mousePressEvent(self,event):
        if event.button()!=Qt.MouseButton.LeftButton: return
        br=self._board_rect(); pos=event.position().toPoint()
        handle=QRect(br.right()-14,br.bottom()-14,28,28)
        if handle.contains(pos): self._mode='resize'
        elif br.contains(pos): self._mode='move'
        else: self._mode=None
        self._last=pos

    def mouseMoveEvent(self,event):
        if not self._mode or self._last is None: return
        pos=event.position().toPoint(); dx=pos.x()-self._last.x(); dy=pos.y()-self._last.y(); self._last=pos
        ir=self._image_rect(); l=dict(self.layout_cfg)
        if ir.width()<=0 or ir.height()<=0: return
        if self._mode=='move':
            l['x']=l['x']+dx/ir.width(); l['y']=l['y']+dy/ir.height()
        else:
            l['w']=l['w']+dx/ir.width(); l['h']=l['h']+dy/ir.height()
        self.layout_cfg=normalized_report_layout(l); self.layout_changed.emit(dict(self.layout_cfg)); self.update()

    def mouseReleaseEvent(self,event):
        self._mode=None; self._last=None


class ReportTemplateDialog(QDialog):
    def __init__(self, cfg, pet, asset_path=None, parent=None):
        super().__init__(parent)
        self.cfg=cfg; self.pet=pet; self.assets=[p for p in _asset_list(cfg.get('assets',{}).get('report')) if Path(p).exists()]
        if not self.assets: self.assets=_asset_list(bundled_assets().get('report'))
        self.current_asset=str(asset_path or (self.assets[0] if self.assets else ''))
        self.current_layout=get_report_layout(cfg,self.current_asset)
        self._dirty=False; self._syncing=False
        self.setWindowTitle('小美丽｜战报白板模板')
        self.setWindowIcon(QIcon(resource('assets/xiaomeili_icon.png'))); self.resize(960,690)
        root=QVBoxLayout(self)
        top=QHBoxLayout(); top.addWidget(QLabel('战报素材：'))
        self.asset_combo=QComboBox()
        for p in self.assets: self.asset_combo.addItem(Path(p).name,p)
        idx=self.asset_combo.findData(self.current_asset); self.asset_combo.setCurrentIndex(max(0,idx))
        self.asset_combo.currentIndexChanged.connect(self._asset_changed); top.addWidget(self.asset_combo,1)
        top.addWidget(HelpBadge('每支战报视频拥有独立白板模板。白板静止时只需设置一次文字区域，之后所有战报都会自动套用。'))
        root.addLayout(top)
        body=QHBoxLayout(); root.addLayout(body,1)
        self.preview=ReportLayoutPreview(); self.preview.layout_changed.connect(self._preview_layout_changed); body.addWidget(self.preview,3)
        controls=QWidget(); form=QFormLayout(controls); body.addWidget(controls,2)
        self.spins={}
        specs=[('x','区域 X (%)',0,95,0.1),('y','区域 Y (%)',0,95,0.1),('w','区域宽度 (%)',5,100,0.1),('h','区域高度 (%)',5,100,0.1),('offset_x','水平偏移 (%)',-30,30,0.1),('offset_y','垂直偏移 (%)',-30,30,0.1),('line1_scale','第一行字号倍率',45,220,1),('line2_scale','第二行字号倍率',45,220,1),('line_spacing','行距 (%)',-10,25,0.1)]
        for key,label,mn,mx,step in specs:
            sp=QDoubleSpinBox(); sp.setRange(mn,mx); sp.setSingleStep(step); sp.setDecimals(1)
            sp.valueChanged.connect(lambda v,k=key:self._spin_changed(k,v)); self.spins[key]=sp; form.addRow(label,sp)
        self.auto_fill=QCheckBox('自动铺满（推荐）'); self.auto_fill.setChecked(True); self.auto_fill.toggled.connect(self._check_changed); form.addRow(self.auto_fill)
        self.outline=QDoubleSpinBox(); self.outline.setRange(0,5); self.outline.setSingleStep(0.5); self.outline.setDecimals(1); self.outline.valueChanged.connect(lambda v:self._spin_changed('outline_width',v)); form.addRow('淡描边 (px)',self.outline)
        sample_box=QGroupBox('四档预览'); sg=QGridLayout(sample_box)
        for i,k in enumerate((5,10,20,30)):
            b=QPushButton(f'{k}杀'); b.clicked.connect(lambda checked=False,n=k:self._set_sample_kills(n)); sg.addWidget(b,0,i)
        form.addRow(sample_box)
        auto_btn=QPushButton('一键自动铺满白板'); auto_btn.clicked.connect(self._auto_fill_default); form.addRow(auto_btn)
        reset_btn=QPushButton('恢复默认模板'); reset_btn.clicked.connect(self._reset_default); form.addRow(reset_btn)
        play_btn=QPushButton('播放动画预览'); play_btn.clicked.connect(self._play_preview); form.addRow(play_btn)
        help_label=QLabel('提示：可直接拖动绿色虚线框移动文字区；拖右下角绿色方块可缩放区域。\n“评价：”前缀已删除，白板只显示评价正文。')
        help_label.setWordWrap(True); help_label.setStyleSheet('color:#666;'); form.addRow(help_label)
        bottom=QHBoxLayout(); self.status=QLabel(''); self.status.setStyleSheet('color:#278a74;'); bottom.addWidget(self.status); bottom.addStretch(1)
        close=QPushButton('关闭'); close.clicked.connect(self.reject); self.save_btn=QPushButton('保存并应用'); self.save_btn.setEnabled(False); self.save_btn.clicked.connect(self._save)
        bottom.addWidget(close); bottom.addWidget(self.save_btn); root.addLayout(bottom)
        self._load_current()

    def _font_family(self):
        try:
            self.pet.report_overlay.reload_font(); return self.pet.report_overlay.font_family
        except Exception: return 'Microsoft YaHei'

    def _load_current(self):
        self.current_layout=get_report_layout(self.cfg,self.current_asset); self._syncing=True
        for k,sp in self.spins.items():
            v=float(self.current_layout.get(k,0.0)); sp.setValue(v*100 if k in ('x','y','w','h','offset_x','offset_y','line_spacing') else v*100)
        self.outline.setValue(float(self.current_layout.get('outline_width',0.0))); self.auto_fill.setChecked(bool(self.current_layout.get('auto_fill',True))); self._syncing=False
        self.preview.set_image_path(self.current_asset); self.preview.set_layout(self.current_layout); self.preview.set_font_family(self._font_family()); self._set_sample_kills(20,mark=False)
        self._dirty=False; self.save_btn.setEnabled(False); self.status.setText('')

    def _asset_changed(self):
        self.current_asset=str(self.asset_combo.currentData() or ''); self._load_current()

    def _mark_dirty(self):
        if self._syncing:return
        self._dirty=True; self.save_btn.setEnabled(True); self.status.setText('未保存')

    def _spin_changed(self,key,value):
        if self._syncing:return
        l=dict(self.current_layout)
        if key in ('x','y','w','h','offset_x','offset_y','line_spacing','line1_scale','line2_scale'): l[key]=float(value)/100.0
        else: l[key]=float(value)
        self.current_layout=normalized_report_layout(l); self.preview.set_layout(self.current_layout); self._mark_dirty()

    def _check_changed(self,v):
        if self._syncing:return
        self.current_layout['auto_fill']=bool(v); self.preview.set_layout(self.current_layout); self._mark_dirty()

    def _preview_layout_changed(self,l):
        self.current_layout=normalized_report_layout(l); self._syncing=True
        for k in ('x','y','w','h','offset_x','offset_y'):
            self.spins[k].setValue(float(self.current_layout[k])*100)
        self._syncing=False; self._mark_dirty()

    def _set_sample_kills(self,kills,mark=False):
        self.preview.set_sample(kills,report_evaluation(kills))
        if mark:self._mark_dirty()

    def _auto_fill_default(self):
        # Keep the proven whiteboard ROI, but let the new font-fitting engine maximize both lines.
        l=dict(self.current_layout); l.update({'x':0.105,'y':0.675,'w':0.790,'h':0.235,'offset_x':0.0,'offset_y':0.0,'line1_scale':1.0,'line2_scale':1.0,'line_spacing':0.02,'auto_fill':True})
        self.current_layout=normalized_report_layout(l); self.preview.set_layout(self.current_layout); self._syncing=True
        for k,sp in self.spins.items():
            if k in self.current_layout: sp.setValue(float(self.current_layout[k])*100)
        self.auto_fill.setChecked(True); self._syncing=False; self._mark_dirty()

    def _reset_default(self):
        self.current_layout=dict(DEFAULT_REPORT_LAYOUT); self.preview.set_layout(self.current_layout); self._syncing=True
        for k,sp in self.spins.items():
            if k in self.current_layout: sp.setValue(float(self.current_layout[k])*100)
        self.outline.setValue(float(self.current_layout['outline_width'])); self.auto_fill.setChecked(True); self._syncing=False; self._mark_dirty()

    def _save(self):
        set_report_layout(self.cfg,self.current_asset,self.current_layout); save_config(self.cfg)
        if getattr(self.pet,'current_asset_path',None)==self.current_asset: self.pet.report_overlay.set_asset(self.current_asset)
        self._dirty=False; self.save_btn.setEnabled(False); self.status.setText('已应用 ✓'); QTimer.singleShot(1600,lambda:self.status.setText(''))
        LOGGER.info('保存战报模板 | asset=%s layout=%s',Path(self.current_asset).name,self.current_layout)

    def _play_preview(self):
        set_report_layout(self.cfg,self.current_asset,self.current_layout); save_config(self.cfg)
        kills=int(self.preview.kills); evaluation=report_evaluation(kills)
        self.pet.report_active=True
        self.pet.play_state('report',force_new_clip=True,asset_override=self.current_asset)
        self.pet.report_overlay.set_asset(self.current_asset)
        self.pet.report_overlay.set_report(kills,evaluation)
        self.pet.report_overlay.raise_()
        self.pet.report_timer.start(max(3000,int(self.cfg.get('report_duration_ms',10000))))



# ----------------------------
# V0.6 local voice subsystem
# ----------------------------
VOICE_DIR = USER / "voice" / "kokoro_v1_1_zh"
VOICE_CACHE_DIR = USER / "voice_cache"
VOICE_DIR.mkdir(parents=True, exist_ok=True)
VOICE_CACHE_DIR.mkdir(parents=True, exist_ok=True)
KOKORO_MODEL = VOICE_DIR / "kokoro-v1.1-zh.onnx"
KOKORO_VOICES = VOICE_DIR / "voices-v1.1-zh.bin"
KOKORO_MODEL_URL = "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.1/kokoro-v1.1-zh.onnx"
KOKORO_VOICES_URL = "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.1/voices-v1.1-zh.bin"
KOKORO_EXPECTED_MODEL_MIN = 300_000_000
KOKORO_EXPECTED_VOICES_MIN = 45_000_000


class VoiceService(QObject):
    """Small local TTS service used by the V0.6 mouth/voice audition stage.

    The model is downloaded once to XiaoMeiliData and then reused by every later
    version. Nothing opens as a second app; synthesis runs in a background thread.
    """
    download_progress = Signal(int, str)
    download_finished = Signal(bool, str)
    voices_ready = Signal(list)
    synthesis_started = Signal()
    synthesis_finished = Signal(bool, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._download_busy = False
        self._load_busy = False
        self._synth_busy = False
        self._lock = threading.RLock()
        self._engine = None
        self._g2p = None
        self._voice_ids = []

    def ready(self):
        try:
            return (
                KOKORO_MODEL.exists() and KOKORO_MODEL.stat().st_size >= KOKORO_EXPECTED_MODEL_MIN
                and KOKORO_VOICES.exists() and KOKORO_VOICES.stat().st_size >= KOKORO_EXPECTED_VOICES_MIN
            )
        except Exception:
            return False

    def component_status(self):
        if self.ready():
            return "语音组件已就绪（本地离线）"
        return "首次使用需准备 Kokoro 中文语音组件（约 380 MB，仅下载一次）"

    @staticmethod
    def _download_one(url, target: Path, progress_cb, base, span, label):
        part = target.with_suffix(target.suffix + ".part")
        try:
            if part.exists():
                part.unlink()
        except Exception:
            pass
        req = urllib.request.Request(url, headers={"User-Agent": "XiaoMeili/0.6"})
        with urllib.request.urlopen(req, timeout=45) as resp, open(part, "wb") as f:
            total = int(resp.headers.get("Content-Length") or 0)
            done = 0
            while True:
                chunk = resp.read(1024 * 1024)
                if not chunk:
                    break
                f.write(chunk)
                done += len(chunk)
                if total > 0:
                    pct = base + int(span * min(1.0, done / total))
                    progress_cb(pct, f"{label}  {done/1024/1024:.0f}/{total/1024/1024:.0f} MB")
                else:
                    progress_cb(base, f"{label}  已下载 {done/1024/1024:.0f} MB")
        part.replace(target)

    def start_download(self):
        if self.ready():
            self.download_progress.emit(100, "语音组件已就绪")
            self.download_finished.emit(True, "语音组件已就绪，无需重复下载。")
            self.load_voices_async()
            return
        if self._download_busy:
            return
        self._download_busy = True

        def job():
            ok = False
            msg = ""
            try:
                VOICE_DIR.mkdir(parents=True, exist_ok=True)
                self.download_progress.emit(1, "正在准备 Kokoro 中文语音模型…")
                if not (KOKORO_MODEL.exists() and KOKORO_MODEL.stat().st_size >= KOKORO_EXPECTED_MODEL_MIN):
                    self._download_one(KOKORO_MODEL_URL, KOKORO_MODEL, self.download_progress.emit, 2, 84, "下载语音模型")
                else:
                    self.download_progress.emit(86, "语音模型已存在，跳过下载")
                if not (KOKORO_VOICES.exists() and KOKORO_VOICES.stat().st_size >= KOKORO_EXPECTED_VOICES_MIN):
                    self._download_one(KOKORO_VOICES_URL, KOKORO_VOICES, self.download_progress.emit, 86, 13, "下载声音库")
                self.download_progress.emit(99, "正在校验语音组件…")
                if not self.ready():
                    raise RuntimeError("下载完成后文件校验失败，请查看日志后重试。")
                ok = True
                msg = "语音组件准备完成。以后可离线使用，不需要再下载。"
                self.download_progress.emit(100, "语音组件已就绪")
            except Exception as e:
                LOGGER.exception("Kokoro 语音组件下载失败")
                msg = f"语音组件准备失败：{type(e).__name__}: {e}"
            finally:
                self._download_busy = False
                self.download_finished.emit(ok, msg)
                if ok:
                    self.load_voices_async()
        threading.Thread(target=job, name="XiaoMeiliVoiceDownload", daemon=True).start()

    def _ensure_engine(self):
        with self._lock:
            if self._engine is not None and self._g2p is not None:
                return self._engine, self._g2p
            if not self.ready():
                raise FileNotFoundError("Kokoro 语音组件尚未准备完成。")
            # Imports stay here so the rest of XiaoMeili can still start even if
            # the optional voice runtime has an installation problem.
            from kokoro_onnx import Kokoro, EspeakConfig
            from misaki import zh
            import espeakng_loader
            espeak_lib = Path(espeakng_loader.get_library_path())
            espeak_data = Path(espeakng_loader.get_data_path())
            if not espeak_lib.exists():
                raise RuntimeError(f"eSpeak-NG 动态库缺失：{espeak_lib}")
            if not espeak_data.exists():
                raise RuntimeError(f"eSpeak-NG 数据目录缺失：{espeak_data}")
            LOGGER.info("eSpeak-NG runtime: lib=%s data=%s", espeak_lib, espeak_data)
            self._engine = Kokoro(
                str(KOKORO_MODEL), str(KOKORO_VOICES),
                espeak_config=EspeakConfig(lib_path=str(espeak_lib), data_path=str(espeak_data)),
            )
            # The v1.1-zh ONNX path currently works most reliably with Misaki's
            # legacy IPA Chinese frontend and is_phonemes=True.
            self._g2p = zh.ZHG2P(version=None)
            return self._engine, self._g2p

    def load_voices_async(self):
        if not self.ready() or self._load_busy:
            return
        if self._voice_ids:
            self.voices_ready.emit(list(self._voice_ids))
            return
        self._load_busy = True

        def job():
            try:
                engine, _ = self._ensure_engine()
                voices = sorted([str(x) for x in engine.get_voices() if str(x).startswith("zf_")])
                self._voice_ids = voices
                self.voices_ready.emit(list(voices))
            except Exception as e:
                LOGGER.exception("读取 Kokoro 声音列表失败")
                self.download_finished.emit(False, f"声音库加载失败：{type(e).__name__}: {e}")
            finally:
                self._load_busy = False
        threading.Thread(target=job, name="XiaoMeiliVoiceLoad", daemon=True).start()

    def preview(self, text, voice_id, speed=1.0):
        text = str(text or "").strip()
        voice_id = str(voice_id or "").strip()
        if not text:
            self.synthesis_finished.emit(False, "请输入试听文字。")
            return
        if not voice_id:
            self.synthesis_finished.emit(False, "请先选择一个声音。")
            return
        if not self.ready():
            self.synthesis_finished.emit(False, "请先准备语音组件。")
            return
        if self._synth_busy:
            self.synthesis_finished.emit(False, "上一条语音还在生成，请稍等。")
            return
        try:
            speed = max(0.70, min(1.30, float(speed)))
        except Exception:
            speed = 1.0
        self._synth_busy = True
        self.synthesis_started.emit()

        def job():
            ok = False
            msg = ""
            try:
                import soundfile as sf
                engine, g2p = self._ensure_engine()
                phonemes, _ = g2p(text)
                if not phonemes or not str(phonemes).strip():
                    raise RuntimeError("中文转音素结果为空。")
                samples, sample_rate = engine.create(
                    phonemes,
                    voice=voice_id,
                    speed=float(speed),
                    is_phonemes=True,
                )
                out = VOICE_CACHE_DIR / "xiaomeili_voice_preview.wav"
                sf.write(str(out), samples, int(sample_rate))
                if sys.platform == "win32":
                    import winsound
                    winsound.PlaySound(str(out), winsound.SND_FILENAME | winsound.SND_ASYNC)
                ok = True
                msg = f"已播放 {voice_id}"
            except Exception as e:
                LOGGER.exception("Kokoro 试听生成失败")
                msg = f"试听失败：{type(e).__name__}: {e}"
            finally:
                self._synth_busy = False
                self.synthesis_finished.emit(ok, msg)
        threading.Thread(target=job, name="XiaoMeiliVoiceSynth", daemon=True).start()


# ----------------------------
# V0.6.1.1 self-update subsystem
# ----------------------------
def _version_tuple(value):
    nums = re.findall(r"\d+", str(value or ""))[:4]
    return tuple(int(x) for x in nums) if nums else (0,)


class UpdateService(QObject):
    status_changed = Signal(str)
    check_finished = Signal(bool, object, str)
    progress_changed = Signal(int, str)
    restart_requested = Signal()

    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self._busy = False
        self._latest_manifest = None

    def manifest_url(self):
        return str(self.cfg.get("updates", {}).get("manifest_url", "") or "").strip()

    def set_manifest_url(self, url):
        if not isinstance(self.cfg.get("updates"), dict):
            self.cfg["updates"] = {}
        self.cfg["updates"]["manifest_url"] = str(url or "").strip()
        save_config(self.cfg)

    def check_async(self):
        if self._busy:
            return
        url = self.manifest_url()
        if not url:
            self.check_finished.emit(False, None, "尚未绑定永久更新源。V0.6.1.1 已具备更新器，请在“更新”页绑定固定 latest.json 地址。")
            return
        self._busy = True
        self.status_changed.emit("正在检查更新…")

        def job():
            try:
                req = urllib.request.Request(url, headers={"User-Agent": f"XiaoMeili/{APP_VERSION}"})
                with urllib.request.urlopen(req, timeout=20) as resp:
                    raw = resp.read(1024 * 1024)
                manifest = json.loads(raw.decode("utf-8-sig"))
                version = str(manifest.get("version", "")).strip()
                package_url = str(manifest.get("package_url", "")).strip()
                if not version or not package_url:
                    raise ValueError("更新清单缺少 version 或 package_url")
                protocol = int(manifest.get("protocol", 1) or 1)
                if protocol > UPDATE_PROTOCOL_VERSION:
                    raise RuntimeError("更新协议版本过新，当前更新器无法安全处理。")
                self._latest_manifest = manifest
                if _version_tuple(version) > _version_tuple(APP_VERSION):
                    notes = manifest.get("notes", "")
                    if isinstance(notes, list):
                        notes = "\n".join("• " + str(x) for x in notes)
                    msg = f"发现新版本 V{version}" + (f"\n{notes}" if notes else "")
                    self.check_finished.emit(True, manifest, msg)
                else:
                    self.check_finished.emit(False, manifest, f"当前已是最新版本 V{APP_VERSION}。")
            except Exception as e:
                LOGGER.exception("检查更新失败")
                self.check_finished.emit(False, None, f"检查更新失败：{type(e).__name__}: {e}")
            finally:
                self._busy = False
        threading.Thread(target=job, name="XiaoMeiliUpdateCheck", daemon=True).start()

    @staticmethod
    def _sha256(path: Path):
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest().lower()

    def install_latest_async(self):
        manifest = self._latest_manifest
        if not isinstance(manifest, dict):
            self.check_finished.emit(False, None, "请先检查更新。")
            return
        if self._busy:
            return
        self._busy = True

        def job():
            try:
                version = str(manifest.get("version", "")).strip()
                url = str(manifest.get("package_url", "")).strip()
                expected = str(manifest.get("sha256", "") or "").strip().lower()
                package = UPDATE_DIR / f"XiaoMeili_{version}_update.zip"
                part = package.with_suffix(".zip.part")
                try:
                    part.unlink(missing_ok=True)
                except Exception:
                    pass
                req = urllib.request.Request(url, headers={"User-Agent": f"XiaoMeili/{APP_VERSION}"})
                with urllib.request.urlopen(req, timeout=45) as resp, open(part, "wb") as f:
                    total = int(resp.headers.get("Content-Length") or 0)
                    done = 0
                    while True:
                        chunk = resp.read(1024 * 1024)
                        if not chunk:
                            break
                        f.write(chunk)
                        done += len(chunk)
                        pct = int(done * 100 / total) if total else 0
                        self.progress_changed.emit(max(0, min(99, pct)), f"正在下载 V{version}…")
                part.replace(package)
                if expected:
                    actual = self._sha256(package)
                    if actual != expected:
                        raise RuntimeError(f"更新包校验失败。期望 {expected}，实际 {actual}")
                helper = Path(resource("assets/update_helper.ps1"))
                if not helper.exists():
                    raise FileNotFoundError(f"更新助手缺失：{helper}")
                if not getattr(sys, "frozen", False):
                    raise RuntimeError("开发模式不执行覆盖更新，请在正式 XiaoMeili.exe 中测试。")
                target = Path(sys.executable).parent
                exe_name = Path(sys.executable).name
                desktop_log = desktop_dir() / "小美丽更新错误日志_请上传给ChatGPT.txt"
                args = [
                    "powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass",
                    "-File", str(helper),
                    "-Package", str(package),
                    "-Target", str(target),
                    "-ExeName", exe_name,
                    "-Pid", str(os.getpid()),
                    "-DesktopLog", str(desktop_log),
                ]
                subprocess.Popen(args, cwd=str(UPDATE_DIR), creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                self.progress_changed.emit(100, "更新包已准备，正在重启安装…")
                self.restart_requested.emit()
            except Exception as e:
                LOGGER.exception("安装更新失败")
                self.check_finished.emit(False, None, f"安装更新失败：{type(e).__name__}: {e}")
            finally:
                self._busy = False
        threading.Thread(target=job, name="XiaoMeiliUpdateInstall", daemon=True).start()


class SettingsDialog(QDialog):
    hotkeys_changed = Signal()
    config_changed = Signal()

    def __init__(self, cfg, pet: PetWindow, vision: VisionWorker, voice_service, update_service, parent=None):
        super().__init__(parent)
        # Give the settings dialog normal Windows title-bar controls: minimize + close,
        # while intentionally keeping maximize disabled.
        self.setWindowFlag(Qt.WindowType.WindowSystemMenuHint, True)
        self.setWindowFlag(Qt.WindowType.WindowMinimizeButtonHint, True)
        self.setWindowFlag(Qt.WindowType.WindowMaximizeButtonHint, False)
        self.setWindowFlag(Qt.WindowType.WindowCloseButtonHint, True)
        self.setWindowFlag(Qt.WindowType.WindowContextHelpButtonHint, False)
        self.cfg = cfg
        self.pet = pet
        self.vision = vision
        self.voice_service = voice_service
        self.update_service = update_service
        self.asset_labels = {}
        self._dirty = False
        self.setWindowTitle("小美丽 V0.6.1 设置")
        self.setWindowIcon(QIcon(resource("assets/xiaomeili_icon.png")))
        self.resize(720, 580)
        root = QVBoxLayout(self)
        self.tabs = QTabWidget(); root.addWidget(self.tabs)

        # General
        page = QWidget(); form = QFormLayout(page)
        self.top_cb = QCheckBox("永远置顶"); self.top_cb.setChecked(cfg.get("always_on_top", True))
        self.lock_cb = QCheckBox("锁定（固定位置 + 点击穿透）"); self.lock_cb.setChecked(bool(cfg.get("click_through", False)))
        form.addRow(self.top_cb); form.addRow(self.lock_cb)
        hint = QLabel("锁定后小美丽不会拦截鼠标；把鼠标移到小美丽身上，右上角仍会出现解锁按钮。")
        hint.setWordWrap(True); form.addRow(hint)
        self.opacity = QSlider(Qt.Orientation.Horizontal); self.opacity.setRange(30,100); self.opacity.setValue(cfg.get("opacity",100))
        form.addRow("透明度", self.opacity)
        self.size_spin = QSpinBox(); self.size_spin.setRange(120,600); self.size_spin.setValue(cfg.get("pet_width",280)); self.size_spin.setSuffix(" px")
        form.addRow("桌宠宽度", self.size_spin)
        self.trans_spin = QSpinBox(); self.trans_spin.setRange(0,1000); self.trans_spin.setValue(cfg.get("transition_ms",220)); self.trans_spin.setSuffix(" ms")
        form.addRow("动画切换过渡", self.trans_spin)
        self.mouse_interaction_cb = QCheckBox("启用鼠标互动基础版")
        self.mouse_interaction_cb.setChecked(bool(cfg.get("mouse_interaction", {}).get("enabled", True)))
        form.addRow(self.mouse_interaction_cb)
        mouse_hint = QLabel("仅在普通待机时生效：鼠标进入小美丽周围的隐形注意区并移动后，切入连续互动版。眼睛、头部、身体、头发、耳环都会顺滑跟随鼠标；游戏击杀/低血量/胜负/战报等状态会立即抢占。鼠标离开或长时间不动后自动回到随机待机视频。")
        mouse_hint.setWordWrap(True); form.addRow(mouse_hint)
        reset_btn = QPushButton("重置到屏幕左上"); reset_btn.clicked.connect(lambda:self.pet.move(100,100)); form.addRow(reset_btn)
        self.tabs.addTab(page,"常规")

        # Hotkeys. A dedicated clear button makes "no shortcut" explicit.
        hp = QWidget(); hv = QVBoxLayout(hp)
        self.hk_table = QTableWidget(9,3)
        self.hk_table.setHorizontalHeaderLabels(["功能","快捷键","操作"])
        self.hk_table.horizontalHeader().setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch)
        self.hk_table.horizontalHeader().setSectionResizeMode(1,QHeaderView.ResizeMode.Stretch)
        self.hk_table.horizontalHeader().setSectionResizeMode(2,QHeaderView.ResizeMode.ResizeToContents)
        hk_rows = [
            ("idle","待机"),("low_hp","低血量"),("kill","击杀"),("dead","被击杀"),("victory","获胜"),("defeat","失败"),
            ("toggle_lock","锁定/解锁（含点击穿透）"),("settings","打开设置"),("show_hide","显示/隐藏桌宠")
        ]
        self.hk_editors={}
        for r,(key,name) in enumerate(hk_rows):
            self.hk_table.setItem(r,0,QTableWidgetItem(name))
            e=QKeySequenceEdit(QKeySequence(cfg.get("hotkeys",{}).get(key,"")))
            self.hk_table.setCellWidget(r,1,e); self.hk_editors[key]=e
            clear_btn=QPushButton("清除")
            clear_btn.setToolTip("清空后，该功能不注册任何全局快捷键")
            clear_btn.clicked.connect(lambda checked=False, ed=e: ed.clear())
            self.hk_table.setCellWidget(r,2,clear_btn)
        hk_hint=QLabel("快捷键可以完全留空。点击右侧“清除”后保存并应用，即不会为该功能注册快捷键。")
        hk_hint.setWordWrap(True); hv.addWidget(hk_hint)
        hv.addWidget(self.hk_table); self.tabs.addTab(hp,"快捷键")

        # Animation asset pools: each state supports up to 20 clips and random rotation.
        ap = QWidget(); av = QVBoxLayout(ap)
        title_row = QHBoxLayout()
        title = QLabel("6 个识别状态 + 1 个战报状态 → 每个状态最多 20 支视频")
        title.setStyleSheet("font-weight:600; font-size:15px;")
        title_row.addWidget(title); title_row.addWidget(HelpBadge(
            "绿幕视频导入后会自动抠绿、去绿边、添加淡白边/柔光并缓存为透明 WebP。\n"
            "支持按钮导入或批量拖拽。随机播放采用有放回抽取，允许连续抽到同一支。\n"
            "‘战报’状态默认使用你提供的10秒静止白板模板。"))
        title_row.addStretch(1); av.addLayout(title_row)
        grid = QGridLayout(); grid.setColumnStretch(1,1)
        grid.addWidget(QLabel("状态"),0,0); grid.addWidget(QLabel("素材池"),0,1)
        for c in range(2,6): grid.addWidget(QLabel(""),0,c)
        for row,(key,name) in enumerate(STATE_NAMES.items(), start=1):
            grid.addWidget(QLabel(name),row,0)
            lab=AssetDropLabel(key)
            lab.files_dropped.connect(self._on_asset_files_dropped)
            self.asset_labels[key]=lab; self._refresh_asset_label(key)
            grid.addWidget(lab,row,1)
            btn=QPushButton("导入视频")
            btn.clicked.connect(lambda checked=False,s=key:self.import_video_for(s))
            grid.addWidget(btn,row,2)
            manage=QPushButton("管理")
            manage.clicked.connect(lambda checked=False,s=key:self.manage_assets(s))
            grid.addWidget(manage,row,3)
            if key=="report":
                templ=QPushButton("模板")
                templ.setToolTip("调整战报白板文字区域、字号、行距和位置，并实时预览。")
                templ.clicked.connect(self.open_report_template_editor)
                grid.addWidget(templ,row,4)
                test=QPushButton("测试")
                test.clicked.connect(self.test_report_preview)
                grid.addWidget(test,row,5)
            else:
                grid.addWidget(QWidget(),row,4)
                test=QPushButton("测试")
                test.clicked.connect(lambda checked=False,s=key:self.pet.play_state(s, force_new_clip=True))
                grid.addWidget(test,row,5)
        av.addLayout(grid)
        helper_row=QHBoxLayout()
        helper_row.addWidget(QLabel("批量拖拽 / 随机规则"))
        helper_row.addWidget(HelpBadge("从资源管理器一次选中多支视频，直接拖到对应状态素材框即可批量导入；每个状态最多20支。每次播放完重新独立抽签，允许 1→1→2、3→3→3 等连续重复。"))
        helper_row.addStretch(1); av.addLayout(helper_row)

        font_row=QHBoxLayout()
        font_row.addWidget(QLabel("战报字体："))
        self.report_font_label=QLabel(self._report_font_status())
        font_row.addWidget(self.report_font_label,1)
        import_font_btn=QPushButton("导入战报字体")
        import_font_btn.clicked.connect(self.import_report_font)
        font_row.addWidget(import_font_btn)
        font_row.addWidget(HelpBadge("战报动态文字固定使用 MaokenAssortedSans-Lite.otf（猫啃什锦黑-轻量版）。选择一次后会复制到 XiaoMeiliData/fonts，后续升级继续使用。"))
        av.addLayout(font_row)

        migrate_glow=QPushButton("为旧版已导入素材补上白边 / 柔光")
        migrate_glow.setToolTip("将 V0.4.4 及更早版本已经抠好透明底的 WebP 重新加上淡白边/柔光，不需要原绿幕视频。")
        migrate_glow.clicked.connect(self.upgrade_existing_assets_glow)
        av.addWidget(migrate_glow)
        restore=QPushButton("恢复 7 种内置占位动画")
        restore.clicked.connect(self.restore_assets); av.addWidget(restore); av.addStretch(1)
        self.tabs.addTab(ap,"动画素材")

        # Voice V0.6: choose one built-in Chinese female voice and keep it forever.
        sp = QWidget(); sv = QVBoxLayout(sp)
        intro = QLabel(
            "V0.6 第一阶段只给小美丽装上“嘴”：先从 Kokoro 中文女声库里试听并选定一个固定声音。"
            "\n本阶段暂不接麦克风、唤醒词和大模型，避免一次引入太多变量。"
        )
        intro.setWordWrap(True); sv.addWidget(intro)

        voice_box = QGroupBox("小美丽固定声音"); vf2 = QFormLayout(voice_box)
        self.voice_status = QLabel(self.voice_service.component_status())
        self.voice_status.setWordWrap(True)
        vf2.addRow("组件状态", self.voice_status)
        self.voice_progress = QProgressBar(); self.voice_progress.setRange(0,100); self.voice_progress.setValue(100 if self.voice_service.ready() else 0)
        vf2.addRow("首次准备", self.voice_progress)
        self.voice_prepare_btn = QPushButton("准备语音组件（首次约 380 MB）")
        self.voice_prepare_btn.setEnabled(not self.voice_service.ready())
        self.voice_prepare_btn.clicked.connect(self._prepare_voice_components)
        vf2.addRow(self.voice_prepare_btn)

        self.voice_combo = QComboBox(); self.voice_combo.setMinimumContentsLength(22)
        self.voice_combo.setEnabled(False)
        vf2.addRow("中文女声", self.voice_combo)

        nav = QWidget(); nav_l = QHBoxLayout(nav); nav_l.setContentsMargins(0,0,0,0)
        prev_btn = QPushButton("上一位"); next_btn = QPushButton("下一位")
        prev_btn.clicked.connect(lambda: self._step_voice(-1)); next_btn.clicked.connect(lambda: self._step_voice(1))
        self.voice_preview_btn = QPushButton("▶ 试听当前声音"); self.voice_preview_btn.setEnabled(False)
        self.voice_preview_btn.clicked.connect(self._preview_voice)
        nav_l.addWidget(prev_btn); nav_l.addWidget(self.voice_preview_btn); nav_l.addWidget(next_btn)
        vf2.addRow("海选", nav)

        self.voice_test_text = QLineEdit(str(cfg.get("voice",{}).get("test_text") or "美丽美丽，我在呢。今天又想让我陪你干嘛？"))
        self.voice_test_text.setMaxLength(120)
        vf2.addRow("试听台词", self.voice_test_text)
        self.voice_speed = QDoubleSpinBox(); self.voice_speed.setRange(0.70,1.30); self.voice_speed.setSingleStep(0.05); self.voice_speed.setDecimals(2)
        self.voice_speed.setValue(float(cfg.get("voice",{}).get("speed",1.0) or 1.0)); self.voice_speed.setSuffix(" ×")
        vf2.addRow("语速", self.voice_speed)

        self.voice_fixed_label = QLabel("当前固定：" + (str(cfg.get("voice",{}).get("voice_id")) or "尚未选择"))
        self.voice_fixed_label.setStyleSheet("font-weight:600;")
        vf2.addRow(self.voice_fixed_label)
        self.voice_fix_btn = QPushButton("设为小美丽固定声音")
        self.voice_fix_btn.setEnabled(False); self.voice_fix_btn.clicked.connect(self._fix_current_voice)
        vf2.addRow(self.voice_fix_btn)
        sv.addWidget(voice_box)

        voice_note = QLabel(
            "说明：模型和声音库只会保存在本机 XiaoMeiliData/voice 中。选定后，后续语音对话版本直接复用这个 voice ID，"
            "你不需要再打开任何 TTS 软件。"
        )
        voice_note.setWordWrap(True); sv.addWidget(voice_note); sv.addStretch(1)
        self.tabs.addTab(sp,"声音 V0.6.1")

        self.voice_service.download_progress.connect(self._voice_download_progress)
        self.voice_service.download_finished.connect(self._voice_download_finished)
        self.voice_service.voices_ready.connect(self._voice_list_ready)
        self.voice_service.synthesis_started.connect(self._voice_synth_started)
        self.voice_service.synthesis_finished.connect(self._voice_synth_finished)
        if self.voice_service.ready():
            self.voice_service.load_voices_async()

        # Updates V0.6.1
        up = QWidget(); uv = QVBoxLayout(up)
        u_intro = QLabel(
            "从 V0.6.1 起，小美丽内置自更新器。以后只要更新源已经绑定，修复 Bug 或增加功能都可以直接在这里检查并更新，不再重新下载整包。"
            "\n注意：V0.6.0 本身没有更新器，所以升级到 V0.6.1 仍然是最后一次手动安装。"
        )
        u_intro.setWordWrap(True); uv.addWidget(u_intro)
        ubox = QGroupBox("检查更新"); uf = QFormLayout(ubox)
        self.update_version_label = QLabel(f"V{APP_VERSION}")
        uf.addRow("当前版本", self.update_version_label)
        self.update_url = QLineEdit(self.update_service.manifest_url())
        self.update_url.setPlaceholderText("永久更新清单地址（latest.json），绑定一次即可")
        uf.addRow("更新源", self.update_url)
        save_source = QPushButton("保存更新源")
        save_source.clicked.connect(self._save_update_source)
        uf.addRow(save_source)
        self.update_status = QLabel("尚未检查更新")
        self.update_status.setWordWrap(True); uf.addRow("状态", self.update_status)
        self.update_progress = QProgressBar(); self.update_progress.setRange(0,100); self.update_progress.setValue(0)
        uf.addRow("更新进度", self.update_progress)
        row = QWidget(); rl = QHBoxLayout(row); rl.setContentsMargins(0,0,0,0)
        self.update_check_btn = QPushButton("检查更新")
        self.update_install_btn = QPushButton("立即更新")
        self.update_install_btn.setEnabled(False)
        self.update_check_btn.clicked.connect(self._check_update)
        self.update_install_btn.clicked.connect(self._install_update)
        rl.addWidget(self.update_check_btn); rl.addWidget(self.update_install_btn)
        uf.addRow(row)
        uv.addWidget(ubox)
        unote = QLabel(
            "更新包会先下载到 XiaoMeiliData/updates，完成 SHA-256 校验后由内部更新助手替换程序文件并自动重启。"
            "个人配置、声音模型、动作素材和日志都保存在 XiaoMeiliData，不会因程序升级被覆盖。"
        )
        unote.setWordWrap(True); uv.addWidget(unote); uv.addStretch(1)
        self.tabs.addTab(up, "更新")
        self.update_service.status_changed.connect(self.update_status.setText)
        self.update_service.check_finished.connect(self._update_check_finished)
        self.update_service.progress_changed.connect(self._update_progress_changed)

        # Vision
        vp=QWidget(); vv=QVBoxLayout(vp)
        box=QGroupBox("VALORANT 自动识别（仅分析屏幕像素）"); vf=QFormLayout(box)
        self.vision_enabled=QCheckBox("启用自动识别")
        self.vision_enabled.setChecked(bool(cfg.get("vision",{}).get("enabled",True)))
        vf.addRow(self.vision_enabled)
        self.nickname_edit = QLineEdit(str(cfg.get("vision",{}).get("player_nickname", "")))
        self.nickname_edit.setPlaceholderText("例如：我是朱棣（填写游戏击杀信息中显示的昵称）")
        nick_label=QWidget(); nick_lay=QHBoxLayout(nick_label); nick_lay.setContentsMargins(0,0,0,0)
        nick_lay.addWidget(QLabel("我的游戏昵称")); nick_lay.addWidget(HelpBadge("用于击杀栏二次校验，也用于整局结算页在5张玩家卡片中找到你。换账号或改名后只需要修改这里。")); nick_lay.addStretch(1)
        vf.addRow(nick_label, self.nickname_edit)
        self.hp_threshold=QSpinBox(); self.hp_threshold.setRange(1,99); self.hp_threshold.setValue(int(cfg.get("vision",{}).get("low_hp_threshold",50)))
        self.hp_threshold.setSuffix(" HP")
        vf.addRow("低血量触发阈值 ≤",self.hp_threshold)
        self.mode_combo = QComboBox()
        self.mode_combo.addItem("极低功耗模式（推荐）", "ultra_low")
        self.mode_combo.addItem("调试模式（更高刷新率）", "debug")
        current_mode = str(cfg.get("vision", {}).get("mode", "ultra_low"))
        idx = self.mode_combo.findData(current_mode)
        self.mode_combo.setCurrentIndex(idx if idx >= 0 else 0)
        vf.addRow("识别模式", self.mode_combo)
        self.pause_bg = QCheckBox("VALORANT 不在前台时自动休眠")
        self.pause_bg.setChecked(bool(cfg.get("vision", {}).get("pause_when_background", True)))
        vf.addRow(self.pause_bg)
        self.nickname_ocr_cb = QCheckBox("昵称 OCR 二次校验（仅在贤者头像判断模糊时启用）")
        self.nickname_ocr_cb.setChecked(bool(cfg.get("vision", {}).get("nickname_ocr_fallback", True)))
        vf.addRow(self.nickname_ocr_cb)
        logic_row=QHBoxLayout(); logic_row.addWidget(QLabel("识别说明")); logic_row.addWidget(HelpBadge(
            "先确认顶部真实比赛HUD，再允许存活/HP/击杀/死亡/胜负识别；大厅、选人和加载界面保持待机。\n"
            "整局战报与英雄选择解耦：真实对局期间战报OCR完全休眠，只登记本局。直播HUD消失后的前20秒使用约5FPS轻量雷达，之后自动降频。检测到真正的五人结算卡后会立刻把最佳高清候选帧缓存到内存；随后再等待短暂稳定确认。即使你在0.5秒左右马上点“继续”，也会使用刚缓存的五卡画面，而不会误截后面的奖励/再玩一局页面。之后只解析昵称和K，D和A不参与结果判断。")); logic_row.addStretch(1)
        vf.addRow(logic_row)
        vv.addWidget(box)

        live=QGroupBox("战报识别状态"); lv=QVBoxLayout(live)
        self.report_snapshot_status=QLabel("战报快照：未锁定")
        self.report_snapshot_status.setStyleSheet("font-size:16px;font-weight:700;color:#D62828;padding:4px 0;")
        self.report_parse_label=QLabel("战报解析：等待结算动画结束")
        self.report_parse_label.setWordWrap(True)
        lv.addWidget(self.report_snapshot_status)
        lv.addWidget(self.report_parse_label)
        self.vision_status=QLabel("等待识别数据...")
        self.vision_status.setWordWrap(True); self.vision_status.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.vision_status.setVisible(False)
        self.diag_btn=QPushButton("显示高级诊断")
        self.diag_btn.setCheckable(True)
        def _toggle_diag(checked):
            self.vision_status.setVisible(bool(checked))
            self.diag_btn.setText("隐藏高级诊断" if checked else "显示高级诊断")
        self.diag_btn.toggled.connect(_toggle_diag)
        lv.addWidget(self.diag_btn)
        lv.addWidget(self.vision_status)
        brow=QHBoxLayout()
        debug_btn=QPushButton("保存下一帧识别调试图")
        debug_btn.clicked.connect(self.request_debug)
        open_debug=QPushButton("打开调试目录")
        open_debug.clicked.connect(lambda: os.startfile(str(DEBUG_DIR)) if sys.platform=='win32' else None)
        report_test_btn=QPushButton("从截图测试战报")
        report_test_btn.setToolTip("跳过真实对局流程，直接用一张整局结算页截图测试：结算布局 → 昵称定位本人卡片 → 只读K数字 → 白板展示。")
        report_test_btn.clicked.connect(self.test_report_from_screenshot)
        brow.addWidget(debug_btn); brow.addWidget(report_test_btn); brow.addWidget(open_debug); lv.addLayout(brow)
        vv.addWidget(live); vv.addStretch(1)
        self.tabs.addTab(vp,"游戏识别")

        # Logs
        lp=QWidget(); ll=QVBoxLayout(lp)
        ll.addWidget(QLabel(f"日志目录：\n{LOG_DIR}\n\n当前日志：\n{CURRENT_LOG}"))
        openlog=QPushButton("打开日志文件夹")
        openlog.clicked.connect(lambda: os.startfile(str(LOG_DIR)) if sys.platform=='win32' else None)
        ll.addWidget(openlog); ll.addStretch(1); self.tabs.addTab(lp,"日志")

        buttons=QHBoxLayout()
        self.apply_status = QLabel("")
        self.apply_status.setStyleSheet("color:#2a8f78;")
        buttons.addWidget(self.apply_status)
        buttons.addStretch(1)
        close_btn=QPushButton("关闭")
        self.save_btn=QPushButton("保存并应用")
        self.save_btn.setEnabled(False)
        close_btn.clicked.connect(self.reject); self.save_btn.clicked.connect(self.apply)
        buttons.addWidget(close_btn); buttons.addWidget(self.save_btn); root.addLayout(buttons)
        self._bind_dirty_tracking()

    def _prepare_voice_components(self):
        self.voice_prepare_btn.setEnabled(False)
        self.voice_status.setText("正在准备语音组件，请保持网络连接。完成后以后可离线使用。")
        self.voice_service.start_download()

    def _voice_download_progress(self, value, text):
        if not self.isVisible():
            return
        self.voice_progress.setValue(max(0, min(100, int(value))))
        self.voice_status.setText(str(text))

    def _voice_download_finished(self, ok, message):
        if not self.isVisible():
            return
        self.voice_status.setText(str(message))
        self.voice_prepare_btn.setEnabled(not bool(ok))
        if ok:
            self.voice_progress.setValue(100)
            self.voice_service.load_voices_async()

    def _voice_list_ready(self, voices):
        if not self.isVisible():
            return
        voices = [str(v) for v in (voices or []) if str(v).startswith("zf_")]
        current = str(self.cfg.get("voice",{}).get("voice_id","") or "")
        selected = self.voice_combo.currentData()
        self.voice_combo.blockSignals(True)
        self.voice_combo.clear()
        for idx, vid in enumerate(voices, start=1):
            suffix = vid.split("_",1)[-1]
            self.voice_combo.addItem(f"女声 {suffix}  ·  {vid}", vid)
        target = current or selected
        if target:
            i = self.voice_combo.findData(target)
            if i >= 0:
                self.voice_combo.setCurrentIndex(i)
        self.voice_combo.blockSignals(False)
        ready = self.voice_combo.count() > 0
        self.voice_combo.setEnabled(ready)
        self.voice_preview_btn.setEnabled(ready)
        self.voice_fix_btn.setEnabled(ready)
        if ready:
            self.voice_status.setText(f"声音库已就绪：{self.voice_combo.count()} 个中文女声可试听。")
        else:
            self.voice_status.setText("语音组件已下载，但没有读取到中文女声。请查看日志。")

    def _step_voice(self, delta):
        if self.voice_combo.count() <= 0:
            return
        self.voice_combo.setCurrentIndex((self.voice_combo.currentIndex() + int(delta)) % self.voice_combo.count())
        self._preview_voice()

    def _preview_voice(self):
        vid = self.voice_combo.currentData()
        if not vid:
            QMessageBox.information(self,"声音试听","请先准备语音组件并选择声音。")
            return
        text = self.voice_test_text.text().strip()
        if not text:
            text = "美丽美丽，我在呢。今天又想让我陪你干嘛？"
            self.voice_test_text.setText(text)
        self.voice_service.preview(text, str(vid), self.voice_speed.value())

    def _voice_synth_started(self):
        if self.isVisible():
            self.voice_preview_btn.setEnabled(False)
            self.voice_status.setText("正在生成试听语音…")

    def _voice_synth_finished(self, ok, message):
        if not self.isVisible():
            return
        self.voice_preview_btn.setEnabled(self.voice_combo.count() > 0)
        self.voice_status.setText(str(message))

    def _fix_current_voice(self):
        vid = str(self.voice_combo.currentData() or "").strip()
        if not vid:
            return
        if not isinstance(self.cfg.get("voice"), dict):
            self.cfg["voice"] = {}
        self.cfg["voice"]["voice_id"] = vid
        self.cfg["voice"]["speed"] = float(self.voice_speed.value())
        self.cfg["voice"]["test_text"] = self.voice_test_text.text().strip()
        save_config(self.cfg)
        self.voice_fixed_label.setText(f"当前固定：{vid}")
        self.voice_status.setText(f"已固定为 {vid}。后续小美丽所有语音都默认使用这个声音。")

    def _refresh_asset_label(self,state):
        pool = _asset_list(self.cfg.get("assets",{}).get(state))
        user = [p for p in pool if _is_user_asset(p) and Path(p).exists()]
        lab=self.asset_labels.get(state)
        if lab:
            lab.setText(f"{len(user)}/{MAX_ASSETS_PER_STATE} 支")
            lab.setToolTip("可一次拖入多支视频到本行；自动抠绿、白边/柔光；最多20支。")

    def _on_asset_files_dropped(self, state, paths):
        """Handle batch drag-and-drop from an animation-state drop zone.

        This handler receives AssetDropLabel.files_dropped
        without carrying the handler across from V0.4.8, which made the
        Settings dialog fail during construction. Keep all drop imports on the
        same validated path as the Import Video button.
        """
        self.import_video_paths_for(state, list(paths or []), source="drop")

    def _report_font_status(self):
        pth=str(self.cfg.get("report_font_path","") or "")
        return "猫啃什锦黑-轻量版（已就绪）" if pth and Path(pth).exists() else "未导入（请选 MaokenAssortedSans-Lite.otf）"

    def import_report_font(self):
        path,_=QFileDialog.getOpenFileName(self,"选择小美丽战报字体",str(Path.home()),"OpenType/TrueType (*.otf *.ttf)")
        if not path: return
        try:
            REPORT_FONT_DIR.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, REPORT_FONT_LOCAL)
            self.cfg["report_font_path"] = str(REPORT_FONT_LOCAL)
            save_config(self.cfg)
            self.pet.report_overlay.reload_font()
            self.report_font_label.setText(self._report_font_status())
            QMessageBox.information(self,"字体已导入","战报动态文字将固定使用这款字体。")
        except Exception as e:
            LOGGER.exception("导入战报字体失败")
            QMessageBox.critical(self,"字体导入失败",str(e))

    def open_report_template_editor(self, asset_path=None):
        dlg=ReportTemplateDialog(self.cfg,self.pet,asset_path=asset_path,parent=self)
        dlg.exec()

    def test_report_preview(self):
        kills,ok=QInputDialog.getInt(self,"测试战报白板","模拟击杀数：",21,0,99,1)
        if not ok:return
        self.pet.show_report({"kills":int(kills),"evaluation":report_evaluation(int(kills)),"nickname":"手动预览","agent":"-"})

    def import_video_for(self,state):
        current = [p for p in _asset_list(self.cfg.get("assets",{}).get(state)) if _is_user_asset(p) and Path(p).exists()]
        remaining = max(0, MAX_ASSETS_PER_STATE-len(current))
        if remaining <= 0:
            QMessageBox.information(self,"素材池已满",f"「{STATE_NAMES[state]}」已经有 20 支视频。请先点“管理”移除不需要的素材。")
            return
        paths,_=QFileDialog.getOpenFileNames(self,f"为「{STATE_NAMES[state]}」选择绿幕视频（还可导入 {remaining} 支）",str(Path.home()),"Video (*.mp4 *.mov *.mkv *.webm *.avi *.m4v)")
        if paths:
            self.import_video_paths_for(state, paths, source="dialog")

    def import_video_paths_for(self, state, paths, source="drop"):
        current = [p for p in _asset_list(self.cfg.get("assets",{}).get(state)) if _is_user_asset(p) and Path(p).exists()]
        remaining = max(0, MAX_ASSETS_PER_STATE-len(current))
        if remaining <= 0:
            QMessageBox.information(self,"素材池已满",f"「{STATE_NAMES[state]}」已经有 20 支视频。请先点“管理”移除不需要的素材。")
            return
        valid=[]
        ignored=[]
        seen=set()
        for raw in paths or []:
            p=Path(raw)
            key=str(p.resolve()) if p.exists() else str(p)
            if key in seen:
                continue
            seen.add(key)
            if p.is_file() and p.suffix.lower() in VIDEO_EXTS:
                valid.append(str(p))
            else:
                ignored.append(p.name or str(p))
        if not valid:
            QMessageBox.warning(self,"没有可导入的视频","拖入内容中没有支持的视频文件。\n支持：MP4 / MOV / MKV / WebM / AVI / M4V")
            return
        overflow=max(0, len(valid)-remaining)
        paths=valid[:remaining]
        progress=QProgressDialog("正在自动抠绿并生成透明动画…","取消",0,len(paths),self)
        progress.setWindowTitle("批量导入小美丽动画" if source=="drop" else "导入小美丽动画")
        progress.setWindowModality(Qt.WindowModality.WindowModal)
        progress.setMinimumDuration(0)
        success=[]; failed=[]
        state_dir=CACHE_DIR/"v048"/state; state_dir.mkdir(parents=True,exist_ok=True)
        for i,path in enumerate(paths, start=1):
            if progress.wasCanceled(): break
            progress.setLabelText(f"[{i}/{len(paths)}] {Path(path).name}\n自动取绿幕颜色 → 去绿边 → 淡白边/白色柔光 → 透明 WebP")
            QApplication.processEvents()
            try:
                stamp=int(time.time()*1000)
                safe=f"{state}_{stamp}_{i}.webp"
                dst=state_dir/safe
                convert_greenscreen_video(path,dst,max_width=420,target_fps=12)
                success.append(str(dst))
            except Exception as e:
                LOGGER.exception("视频导入失败: %s",path)
                failed.append((Path(path).name,str(e)))
            progress.setValue(i); QApplication.processEvents()
        progress.close()
        if success:
            self.cfg["assets"][state]=(current+success)[:MAX_ASSETS_PER_STATE]
            save_config(self.cfg)
            self.pet.play_state(state, force_new_clip=True)
            self._refresh_asset_label(state)
        msg=f"成功导入 {len(success)} 支。当前「{STATE_NAMES[state]}」素材池：{len(_asset_list(self.cfg['assets'].get(state)))}/{MAX_ASSETS_PER_STATE}。"
        if overflow:
            msg += f"\n\n素材池最多 20 支，本次有 {overflow} 支因容量限制未导入。"
        if ignored:
            msg += "\n\n已忽略非视频文件：" + "、".join(ignored[:5])
        if failed:
            msg += "\n\n失败：\n" + "\n".join(f"• {n}: {e}" for n,e in failed[:5])
        QMessageBox.information(self,"导入完成",msg)

    def upgrade_existing_assets_glow(self):
        jobs = []
        for state in STATE_NAMES:
            for pth in _asset_list(self.cfg.get("assets", {}).get(state)):
                p = Path(pth)
                if not (_is_user_asset(pth) and p.exists() and p.suffix.lower() == ".webp"):
                    continue
                # New V0.4.8 imports already have the effect.
                # V0.4.5+ imports already include the white rim/glow.
                glow_ready_dirs = {"v045", "v045_migrated", "v046", "v047", "v048"}
                if any(str(part).lower() in glow_ready_dirs for part in p.parts):
                    continue
                jobs.append((state, p))
        if not jobs:
            QMessageBox.information(self, "无需处理", "没有发现需要升级白边/柔光的旧版透明 WebP 素材。")
            return
        progress = QProgressDialog("正在为旧素材添加白边 / 柔光…", "取消", 0, len(jobs), self)
        progress.setWindowTitle("升级小美丽动画素材")
        progress.setWindowModality(Qt.WindowModality.WindowModal)
        progress.setMinimumDuration(0)
        replacements = {}
        failed = []
        for i, (state, src) in enumerate(jobs, start=1):
            if progress.wasCanceled():
                break
            progress.setLabelText(f"[{i}/{len(jobs)}] {src.name}\n保留原透明人物 → 添加淡白边 → 柔和外发光")
            QApplication.processEvents()
            try:
                dst_dir = CACHE_DIR / "v045_migrated" / state
                dst_dir.mkdir(parents=True, exist_ok=True)
                dst = dst_dir / f"{src.stem}_glow.webp"
                add_glow_to_transparent_animation(src, dst)
                replacements[str(src)] = str(dst)
            except Exception as e:
                LOGGER.exception("旧素材白边升级失败: %s", src)
                failed.append((src.name, str(e)))
            progress.setValue(i)
            QApplication.processEvents()
        progress.close()
        if replacements:
            for state in STATE_NAMES:
                pool = _asset_list(self.cfg.get("assets", {}).get(state))
                self.cfg["assets"][state] = [replacements.get(str(x), str(x)) for x in pool]
                self._refresh_asset_label(state)
            save_config(self.cfg)
            self.pet.play_state(self.pet.current_state or "idle", force_new_clip=True)
        msg = f"已为 {len(replacements)} 支旧素材补上白边 / 柔光。"
        if failed:
            msg += "\n\n失败：\n" + "\n".join(f"• {n}: {e}" for n,e in failed[:5])
        QMessageBox.information(self, "处理完成", msg)

    def manage_assets(self,state):
        pool=[p for p in _asset_list(self.cfg.get("assets",{}).get(state)) if _is_user_asset(p) and Path(p).exists()]
        dlg=QDialog(self); dlg.setWindowTitle(f"管理「{STATE_NAMES[state]}」素材池")
        dlg.setWindowIcon(QIcon(resource("assets/xiaomeili_icon.png"))); dlg.resize(650,500)
        lay=QVBoxLayout(dlg)
        top=QHBoxLayout(); info=QLabel(f"当前 {len(pool)}/{MAX_ASSETS_PER_STATE} 支")
        top.addWidget(info); top.addWidget(HelpBadge("每条素材显示首帧缩略图，方便删除时确认。随机播放采用有放回抽取，允许连续重复同一支。")); top.addStretch(1); lay.addLayout(top)
        lst=QListWidget(); lst.setIconSize(QSize(96,96)); lst.setSpacing(6); lay.addWidget(lst)
        for pth in pool:
            thumb=asset_thumbnail(pth,96)
            item=QListWidgetItem(QIcon(thumb) if thumb else QIcon(), Path(pth).name)
            item.setData(Qt.ItemDataRole.UserRole,pth); item.setToolTip(pth); item.setSizeHint(QSize(0,104)); lst.addItem(item)
        row=QHBoxLayout(); remove=QPushButton("移除选中"); clear=QPushButton("全部清空"); close=QPushButton("关闭")
        row.addWidget(remove); row.addWidget(clear)
        if state=="report":
            edit_template=QPushButton("编辑选中模板")
            edit_template.setToolTip("为选中的战报视频单独设置白板文字区域和字号。也可以双击素材。")
            row.addWidget(edit_template)
        else:
            edit_template=None
        row.addStretch(1); row.addWidget(close); lay.addLayout(row)
        def sync_from_list():
            vals=[lst.item(i).data(Qt.ItemDataRole.UserRole) for i in range(lst.count())]
            self.cfg["assets"][state]=vals if vals else bundled_assets()[state]
            save_config(self.cfg); self._refresh_asset_label(state)
            if self.pet.current_state==state: self.pet.play_state(state,force_new_clip=True)
            info.setText(f"当前 {len(vals)}/{MAX_ASSETS_PER_STATE} 支")
        def remove_selected():
            for item in list(lst.selectedItems()):
                lst.takeItem(lst.row(item))
            sync_from_list()
        def clear_all():
            if lst.count() and QMessageBox.question(dlg,"确认清空",f"清空「{STATE_NAMES[state]}」的自定义素材池？缓存文件会保留，可避免误删原始素材。") == QMessageBox.StandardButton.Yes:
                lst.clear(); sync_from_list()
        remove.clicked.connect(remove_selected); clear.clicked.connect(clear_all); close.clicked.connect(dlg.accept)
        if state=="report":
            def edit_selected():
                item=lst.currentItem()
                if not item:
                    QMessageBox.information(dlg,"请选择素材","请先选中一支战报视频。")
                    return
                self.open_report_template_editor(item.data(Qt.ItemDataRole.UserRole))
            edit_template.clicked.connect(edit_selected)
            lst.itemDoubleClicked.connect(lambda item:self.open_report_template_editor(item.data(Qt.ItemDataRole.UserRole)))
        dlg.exec()

    def restore_assets(self):
        self.cfg["assets"] = bundled_assets(); save_config(self.cfg)
        for k in STATE_NAMES:self._refresh_asset_label(k)
        self.pet.play_state("idle", force_new_clip=True)
        QMessageBox.information(self,"已恢复","7 个状态已恢复为内置占位动画。你导入过的透明缓存文件不会被删除。")

    def request_debug(self):
        self.vision.request_debug_frame()
        QMessageBox.information(self,"已请求",f"下一次成功识别到 VALORANT 画面时，会保存调试图到：\n{DEBUG_DIR}")

    def update_vision_snapshot(self,data):
        if not self.isVisible(): return
        locked=bool(data.get("report_snapshot_locked"))
        if locked:
            self.report_snapshot_status.setText("战报快照：已锁定")
            self.report_snapshot_status.setStyleSheet("font-size:16px;font-weight:700;color:#169447;padding:4px 0;")
        elif bool(data.get("report_candidate_cached")):
            self.report_snapshot_status.setText("战报快照：五卡候选已缓存")
            self.report_snapshot_status.setStyleSheet("font-size:16px;font-weight:700;color:#D98B00;padding:4px 0;")
        else:
            self.report_snapshot_status.setText("战报快照：未锁定")
            self.report_snapshot_status.setStyleSheet("font-size:16px;font-weight:700;color:#D62828;padding:4px 0;")
        parse_status=str(data.get("report_parse_status") or ("等待结算页" if not locked else "快照已锁定"))
        result=""
        if data.get("report_kills") is not None:
            result=f"  |  本局结果：{data.get('report_nickname','-')} / K={data.get('report_kills')}"
        self.report_parse_label.setText(f"战报解析：{parse_status}{result}")

        mode_name="极低功耗" if data.get("mode","ultra_low")=="ultra_low" else "调试"
        tm=data.get("timings",{}) or {}
        perf=(
            f"模式：{mode_name}  |  截图后端：{data.get('capture_backend','-')}  |  扫描：{data.get('scan_fps',0):.1f} 次/秒\n"
            f"CPU 估算：{data.get('cpu_estimate',0):.1f}%  |  OCR：{data.get('ocr_triggers',0)} 次  |  HP完整识别：{data.get('hp_reads',0)} 次  |  队列：{data.get('queue_length',0)}\n"
            f"耗时(ms)：截取 {tm.get('capture',0):.2f} / 对局 {tm.get('context',0):.2f} / 存活 {tm.get('alive',0):.2f} / HP {tm.get('hp',0):.2f} / 击杀 {tm.get('kill',0):.2f} / 死亡 {tm.get('death',0):.2f} / 结果 {tm.get('result',0):.2f} / OCR {tm.get('ocr',0):.2f}"
        )
        if data.get("disabled"):
            self.vision_status.setText("自动识别：已关闭\n"+perf); return
        if not data.get("game_found"):
            self.vision_status.setText("VALORANT窗口：未找到\n小美丽保持待机。\n"+perf); return
        if data.get("paused") and not data.get("foreground",True):
            self.vision_status.setText("VALORANT窗口：已找到，但当前不在前台\n视觉识别：休眠中\n"+perf); return
        if data.get("error"):
            self.vision_status.setText(f"VALORANT窗口：已找到\n识别错误：{data.get('error')}\n{perf}"); return
        alive={True:"存活",False:"已确认死亡",None:"未确认/疑似"}.get(data.get("alive"),"未确认")
        hp="?" if data.get("hp") is None else str(data.get("hp"))
        nick=str(self.cfg.get("vision",{}).get("player_nickname","")).strip() or "未设置"
        match_txt="对局中" if data.get("match_context") else "非对局（待机门控）"
        text=(
            f"VALORANT窗口：已找到  |  阶段：{data.get('phase','-')}\n"
            f"对局环境：{match_txt}（2/3票={data.get('context_votes',0)}）\n"
            f"对局线索 L/C/R：{data.get('context_left',0):.3f} / {data.get('context_center',0):.3f} / {data.get('context_right',0):.3f}\n"
            f"我的昵称：{nick}  |  击杀二次校验：{data.get('nickname_match','-')}\n"
            f"本人贤者：{alive}（绿色友方整条UI匹配 {data.get('alive_score',0):.3f}）\n"
            f"HP：{hp}（置信 {data.get('hp_conf',0):.3f}）  |  低血量：{'是' if data.get('low_hp') else '否'}\n"
            f"战报布局：{data.get('report_layout_score',0):.3f}  |  快照分数：{data.get('report_snapshot_score',0):.3f}\n"
            f"等待采样：{data.get('report_wait_samples',0)}  |  候选/稳定：{data.get('report_candidate_hits',0)}/{data.get('report_stable_hits',0)}  |  五卡：{data.get('report_candidate_counts',[])}  |  候选质量：{data.get('report_candidate_quality',0):.2f}  |  离线解析：{data.get('report_parse_attempts',0)} 次\n"
            f"当前自动状态：{STATE_NAMES.get(data.get('state'),'待机')}\n{perf}"
        )
        self.vision_status.setText(text)

    def test_report_from_screenshot(self):
        path,_ = QFileDialog.getOpenFileName(self, "选择整局结算页截图", str(Path.home()), "Images (*.png *.jpg *.jpeg *.webp *.bmp)")
        if not path:
            return
        try:
            img = cv2.imread(path)
            if img is None or img.size == 0:
                raise ValueError("无法读取图片")
            h,w = img.shape[:2]
            rx1,ry1,rx2,ry2 = ROI_REPORT_CARDS_RADAR
            radar = img[int(ry1*h):int(ry2*h), int(rx1*w):int(rx2*w)]
            x1,y1,x2,y2 = ROI_REPORT_CARDS
            cards = img[int(y1*h):int(y2*h), int(x1*w):int(x2*w)]
            cx1,cy1,cx2,cy2 = ROI_REPORT_CONTINUE
            cont = img[int(cy1*h):int(cy2*h), int(cx1*w):int(cx2*w)]
            cand,score = self.vision._report_layout_candidate(radar, cont)
            five_ok, five_quality, five_counts, _ = self.vision._report_five_card_completeness(radar)
            if not cand or not five_ok:
                QMessageBox.warning(self, "战报截图测试",
                    f"未通过真正五人结算页检测。\n布局分数：{score:.3f}\n五卡计数：{five_counts}")
                return
            data,desc = self.vision._read_whole_match_report(cards)
            if data is None:
                QMessageBox.warning(self, "战报截图测试", f"结算页布局已命中（{score:.3f}），但OCR未完成：\n{desc}")
                return
            self.pet.show_report(data)
            QMessageBox.information(self, "战报截图测试",
                f"识别成功：\n昵称：{data.get('nickname')}\n卡片：第{data.get('card_index')}位\nK：{data.get('kills')}\n\n已在桌宠上模拟播放战报白板。")
        except Exception as e:
            LOGGER.exception("从截图测试战报失败")
            QMessageBox.critical(self, "战报截图测试失败", f"{type(e).__name__}: {e}")

    def _save_update_source(self):
        url = self.update_url.text().strip()
        self.update_service.set_manifest_url(url)
        self.update_status.setText("更新源已保存。" if url else "更新源已清空。")

    def _check_update(self):
        self._save_update_source()
        self.update_install_btn.setEnabled(False)
        self.update_progress.setValue(0)
        self.update_check_btn.setEnabled(False)
        self.update_service.check_async()

    def _update_check_finished(self, has_update, manifest, message):
        self.update_check_btn.setEnabled(True)
        self.update_status.setText(str(message))
        self.update_install_btn.setEnabled(bool(has_update and manifest))
        if not has_update:
            self.update_progress.setValue(0)

    def _update_progress_changed(self, value, message):
        self.update_progress.setValue(max(0, min(100, int(value))))
        self.update_status.setText(str(message))

    def _install_update(self):
        self.update_install_btn.setEnabled(False)
        self.update_check_btn.setEnabled(False)
        self.update_service.install_latest_async()

    def mark_dirty(self, *args):
        self._dirty = True
        self.save_btn.setEnabled(True)
        self.apply_status.setText("")

    def _bind_dirty_tracking(self):
        for widget, signal_name in [
            (self.top_cb, "toggled"), (self.lock_cb, "toggled"),
            (self.opacity, "valueChanged"), (self.size_spin, "valueChanged"),
            (self.trans_spin, "valueChanged"), (self.vision_enabled, "toggled"),
            (self.nickname_edit, "textChanged"), (self.hp_threshold, "valueChanged"),
            (self.mode_combo, "currentIndexChanged"), (self.pause_bg, "toggled"), (self.nickname_ocr_cb, "toggled"), (self.mouse_interaction_cb, "toggled"),
            (self.voice_test_text, "textChanged"), (self.voice_speed, "valueChanged"),
        ]:
            getattr(widget, signal_name).connect(self.mark_dirty)
        for editor in self.hk_editors.values():
            editor.keySequenceChanged.connect(self.mark_dirty)

    def _show_applied(self):
        self.apply_status.setText("已应用 ✓")
        QTimer.singleShot(1600, lambda: self.apply_status.setText("") if not self._dirty else None)

    def apply(self):
        self.cfg["always_on_top"]=self.top_cb.isChecked()
        locked=self.lock_cb.isChecked(); self.cfg["click_through"]=locked; self.cfg["lock_position"]=locked
        self.cfg["opacity"]=self.opacity.value(); self.cfg["pet_width"]=self.size_spin.value(); self.cfg["transition_ms"]=self.trans_spin.value()
        for k,e in self.hk_editors.items():
            self.cfg["hotkeys"][k]=e.keySequence().toString().lower().replace(" ","")
        self.cfg["mouse_interaction"]["enabled"] = self.mouse_interaction_cb.isChecked()
        if not isinstance(self.cfg.get("voice"), dict): self.cfg["voice"] = {}
        self.cfg["voice"]["speed"] = float(self.voice_speed.value())
        self.cfg["voice"]["test_text"] = self.voice_test_text.text().strip()
        self.cfg["vision"]["enabled"]=self.vision_enabled.isChecked()
        self.cfg["vision"]["player_nickname"]=self.nickname_edit.text().strip()
        self.cfg["vision"]["low_hp_threshold"]=self.hp_threshold.value()
        self.cfg["vision"]["mode"]=self.mode_combo.currentData() or "ultra_low"
        self.cfg["vision"]["pause_when_background"]=self.pause_bg.isChecked()
        self.cfg["vision"]["nickname_ocr_fallback"]=self.nickname_ocr_cb.isChecked()
        self.cfg["x"],self.cfg["y"]=self.pet.x(),self.pet.y()
        save_config(self.cfg)
        self.pet.setWindowOpacity(self.cfg["opacity"]/100.0); self.pet.resize_pet(); self.pet.apply_window_flags(); self.pet.apply_clickthrough_native(); self.pet.refresh_mouse_interaction_config()
        self.hotkeys_changed.emit(); self.config_changed.emit(); LOGGER.info("设置已保存并应用（窗口保持打开）")
        self._dirty = False
        self.save_btn.setEnabled(False)
        self._show_applied()


class AppController(QObject):
    def __init__(self,app,cfg):
        super().__init__()
        self.app=app; self.cfg=cfg; self.bridge=Bridge(); self.pet=PetWindow(cfg); self.settings=None
        self.hotkeys=HotkeyManager(self.bridge)
        self.vision=VisionWorker(cfg)
        self.voice_service=VoiceService()
        self.update_service=UpdateService(cfg)

        self.bridge.trigger_state.connect(self.pet.play_state)
        self.bridge.open_settings.connect(self.open_settings)
        self.bridge.toggle_lock.connect(self.pet.toggle_interaction_lock)
        self.bridge.show_hide.connect(self.pet.toggle_show_hide)
        self.pet.request_settings.connect(self.open_settings)
        self.pet.config_changed.connect(self.update_tray_checks)
        self.vision.state_requested.connect(self.pet.play_state)
        self.vision.report_ready.connect(self.pet.show_report)
        self.vision.snapshot.connect(self.on_vision_snapshot)
        self.update_service.restart_requested.connect(self.quit)

        self.tray=self.make_tray(); self.app.setProperty("tray",self.tray)
        self.hotkeys.register(cfg); self.pet.show(); self.vision.start()

    def make_tray(self):
        tray=QSystemTrayIcon(QIcon(resource("assets/xiaomeili_icon.png")),self.app)
        menu=QMenu()
        for key,name in STATE_NAMES.items():
            act=QAction(name,menu); act.triggered.connect(lambda checked=False,s=key:self.pet.play_state(s)); menu.addAction(act)
        menu.addSeparator()
        self.lock_act=QAction("锁定（位置 + 点击穿透）",menu); self.lock_act.setCheckable(True); self.lock_act.setChecked(self.cfg.get("click_through",False)); self.lock_act.triggered.connect(self.pet.set_interaction_lock); menu.addAction(self.lock_act)
        menu.addSeparator()
        settings=QAction("设置...",menu); settings.triggered.connect(self.open_settings); menu.addAction(settings)
        check_updates=QAction("检查更新",menu); check_updates.triggered.connect(self.check_updates_from_tray); menu.addAction(check_updates)
        logs=QAction("打开日志文件夹",menu); logs.triggered.connect(lambda:os.startfile(str(LOG_DIR)) if sys.platform=='win32' else None); menu.addAction(logs)
        showhide=QAction("显示/隐藏",menu); showhide.triggered.connect(self.pet.toggle_show_hide); menu.addAction(showhide)
        menu.addSeparator()
        quit_act=QAction("退出小美丽",menu); quit_act.triggered.connect(self.quit); menu.addAction(quit_act)
        tray.setContextMenu(menu); tray.setToolTip(APP_NAME); tray.activated.connect(lambda reason:self.open_settings() if reason==QSystemTrayIcon.ActivationReason.DoubleClick else None); tray.show(); return tray

    def check_updates_from_tray(self):
        self.open_settings()
        if self.settings:
            for i in range(self.settings.tabs.count()):
                if self.settings.tabs.tabText(i) == "更新":
                    self.settings.tabs.setCurrentIndex(i)
                    break
            self.settings._check_update()

    def update_tray_checks(self):
        self.lock_act.setChecked(bool(self.cfg.get("click_through",False)))

    def on_vision_snapshot(self,data):
        if self.settings:
            self.settings.update_vision_snapshot(data)

    def open_settings(self):
        if self.settings and self.settings.isVisible():
            # If the settings window is minimized, tray/hotkey/open requests should
            # restore it just like a normal Windows application.
            if self.settings.isMinimized():
                self.settings.showNormal()
            self.settings.raise_(); self.settings.activateWindow(); return
        self.settings=SettingsDialog(self.cfg,self.pet,self.vision,self.voice_service,self.update_service)
        self.settings.hotkeys_changed.connect(lambda:self.hotkeys.register(self.cfg))
        self.settings.config_changed.connect(self.update_tray_checks)
        if self.vision.last_snapshot:
            self.settings.update_vision_snapshot(self.vision.last_snapshot)
        self.settings.show(); self.settings.raise_(); self.settings.activateWindow()

    def quit(self):
        try:
            self.cfg["x"],self.cfg["y"]=self.pet.x(),self.pet.y(); save_config(self.cfg)
            self.pet.lock_bubble.hide(); self.hotkeys.unregister_all(); self.vision.stop(); self.vision.wait(1800)
            LOGGER.info("正常退出")
        finally:
            self.app.quit()


def main():
    set_windows_app_identity()
    app=QApplication(sys.argv); app.setQuitOnLastWindowClosed(False); app.setApplicationName(APP_NAME); app.setWindowIcon(QIcon(resource("assets/xiaomeili_icon.png")))
    cfg=load_config()
    maybe_adopt_report_font(cfg)
    def excepthook(exc_type,exc,tb):
        LOGGER.critical("未捕获异常:\n%s",''.join(traceback.format_exception(exc_type,exc,tb)), exc_info=(exc_type,exc,tb))
        try: QMessageBox.critical(None,"小美丽发生异常",f"错误已自动保存到桌面：\n{DESKTOP_ERROR_LOG}\n\n{exc}")
        except Exception: pass
    sys.excepthook=excepthook
    if hasattr(threading, "excepthook"):
        def thread_excepthook(args):
            LOGGER.critical("后台线程未捕获异常：%s", args.thread.name if args.thread else "unknown", exc_info=(args.exc_type,args.exc_value,args.exc_traceback))
        threading.excepthook=thread_excepthook
    ctl=AppController(app,cfg)
    sys.exit(app.exec())


def runtime_self_test():
    import espeakng_loader
    lib = Path(espeakng_loader.get_library_path())
    data = Path(espeakng_loader.get_data_path())
    if not lib.exists():
        raise FileNotFoundError(f"espeak library missing: {lib}")
    if not data.exists():
        raise FileNotFoundError(f"espeak data missing: {data}")
    from kokoro_onnx import Kokoro, EspeakConfig
    from misaki import zh
    _ = EspeakConfig(lib_path=str(lib), data_path=str(data))
    _ = zh.ZHG2P(version=None)
    return True


if __name__=="__main__":
    if "--runtime-self-test" in sys.argv:
        try:
            runtime_self_test()
            raise SystemExit(0)
        except Exception:
            LOGGER.exception("冻结版运行时自检失败")
            raise SystemExit(7)
    main()
