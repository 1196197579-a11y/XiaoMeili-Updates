﻿$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$ProgressPreference = 'SilentlyContinue'


$InstallRoot = Join-Path $env:PUBLIC 'XiaoMeili'
$AppDir      = Join-Path $InstallRoot 'app'
$SetupLog    = Join-Path $InstallRoot 'setup.log'
$DistRoot    = Join-Path $InstallRoot 'DesktopApp'
$ExeDir      = Join-Path $DistRoot 'XiaoMeili'
$ExePath     = Join-Path $ExeDir 'XiaoMeili.exe'
$SourceRoot  = Split-Path -Parent $MyInvocation.MyCommand.Path
$SourceApp   = Join-Path $SourceRoot 'app'

function Write-Log([string]$Text) {
    $stamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "[$stamp] $Text"
    Write-Host $Text
    Add-Content -LiteralPath $SetupLog -Value $line -Encoding UTF8
}


function Stop-XiaoMeiliProcesses {
    Write-Log 'Stopping any running XiaoMeili processes before rebuild...'
    $names = @('XiaoMeili')
    foreach ($name in $names) {
        try {
            Get-Process -Name $name -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
        } catch {}
    }

    # Also stop python processes whose command line points at an older XiaoMeili install.
    try {
        Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
            Where-Object {
                ($_.Name -match '^(python|pythonw)\.exe$') -and
                ($_.CommandLine -match 'XiaoMeili')
            } |
            ForEach-Object {
                try { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue } catch {}
            }
    } catch {}

    Start-Sleep -Milliseconds 700
}

function Remove-TreeRobust {
    param([Parameter(Mandatory=$true)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) { return }

    $lastError = $null
    for ($attempt = 1; $attempt -le 5; $attempt++) {
        try {
            # Clear read-only flags first; antivirus/previous processes may leave
            # compiled .pyd files temporarily locked.
            Get-ChildItem -LiteralPath $Path -Recurse -Force -ErrorAction SilentlyContinue |
                ForEach-Object {
                    try { $_.IsReadOnly = $false } catch {}
                }

            Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction Stop
            return
        }
        catch {
            $lastError = $_
            Write-Log ("Cleanup attempt $attempt failed: " + $_.Exception.Message)
            Stop-XiaoMeiliProcesses
            Start-Sleep -Milliseconds (500 * $attempt)
        }
    }

    throw ("Unable to remove old build folder after retries: " + $Path + " | " + $lastError.Exception.Message)
}

function Invoke-Logged {
    param(
        [Parameter(Mandatory=$true)][string]$FilePath,
        [Parameter(Mandatory=$false)][string[]]$Arguments = @(),
        [Parameter(Mandatory=$true)][string]$StepName
    )
    Write-Log $StepName
    Add-Content -LiteralPath $SetupLog -Value ("CMD: " + $FilePath + ' ' + ($Arguments -join ' ')) -Encoding UTF8

    # IMPORTANT: PyInstaller writes normal INFO/WARNING progress lines to STDERR.
    # With $ErrorActionPreference='Stop', piping a native command's STDERR through
    # PowerShell can turn those harmless lines into NativeCommandError and abort the
    # installer even while PyInstaller itself is healthy.  Run the child process with
    # redirected files and trust the real process exit code instead.
    $token = [Guid]::NewGuid().ToString('N')
    $stdoutFile = Join-Path $env:TEMP ("xm_" + $token + "_stdout.log")
    $stderrFile = Join-Path $env:TEMP ("xm_" + $token + "_stderr.log")
    try {
        $proc = Start-Process -FilePath $FilePath -ArgumentList $Arguments -Wait -PassThru -NoNewWindow `
            -RedirectStandardOutput $stdoutFile -RedirectStandardError $stderrFile

        foreach ($f in @($stdoutFile, $stderrFile)) {
            if (Test-Path -LiteralPath $f) {
                Get-Content -LiteralPath $f -ErrorAction SilentlyContinue | ForEach-Object {
                    Add-Content -LiteralPath $SetupLog -Value $_ -Encoding UTF8
                }
            }
        }

        $code = $proc.ExitCode
        if ($code -ne 0) {
            throw "$StepName failed with exit code $code"
        }
    }
    finally {
        Remove-Item -LiteralPath $stdoutFile -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $stderrFile -Force -ErrorAction SilentlyContinue
    }
}

try {
    New-Item -ItemType Directory -Force -Path $InstallRoot | Out-Null
    Set-Content -LiteralPath $SetupLog -Value '==================================================' -Encoding UTF8
    Add-Content -LiteralPath $SetupLog -Value 'XiaoMeili V0.6.1.1 Voice Mouth robust installer' -Encoding UTF8
    Add-Content -LiteralPath $SetupLog -Value ("Source: " + $SourceRoot) -Encoding UTF8
    Add-Content -LiteralPath $SetupLog -Value ("Target: " + $AppDir) -Encoding UTF8
    Add-Content -LiteralPath $SetupLog -Value '==================================================' -Encoding UTF8

    Write-Log '[0/9] Preflight package check...'
    $Required = @(
        (Join-Path $SourceApp 'requirements.txt'),
        (Join-Path $SourceApp 'src\main.py'),
        (Join-Path $SourceApp 'assets\xiaomeili_icon.ico'),
        (Join-Path $SourceApp 'assets\xiaomeili_icon.png'),
        (Join-Path $SourceApp 'assets\states\idle.gif'),
        (Join-Path $SourceApp 'assets\states\report.webp'),
        (Join-Path $SourceApp 'assets\vision\sage_alive.png')
    )
    foreach ($item in $Required) {
        if (-not (Test-Path -LiteralPath $item)) {
            throw "Package is incomplete. Missing source file: $item"
        }
    }
    Write-Log 'Package preflight passed.'

    Write-Log '[1/9] Copying application files to ASCII-only path...'
    Stop-XiaoMeiliProcesses
    if (Test-Path -LiteralPath $AppDir) {
        Remove-TreeRobust -Path $AppDir
    }
    New-Item -ItemType Directory -Force -Path $AppDir | Out-Null

    # Explicit copies avoid the PowerShell -LiteralPath + wildcard bug that affected V0.4.1.
    Copy-Item -LiteralPath (Join-Path $SourceApp 'requirements.txt') -Destination (Join-Path $AppDir 'requirements.txt') -Force
    Copy-Item -LiteralPath (Join-Path $SourceApp 'src') -Destination $AppDir -Recurse -Force
    Copy-Item -LiteralPath (Join-Path $SourceApp 'assets') -Destination $AppDir -Recurse -Force

    $TargetReq  = Join-Path $AppDir 'requirements.txt'
    $TargetMain = Join-Path $AppDir 'src\main.py'
    $TargetIcon = Join-Path $AppDir 'assets\xiaomeili_icon.ico'
    foreach ($item in @($TargetReq,$TargetMain,$TargetIcon)) {
        if (-not (Test-Path -LiteralPath $item)) {
            throw "Copy verification failed. Missing target file: $item"
        }
    }
    $copiedCount = (Get-ChildItem -LiteralPath $AppDir -Recurse -File | Measure-Object).Count
    Write-Log ("Copy verified. Files copied: " + $copiedCount)

    Write-Log '[2/9] Locating Python 3.10+...'
    $PythonExe = $null
    $PythonPrefix = @()

    $py = Get-Command 'py.exe' -ErrorAction SilentlyContinue
    if ($py) {
        foreach ($selector in @('-3.12','-3.11','-3.10','-3')) {
            & $py.Source $selector -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" *> $null
            if ($LASTEXITCODE -eq 0) {
                $PythonExe = $py.Source
                $PythonPrefix = @($selector)
                break
            }
        }
    }

    if (-not $PythonExe) {
        $python = Get-Command 'python.exe' -ErrorAction SilentlyContinue
        if ($python) {
            & $python.Source -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" *> $null
            if ($LASTEXITCODE -eq 0) { $PythonExe = $python.Source }
        }
    }

    if (-not $PythonExe) {
        $winget = Get-Command 'winget.exe' -ErrorAction SilentlyContinue
        if (-not $winget) { throw 'Python 3.10+ was not found and winget is unavailable.' }
        Write-Log 'Python was not found. Installing Python 3.12 with winget...'
        & $winget.Source install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements 2>&1 | ForEach-Object {
            Add-Content -LiteralPath $SetupLog -Value $_.ToString() -Encoding UTF8
        }
        if ($LASTEXITCODE -ne 0) { throw "Python installation failed with exit code $LASTEXITCODE" }
        $candidate = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe'
        if (Test-Path -LiteralPath $candidate) {
            $PythonExe = $candidate
            $PythonPrefix = @()
        } else {
            throw 'Python installed, but python.exe was not found. Restart Windows once, then run this installer again.'
        }
    }
    Write-Log ("Python: " + $PythonExe + ' ' + ($PythonPrefix -join ' '))

    Write-Log '[3/9] Preparing isolated Python environment...'
    $VenvDir = Join-Path $AppDir '.venv'
    $VenvPython = Join-Path $VenvDir 'Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $VenvPython)) {
        $venvArgs = @()
        $venvArgs += $PythonPrefix
        $venvArgs += @('-m','venv',$VenvDir)
        Invoke-Logged -FilePath $PythonExe -Arguments $venvArgs -StepName 'Creating virtual environment'
    }
    if (-not (Test-Path -LiteralPath $VenvPython)) { throw 'Virtual environment python.exe was not created.' }

    Invoke-Logged -FilePath $VenvPython -Arguments @('-m','pip','install','--disable-pip-version-check','--upgrade','pip') -StepName '[4/9] Updating pip...'
    Invoke-Logged -FilePath $VenvPython -Arguments @('-m','pip','install','--disable-pip-version-check','-r',$TargetReq) -StepName '[5/9] Installing XiaoMeili dependencies...'

    Write-Log '[6/9] Installing optional DXGI capture backend...'
    $DxcamInstalled = $false
    & $VenvPython -m pip install --disable-pip-version-check 'dxcam>=0.0.5' 2>&1 | ForEach-Object {
        Add-Content -LiteralPath $SetupLog -Value $_.ToString() -Encoding UTF8
    }
    if ($LASTEXITCODE -eq 0) {
        & $VenvPython -c 'import dxcam' *> $null
        if ($LASTEXITCODE -eq 0) { $DxcamInstalled = $true }
    }
    if ($DxcamInstalled) { Write-Log 'DXGI backend ready.' } else { Write-Log 'DXGI backend unavailable; MSS fallback will be used.' }

    Write-Log '[7/9] Verifying runtime imports...'
    # V0.4.9.8: avoid Python -c quoting through PowerShell.  V0.4.2 could lose
    # the inner quotes around print(...), producing a SyntaxError before imports.
    $SelfTestPy = Join-Path $InstallRoot '_runtime_selftest.py'
    $SelfTestCode = @'
import PySide6
from PIL import Image
import keyboard
import cv2
import numpy
import mss
import rapidocr
import onnxruntime
import kokoro_onnx
import espeakng_loader
from pathlib import Path
from misaki import zh
import soundfile
assert Path(espeakng_loader.get_library_path()).exists(), espeakng_loader.get_library_path()
assert Path(espeakng_loader.get_data_path()).exists(), espeakng_loader.get_data_path()
_ = zh.ZHG2P(version=None)
print("runtime imports OK + Kokoro/eSpeak voice runtime OK")
'@
    Set-Content -LiteralPath $SelfTestPy -Value $SelfTestCode -Encoding ASCII
    try {
        Invoke-Logged -FilePath $VenvPython -Arguments @($SelfTestPy) -StepName 'Runtime import self-test'
    }
    finally {
        Remove-Item -LiteralPath $SelfTestPy -Force -ErrorAction SilentlyContinue
    }

    Invoke-Logged -FilePath $VenvPython -Arguments @('-m','pip','install','--disable-pip-version-check','pyinstaller>=6.10,<7') -StepName '[8/9] Installing EXE packager...'

    Write-Log '[9/9] Building XiaoMeili.exe...'
    Stop-XiaoMeiliProcesses
    if (Test-Path -LiteralPath $DistRoot) { Remove-TreeRobust -Path $DistRoot }
    $BuildDir = Join-Path $InstallRoot 'build'
    if (Test-Path -LiteralPath $BuildDir) { Remove-TreeRobust -Path $BuildDir }
    New-Item -ItemType Directory -Force -Path $DistRoot | Out-Null

    $buildArgs = @(
        '-m','PyInstaller',
        '--noconfirm','--clean','--windowed',
        '--name','XiaoMeili',
        '--icon',(Join-Path $AppDir 'assets\xiaomeili_icon.ico'),
        '--distpath',$DistRoot,
        '--workpath',$BuildDir,
        '--specpath',$InstallRoot,
        '--collect-all','rapidocr',
        '--collect-all','onnxruntime',
        '--collect-all','espeakng_loader',
        '--collect-all','kokoro_onnx',
        '--collect-all','misaki',
        '--collect-all','jieba',
        '--collect-all','pypinyin',
        '--collect-all','pypinyin_dict',
        '--collect-all','cn2an',
        '--collect-all','ordered_set',
        '--collect-all','soundfile'
    )
    if ($DxcamInstalled) { $buildArgs += @('--collect-all','dxcam') }
    $buildArgs += @(
        '--add-data',((Join-Path $AppDir 'assets') + ';assets'),
        (Join-Path $AppDir 'src\main.py')
    )
    Invoke-Logged -FilePath $VenvPython -Arguments $buildArgs -StepName 'Packaging Windows GUI EXE'

    if (-not (Test-Path -LiteralPath $ExePath)) {
        throw "Build finished but EXE was not found: $ExePath"
    }

    Write-Log 'Running frozen EXE runtime self-test (including bundled eSpeak-NG data)...'
    $self = Start-Process -FilePath $ExePath -ArgumentList @('--runtime-self-test') -Wait -PassThru
    if ($self.ExitCode -ne 0) {
        throw "Frozen runtime self-test failed with exit code $($self.ExitCode). The EXE will not be accepted."
    }
    Write-Log 'Frozen runtime self-test passed.'

    Write-Log 'Creating desktop shortcut with XiaoMeili icon...'
    # CreateShortcut is deliberately given an ASCII-only .lnk path first.
    # Windows PowerShell 5.x can misread UTF-8 Chinese literals without a BOM,
    # which caused V0.4.6 to build the EXE successfully and then fail only at
    # shortcut creation. Shortcut creation is now non-fatal as well.
    $shortcutPath = $null
    try {
        $desktop = [Environment]::GetFolderPath('Desktop')
        $asciiShortcut = Join-Path $desktop 'XiaoMeili.lnk'
        if (Test-Path -LiteralPath $asciiShortcut) { Remove-Item -LiteralPath $asciiShortcut -Force -ErrorAction SilentlyContinue }
        $ws = New-Object -ComObject WScript.Shell
        $lnk = $ws.CreateShortcut($asciiShortcut)
        $lnk.TargetPath = $ExePath
        $lnk.WorkingDirectory = $ExeDir
        $lnk.IconLocation = "$ExePath,0"
        $lnk.Description = 'XiaoMeili Desktop Pet V0.6.1.1 Voice Mouth'
        $lnk.Save()
        $shortcutPath = $asciiShortcut

        # Best effort: rename the already-valid ASCII shortcut to Chinese display name.
        try {
            $cnBase = ([string][char]0x5C0F) + ([string][char]0x7F8E) + ([string][char]0x4E3D)
            $cnShortcut = Join-Path $desktop ($cnBase + '.lnk')
            if (Test-Path -LiteralPath $cnShortcut) { Remove-Item -LiteralPath $cnShortcut -Force -ErrorAction SilentlyContinue }
            Move-Item -LiteralPath $asciiShortcut -Destination $cnShortcut -Force
            $shortcutPath = $cnShortcut
        }
        catch {
            Write-Log ('WARNING: Chinese shortcut rename failed; keeping XiaoMeili.lnk. ' + $_.Exception.Message)
        }
    }
    catch {
        Write-Log ('WARNING: Desktop shortcut creation failed, but EXE installation will continue. ' + $_.Exception.Message)
    }

    Write-Log ("EXE ready: " + $ExePath)
    if ($shortcutPath) { Write-Log ("Desktop shortcut: " + $shortcutPath) }
    Write-Log 'Starting XiaoMeili...'
    Start-Process -FilePath $ExePath -WorkingDirectory $ExeDir

    Write-Host ''
    Write-Host '==================================================' -ForegroundColor Green
    Write-Host 'XiaoMeili V0.6.1.1 Voice Mouth installation completed.' -ForegroundColor Green
    if ($shortcutPath) {
        Write-Host 'A XiaoMeili shortcut has been created on the desktop.' -ForegroundColor Green
    } else {
        Write-Host 'Shortcut creation was skipped/failed, but the EXE is installed and has been started.' -ForegroundColor Yellow
    }
    Write-Host ("EXE: " + $ExePath)
    Write-Host '==================================================' -ForegroundColor Green
    exit 0
}
catch {
    $msg = $_.Exception.Message
    Add-Content -LiteralPath $SetupLog -Value ('ERROR: ' + $msg) -Encoding UTF8
    Add-Content -LiteralPath $SetupLog -Value ($_ | Out-String) -Encoding UTF8
    $desktop = [Environment]::GetFolderPath('Desktop')
    $desktopLog = Join-Path $desktop '小美丽安装错误日志_请上传给ChatGPT.txt'
    try {
        Copy-Item -LiteralPath $SetupLog -Destination $desktopLog -Force
    } catch {}
    Write-Host ''
    Write-Host '==================================================' -ForegroundColor Red
    Write-Host 'XiaoMeili installation failed.' -ForegroundColor Red
    Write-Host $msg -ForegroundColor Red
    Write-Host ("Desktop diagnostic log: " + $desktopLog) -ForegroundColor Yellow
    Write-Host '==================================================' -ForegroundColor Red
    exit 1
}
