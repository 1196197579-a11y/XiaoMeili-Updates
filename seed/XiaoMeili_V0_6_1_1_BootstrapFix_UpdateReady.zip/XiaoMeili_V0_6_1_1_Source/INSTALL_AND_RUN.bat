@echo off
setlocal EnableExtensions
set "SCRIPT_DIR=%~dp0"
set "PS1=%SCRIPT_DIR%INSTALL.ps1"
title XiaoMeili V0.6.1.1 Bootstrap Installer

if not exist "%PS1%" (
  echo ERROR: INSTALL.ps1 is missing.
  echo Please re-extract the whole package and try again.
  pause
  exit /b 2
)

echo ==================================================
echo XiaoMeili V0.6.1.1 Bootstrap Installer
echo This bootstrap fixes the previous cmd/PowerShell encoding issue.
echo After this install, use XiaoMeili.exe directly.
echo ==================================================
echo.

powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%PS1%"
set "RC=%ERRORLEVEL%"

if "%RC%"=="0" goto success

echo.
echo INSTALL FAILED. Exit code: %RC%
echo A detailed installer log should be copied to the Desktop.
set "FALLBACK_LOG=%USERPROFILE%\Desktop\XiaoMeili_Install_Error_Log.txt"
(
  echo XiaoMeili V0.6.1.1 bootstrap failed.
  echo Exit code: %RC%
  echo Time: %DATE% %TIME%
  echo Script: %PS1%
) > "%FALLBACK_LOG%" 2>nul
echo Fallback log: %FALLBACK_LOG%
pause
exit /b %RC%

:success
echo.
echo Installation completed successfully.
echo From now on, launch XiaoMeili from the Desktop shortcut.
echo Future updates are handled inside Settings - Update after a permanent update source is bound.
pause
exit /b 0
