@echo off
set "CFG=%PUBLIC%\XiaoMeiliData\config.json"
if exist "%CFG%" (
  copy "%CFG%" "%CFG%.backup" >nul
  del /q "%CFG%"
  echo Config reset. Backup: %CFG%.backup
) else (
  echo No config file found.
)
pause
