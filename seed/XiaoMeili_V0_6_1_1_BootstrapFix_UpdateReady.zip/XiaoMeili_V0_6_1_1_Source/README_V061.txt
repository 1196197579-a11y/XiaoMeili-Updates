小美丽 V0.6.1｜Voice Mouth + Continuous Puppet V2

本版重点：
1. 修复 V0.6 声音库 100% 后加载失败：PyInstaller 现在强制收集 espeakng_loader 的 DLL 与 espeak-ng-data，并在构建完成后对冻结 EXE 做运行时自检。自检不过则安装直接判定失败，不再把坏 EXE 交给用户。
2. Kokoro 初始化时显式绑定 espeak-ng 的 library/data 路径。
3. 新增“更新”页与内部更新助手。更新包下载后进行 SHA-256 校验，再覆盖程序目录并自动重启；XiaoMeiliData 下的配置、声音模型、素材与日志不受影响。
4. 新增桌面错误日志：应用内 ERROR/CRITICAL 会自动追加到“桌面\小美丽错误日志_请上传给ChatGPT.txt”。安装失败也会自动生成“桌面\小美丽安装错误日志_请上传给ChatGPT.txt”。
5. 安装目录从版本号目录改为稳定目录：C:\Users\Public\XiaoMeili，便于未来原地升级。
6. 保留 V2 Continuous Puppet 的 18 个鼠标互动素材，已做 SHA-256 一致性校验。

重要：
- V0.6.0 本身没有更新器，因此 V0.6.1 仍需要最后一次手动安装。
- “检查更新”要真正获得未来版本，需要一个永久的 latest.json 更新地址（推荐 GitHub Releases + raw latest.json）。本版已把更新客户端完整做进程序，更新源只需绑定一次。
- 你在 V0.6 已下载的 Kokoro 约 380MB 文件位于 C:\Users\Public\XiaoMeiliData\voice，V0.6.1 会直接复用，不需要重新下载。
