@echo off
set "EXE=%PUBLIC%\XiaoMeili_V0_6\DesktopApp\XiaoMeili\XiaoMeili.exe"
if exist "%EXE%" (
  start "" "%EXE%"
  exit /b 0
)
echo XiaoMeili V0.6 EXE is not installed yet.
echo Run INSTALL_AND_RUN.bat once. After that use the desktop XiaoMeili icon.
pause
