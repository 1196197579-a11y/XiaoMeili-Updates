@echo off
set "APP_DIR=%PUBLIC%\XiaoMeili_V0_6\app"
if not exist "%APP_DIR%\.venv\Scripts\python.exe" (
  echo XiaoMeili V0.6 is not installed yet.
  echo Run INSTALL_AND_RUN.bat first.
  pause
  exit /b 1
)
echo Starting XiaoMeili V0.6 source in diagnostic mode...
echo This window stays open if an error occurs.
echo.
"%APP_DIR%\.venv\Scripts\python.exe" "%APP_DIR%\src\main.py"
echo.
echo Process ended. Latest logs: %PUBLIC%\XiaoMeiliData\logs
pause
